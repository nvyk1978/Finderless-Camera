package com.example.volumecamera;

import android.app.Application;

public class FinderlessApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        CrashLogger.install(this);
        CrashLogger.log(this, "APP_PROCESS_START");
        CrashLogger.recordPreviousExit(this);
    }
}
