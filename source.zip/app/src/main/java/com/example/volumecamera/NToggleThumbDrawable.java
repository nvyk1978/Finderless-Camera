package com.example.volumecamera;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.drawable.Drawable;

/**
 * N-toggle thumb drawn directly in code.
 * The platform cannot substitute state-specific drawable geometry: every state
 * is rendered into the exact same 24dp x 24dp bounds and only the color changes.
 */
public final class NToggleThumbDrawable extends Drawable {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final int sizePx;
    private final boolean lockedRed;

    public NToggleThumbDrawable(Context context, boolean lockedRed) {
        this.sizePx = Math.round(24f * context.getResources().getDisplayMetrics().density);
        this.lockedRed = lockedRed;
        updateColor();
    }

    private void updateColor() {
        if (lockedRed) {
            paint.setColor(Color.rgb(68, 17, 0));       // #441100 dark red
        } else {
            paint.setColor(isChecked() ? Color.rgb(68, 85, 119) : Color.WHITE); // #445577 / white
        }
        invalidateSelf();
    }

    private boolean isChecked() {
        for (int state : getState()) {
            if (state == android.R.attr.state_checked) return true;
        }
        return false;
    }

    @Override public boolean isStateful() { return !lockedRed; }

    @Override protected boolean onStateChange(int[] state) {
        int before = paint.getColor();
        updateColor();
        return before != paint.getColor();
    }

    @Override public void draw(Canvas canvas) {
        android.graphics.Rect b = getBounds();
        float cx = b.exactCenterX();
        float cy = b.exactCenterY();
        float radius = Math.min(b.width(), b.height()) * 0.5f;
        canvas.drawCircle(cx, cy, radius, paint);
    }

    @Override public int getIntrinsicWidth() { return sizePx; }
    @Override public int getIntrinsicHeight() { return sizePx; }
    @Override public int getMinimumWidth() { return sizePx; }
    @Override public int getMinimumHeight() { return sizePx; }
    @Override public void setAlpha(int alpha) { paint.setAlpha(alpha); invalidateSelf(); }
    @Override public void setColorFilter(ColorFilter colorFilter) { paint.setColorFilter(colorFilter); invalidateSelf(); }
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
}
