package com.example.volumecamera;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.widget.RemoteViews;

final class NotificationLauncher {
    static final String CHANNEL_ID = "finderless_launcher_channel_v1";
    static final int ID = 21;
    private static final int UI_DARK_RED = Color.rgb(136, 34, 17);

    private NotificationLauncher() {}

    static void show(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null) return;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "通知ランチャー", NotificationManager.IMPORTANCE_LOW);
            ch.setSound(null, null);
            ch.enableVibration(false);
            nm.createNotificationChannel(ch);
        }
        boolean enabled = c.getSharedPreferences(CameraForegroundService.PREFS, Context.MODE_PRIVATE)
                .getBoolean(CameraForegroundService.KEY_ENABLED, false);

        PendingIntent exit = service(c, 109, CameraForegroundService.ACTION_COMPLETE_EXIT);
        PendingIntent toggle = service(c, 101, CameraForegroundService.ACTION_TOGGLE);
        PendingIntent hide = service(c, 104, CameraForegroundService.ACTION_HIDE_MODE);
        PendingIntent capture = service(c, 103, CameraForegroundService.ACTION_CAPTURE_ONCE);

        Intent open = new Intent(c, MainActivity.class);
        open.putExtra(MainActivity.EXTRA_FORCE_SETTINGS, true);
        PendingIntent openPi = PendingIntent.getActivity(c, 102, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent dismissed = new Intent(c, NotificationLauncherDismissReceiver.class);
        PendingIntent dismissedPi = PendingIntent.getBroadcast(c, 105, dismissed,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        RemoteViews view = new RemoteViews(c.getPackageName(), R.layout.notification_camera);
        view.setTextViewText(R.id.notification_toggle, enabled ? "STOP" : "AUTO");
        view.setInt(R.id.notification_toggle, "setBackgroundResource",
                enabled ? R.drawable.button_dark_gray : R.drawable.button_blue);
        view.setTextColor(R.id.notification_toggle, enabled ? UI_DARK_RED : Color.WHITE);
        view.setInt(R.id.notification_hide, "setBackgroundResource", R.drawable.button_dark_gray);
        view.setTextColor(R.id.notification_hide, Color.WHITE);
        view.setInt(R.id.notification_capture, "setBackgroundResource", R.drawable.button_shutter);
        view.setImageViewResource(R.id.notification_capture_icon, R.drawable.ic_shutter_white);
        view.setImageViewResource(R.id.notification_exit_icon, R.drawable.ic_exit_red);
        view.setOnClickPendingIntent(R.id.notification_exit, exit);
        view.setOnClickPendingIntent(R.id.notification_hide, hide);
        view.setOnClickPendingIntent(R.id.notification_capture, capture);
        view.setOnClickPendingIntent(R.id.notification_toggle, toggle);

        Notification n = new Notification.Builder(c, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification_dot)
                .setOngoing(false).setAutoCancel(false).setOnlyAlertOnce(true)
                .setContentIntent(openPi).setDeleteIntent(dismissedPi)
                .setCustomContentView(view)
                .setStyle(new Notification.DecoratedCustomViewStyle()).build();
        nm.notify(ID, n);
        c.getSharedPreferences(CameraForegroundService.PREFS, Context.MODE_PRIVATE).edit()
                .putBoolean("notification_swipe_end", false)
                .putBoolean("notification_launcher_active", true).apply();
        CrashLogger.log(c, "QS launcher shown without camera FGS");
    }

    private static PendingIntent service(Context c, int request, String action) {
        Intent i = new Intent(c, CameraForegroundService.class).setAction(action);
        return PendingIntent.getService(c, request, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
}
