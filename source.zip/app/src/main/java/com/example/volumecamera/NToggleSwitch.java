package com.example.volumecamera;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.SoundEffectConstants;
import android.view.animation.DecelerateInterpolator;
import android.widget.CompoundButton;

/**
 * N-toggle: fully custom-drawn toggle.
 *
 * Geometry is owned here and does not use android.widget.Switch thumb/track
 * drawables. The OFF white thumb is 24dp; colored thumbs (ON blue / locked dark-red) are 25dp.
 * Normal user changes slide over 120ms; locked-red/programmatic startup state
 * is applied immediately.
 *
 * Rollback: the previous Switch implementation is kept in
 * NToggleSwitchLegacy.java and NToggleThumbDrawable.java.
 */
public class NToggleSwitch extends CompoundButton {
    private static final long THUMB_ANIMATION_MS = 120L;

    private final Paint trackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint thumbPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private boolean lockedRed = false;
    private int trackColor = Color.rgb(42, 34, 34);
    private float thumbProgress = 0f; // 0 = OFF/left, 1 = ON/right
    private ValueAnimator thumbAnimator;

    public NToggleSwitch(Context c) { super(c); init(); }
    public NToggleSwitch(Context c, AttributeSet a) { super(c, a); init(); }
    public NToggleSwitch(Context c, AttributeSet a, int s) { super(c, a, s); init(); }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void init() {
        setButtonDrawable(null);
        setText("");
        setGravity(Gravity.CENTER);
        setMinimumWidth(dp(44));
        setMinimumHeight(dp(24));
        setPadding(0, 0, 0, 0);
        setClickable(true);
        setFocusable(true);
    }

    public void setLockedRed(boolean v) {
        lockedRed = v;
        if (v) {
            // Fixed settings must not visibly travel into place.
            cancelThumbAnimator();
            thumbProgress = isChecked() ? 1f : 0f;
        }
        invalidate();
    }

    public void setNTrackColor(int c) {
        trackColor = c;
        invalidate();
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        cancelThumbAnimator();
        thumbProgress = isChecked() ? 1f : 0f;
        invalidate();
    }

    @Override
    protected void onDetachedFromWindow() {
        cancelThumbAnimator();
        super.onDetachedFromWindow();
    }

    private void cancelThumbAnimator() {
        if (thumbAnimator != null) {
            thumbAnimator.cancel();
            thumbAnimator = null;
        }
    }

    private void animateThumbTo(float target) {
        cancelThumbAnimator();
        if (lockedRed || !isAttachedToWindow()) {
            thumbProgress = target;
            invalidate();
            return;
        }
        if (Math.abs(thumbProgress - target) < 0.001f) {
            thumbProgress = target;
            invalidate();
            return;
        }
        thumbAnimator = ValueAnimator.ofFloat(thumbProgress, target);
        thumbAnimator.setDuration(THUMB_ANIMATION_MS);
        thumbAnimator.setInterpolator(new DecelerateInterpolator());
        thumbAnimator.addUpdateListener(animation -> {
            thumbProgress = (float) animation.getAnimatedValue();
            invalidate();
        });
        thumbAnimator.start();
    }

    @Override
    public void setChecked(boolean checked) {
        final boolean changed = checked != isChecked();
        super.setChecked(checked);
        if (changed) {
            animateThumbTo(checked ? 1f : 0f);
            refreshDrawableState();
            invalidate();
            postInvalidateOnAnimation();
        } else if (!isAttachedToWindow()) {
            // Keep initial XML/programmatic state in sync before first attach.
            thumbProgress = checked ? 1f : 0f;
        }
    }

    @Override
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        invalidate();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (!isEnabled()) return false;
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                setPressed(true);
                return true;
            case MotionEvent.ACTION_UP:
                setPressed(false);
                toggle();
                playSoundEffect(SoundEffectConstants.CLICK);
                return true;
            case MotionEvent.ACTION_CANCEL:
                setPressed(false);
                return true;
            default:
                return true;
        }
    }

    @Override
    public boolean performClick() {
        return super.performClick();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        final int trackW = dp(44);
        final int trackH = dp(24);
        final int thumbD = dp((lockedRed || isChecked()) ? 25 : 24);

        final int left = (getWidth() - trackW) / 2;
        final int top = (getHeight() - trackH) / 2;
        final int right = left + trackW;
        final int bottom = top + trackH;

        trackPaint.setColor(trackColor);
        canvas.drawRoundRect(new RectF(left, top, right, bottom),
                trackH / 2f, trackH / 2f, trackPaint);

        final float travel = trackW - thumbD;
        final float thumbLeft = left + travel * thumbProgress;
        final float thumbTop = top + (trackH - thumbD) / 2f;

        thumbPaint.setColor(lockedRed
                ? Color.rgb(68, 17, 0)
                : (isChecked() ? Color.rgb(68, 85, 119) : Color.WHITE));
        canvas.drawOval(new RectF(thumbLeft, thumbTop,
                thumbLeft + thumbD, thumbTop + thumbD), thumbPaint);
    }
}
