package com.example.volumecamera;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.Gravity;
import android.widget.CompoundButton;

/**
 * N-toggle: fully custom-drawn toggle.
 *
 * Geometry is owned here and does not use android.widget.Switch thumb/track
 * drawables at all.  In particular, the thumb is drawn from an integer-pixel
 * rectangle of exactly dp(24) x dp(24).  This avoids the one-pixel rasterisation
 * difference that occurred when the checked and unchecked circles had fractional
 * pixel centres.
 *
 * Rollback: the previous Switch implementation is kept in
 * NToggleSwitchLegacy.java and NToggleThumbDrawable.java.
 */
public class NToggleSwitch extends CompoundButton {
    private final Paint trackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint thumbPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private boolean lockedRed = false;
    private int trackColor = Color.rgb(42, 34, 34);

    public NToggleSwitch(Context c) { super(c); init(); }
    public NToggleSwitch(Context c, AttributeSet a) { super(c, a); init(); }
    public NToggleSwitch(Context c, AttributeSet a, int s) { super(c, a, s); init(); }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void init() {
        setButtonDrawable(null);
        setText("");
        setGravity(Gravity.CENTER);
        setMinimumWidth(dp(44));
        setMinimumHeight(dp(24));
        setPadding(0, 0, 0, 0);
        setClickable(true);
        setFocusable(true);
    }

    public void setLockedRed(boolean v) { lockedRed = v; invalidate(); }
    public void setNTrackColor(int c) { trackColor = c; invalidate(); }

    @Override
    public boolean onTouchEvent(android.view.MotionEvent event) {
        if (!isEnabled()) return false;
        switch (event.getActionMasked()) {
            case android.view.MotionEvent.ACTION_DOWN:
                setPressed(true);
                return true;
            case android.view.MotionEvent.ACTION_UP:
                setPressed(false);
                // Do not route through CompoundButton.performClick(). On this
                // custom-drawn control that path was not changing state on-device.
                // Toggle the CompoundButton state directly so the existing
                // OnCheckedChangeListener is fired exactly once.
                toggle();
                playSoundEffect(android.view.SoundEffectConstants.CLICK);
                return true;
            case android.view.MotionEvent.ACTION_CANCEL:
                setPressed(false);
                return true;
            default:
                return true;
        }
    }

    @Override
    public boolean performClick() {
        // CompoundButton.performClick() toggles checked state exactly once and
        // then dispatches the existing OnCheckedChangeListener callbacks.
        return super.performClick();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        final int trackW = dp(44);
        final int trackH = dp(24);
        // N-toggle standard geometry: every thumb state uses exactly the same
        // integer-pixel diameter. Only the paint color changes.
        final int normalThumbD = dp(24);
        final int thumbD = normalThumbD;

        // Integer-pixel bounds are deliberate: ON and OFF must rasterise to
        // exactly the same pixel dimensions, not merely the same dp radius.
        final int left = (getWidth() - trackW) / 2;
        final int top = (getHeight() - trackH) / 2;
        final int right = left + trackW;
        final int bottom = top + trackH;

        trackPaint.setColor(trackColor);
        canvas.drawRoundRect(new RectF(left, top, right, bottom),
                trackH / 2f, trackH / 2f, trackPaint);

        final int baseThumbD = normalThumbD;
        final int baseLeft = isChecked() ? right - baseThumbD : left;
        final int baseTop = top + (trackH - baseThumbD) / 2;
        final int thumbLeft = baseLeft - (thumbD - baseThumbD) / 2;
        final int thumbTop = baseTop - (thumbD - baseThumbD) / 2;
        thumbPaint.setColor(lockedRed
                ? Color.rgb(68, 17, 0)
                : (isChecked() ? Color.rgb(68, 85, 119) : Color.WHITE));
        canvas.drawOval(new RectF(thumbLeft, thumbTop,
                thumbLeft + thumbD, thumbTop + thumbD), thumbPaint);
    }
}
