package com.example.volumecamera;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class NotificationLauncherDismissReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        context.getSharedPreferences(CameraForegroundService.PREFS, Context.MODE_PRIVATE).edit()
                .putBoolean("notification_swipe_end", true)
                .putBoolean("notification_launcher_active", false).apply();
        CrashLogger.log(context, "QS launcher dismissed -> launcher inactive");
        boolean serviceRunning = context.getSharedPreferences(CameraForegroundService.PREFS, Context.MODE_PRIVATE)
                .getBoolean("service_running", false);
        if (serviceRunning) {
            Intent stopLauncher = new Intent(context, CameraForegroundService.class)
                    .setAction(CameraForegroundService.ACTION_NOTIFICATION_DISMISSED);
            context.startService(stopLauncher);
        } else {
            context.sendBroadcast(new Intent(CameraForegroundService.ACTION_SERVICE_STATE_CHANGED)
                    .setPackage(context.getPackageName()));
        }
    }
}
