package com.example.volumecamera;

import android.app.ActivityManager;
import android.app.ApplicationExitInfo;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.os.Build;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public final class CrashLogger {
    private static final String FILE_NAME = "finderless_diagnostic.log";
    private static final long MAX_LOG_BYTES = 512 * 1024;
    private static final int REPORT_TAIL_BYTES = 160 * 1024;
    private static final String PREFS = "finderless_diagnostic_prefs";
    private static final String KEY_LAST_EXIT_TS = "last_exit_timestamp";

    private CrashLogger() {}

    public static void install(Context context) {
        final Context app = context.getApplicationContext();
        final Thread.UncaughtExceptionHandler previous =
                Thread.getDefaultUncaughtExceptionHandler();

        Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {
            try {
                log(app, "UNCAUGHT_EXCEPTION thread=" + thread.getName()
                        + "\n" + stackTrace(throwable));
            } catch (Throwable ignored) {}

            if (previous != null) {
                previous.uncaughtException(thread, throwable);
            }
        });
    }

    public static synchronized void log(Context context, String event) {
        if (context == null) return;

        try {
            File file = new File(context.getFilesDir(), FILE_NAME);
            rotateIfNeeded(file);

            String timestamp = new SimpleDateFormat(
                    "yyyy-MM-dd HH:mm:ss.SSS", Locale.US
            ).format(new Date());

            String line = timestamp
                    + " [" + Thread.currentThread().getName() + "] "
                    + event + "\n";

            try (FileOutputStream out = new FileOutputStream(file, true)) {
                out.write(line.getBytes(StandardCharsets.UTF_8));
                out.flush();
            }
        } catch (Throwable ignored) {}
    }

    public static void logThrowable(Context context, String event, Throwable throwable) {
        log(context, event + "\n" + stackTrace(throwable));
    }

    private static String stackTrace(Throwable throwable) {
        if (throwable == null) return "(null throwable)";
        try {
            StringWriter sw = new StringWriter();
            throwable.printStackTrace(new PrintWriter(sw));
            return sw.toString();
        } catch (Throwable ignored) {
            return throwable.getClass().getName() + ": " + throwable.getMessage();
        }
    }

    private static void rotateIfNeeded(File file) {
        if (!file.exists() || file.length() < MAX_LOG_BYTES) return;

        File old = new File(file.getParentFile(), FILE_NAME + ".old");
        if (old.exists()) old.delete();
        file.renameTo(old);
    }

    public static void recordPreviousExit(Context context) {
        if (Build.VERSION.SDK_INT < 30) return;

        try {
            ActivityManager am =
                    (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
            if (am == null) return;

            List<ApplicationExitInfo> exits =
                    am.getHistoricalProcessExitReasons(null, 0, 5);
            if (exits == null || exits.isEmpty()) return;

            ApplicationExitInfo exit = exits.get(0);
            long ts = exit.getTimestamp();

            SharedPreferences prefs =
                    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            long alreadyLogged = prefs.getLong(KEY_LAST_EXIT_TS, 0L);
            if (ts <= alreadyLogged) return;

            StringBuilder b = new StringBuilder();
            b.append("PREVIOUS_PROCESS_EXIT")
                    .append(" reason=").append(reasonName(exit.getReason()))
                    .append("(").append(exit.getReason()).append(")")
                    .append(" status=").append(exit.getStatus())
                    .append(" importance=").append(exit.getImportance())
                    .append(" pss=").append(exit.getPss())
                    .append(" rss=").append(exit.getRss())
                    .append(" timestamp=").append(ts);

            CharSequence description = exit.getDescription();
            if (description != null) {
                b.append(" description=").append(description);
            }

            log(context, b.toString());

            try (InputStream trace = exit.getTraceInputStream()) {
                if (trace != null) {
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    byte[] buffer = new byte[1024];
                    int total = 0;
                    int read;
                    while (total < 8192
                            && (read = trace.read(
                                    buffer,
                                    0,
                                    Math.min(buffer.length, 8192 - total)
                            )) > 0) {
                        out.write(buffer, 0, read);
                        total += read;
                    }
                    String traceText =
                            new String(out.toByteArray(), StandardCharsets.UTF_8);
                    if (!traceText.trim().isEmpty()) {
                        log(context, "PREVIOUS_EXIT_TRACE\n" + traceText);
                    }
                }
            } catch (Throwable traceError) {
                log(context, "PREVIOUS_EXIT_TRACE unavailable: "
                        + traceError.getClass().getSimpleName()
                        + ": " + traceError.getMessage());
            }

            prefs.edit().putLong(KEY_LAST_EXIT_TS, ts).apply();
        } catch (Throwable error) {
            logThrowable(context, "recordPreviousExit failed", error);
        }
    }

    private static String reasonName(int reason) {
        if (Build.VERSION.SDK_INT < 30) return "UNKNOWN";
        switch (reason) {
            case ApplicationExitInfo.REASON_ANR:
                return "ANR";
            case ApplicationExitInfo.REASON_CRASH:
                return "CRASH";
            case ApplicationExitInfo.REASON_CRASH_NATIVE:
                return "CRASH_NATIVE";
            case ApplicationExitInfo.REASON_DEPENDENCY_DIED:
                return "DEPENDENCY_DIED";
            case ApplicationExitInfo.REASON_EXCESSIVE_RESOURCE_USAGE:
                return "EXCESSIVE_RESOURCE_USAGE";
            case ApplicationExitInfo.REASON_EXIT_SELF:
                return "EXIT_SELF";
            case ApplicationExitInfo.REASON_INITIALIZATION_FAILURE:
                return "INITIALIZATION_FAILURE";
            case ApplicationExitInfo.REASON_LOW_MEMORY:
                return "LOW_MEMORY";
            case ApplicationExitInfo.REASON_OTHER:
                return "OTHER";
            case ApplicationExitInfo.REASON_PERMISSION_CHANGE:
                return "PERMISSION_CHANGE";
            case ApplicationExitInfo.REASON_SIGNALED:
                return "SIGNALED";
            case ApplicationExitInfo.REASON_USER_REQUESTED:
                return "USER_REQUESTED";
            case ApplicationExitInfo.REASON_USER_STOPPED:
                return "USER_STOPPED";
            default:
                return "UNKNOWN";
        }
    }

    public static synchronized String getReport(Context context) {
        StringBuilder report = new StringBuilder();

        report.append("FinderlessCamera diagnostic report\n");
        report.append("Generated: ")
                .append(new SimpleDateFormat(
                        "yyyy-MM-dd HH:mm:ss.SSS", Locale.US
                ).format(new Date()))
                .append("\n");
        report.append("Device: ")
                .append(Build.MANUFACTURER).append(" ")
                .append(Build.MODEL).append("\n");
        report.append("Android: ")
                .append(Build.VERSION.RELEASE)
                .append(" (SDK ").append(Build.VERSION.SDK_INT).append(")\n");

        try {
            PackageInfo info = context.getPackageManager()
                    .getPackageInfo(context.getPackageName(), 0);
            report.append("App: ").append(info.versionName)
                    .append(" (").append(info.getLongVersionCode()).append(")\n");
        } catch (Throwable ignored) {}

        report.append("\n--- LOG ---\n");

        File file = new File(context.getFilesDir(), FILE_NAME);
        if (!file.exists()) {
            report.append("(no diagnostic log yet)\n");
            return report.toString();
        }

        try (FileInputStream in = new FileInputStream(file)) {
            long length = file.length();
            long skip = Math.max(0, length - REPORT_TAIL_BYTES);
            while (skip > 0) {
                long skipped = in.skip(skip);
                if (skipped <= 0) break;
                skip -= skipped;
            }

            byte[] bytes = new byte[(int) Math.min(REPORT_TAIL_BYTES, file.length())];
            int offset = 0;
            int read;
            while (offset < bytes.length
                    && (read = in.read(bytes, offset, bytes.length - offset)) > 0) {
                offset += read;
            }

            report.append(new String(bytes, 0, offset, StandardCharsets.UTF_8));
        } catch (Throwable error) {
            report.append("Could not read log: ")
                    .append(error.getClass().getName())
                    .append(": ").append(error.getMessage()).append("\n");
        }

        return report.toString();
    }

    public static synchronized void clear(Context context) {
        try {
            File file = new File(context.getFilesDir(), FILE_NAME);
            if (file.exists()) file.delete();
            File old = new File(context.getFilesDir(), FILE_NAME + ".old");
            if (old.exists()) old.delete();
            log(context, "DIAGNOSTIC_LOG_CLEARED");
        } catch (Throwable ignored) {}
    }
}
