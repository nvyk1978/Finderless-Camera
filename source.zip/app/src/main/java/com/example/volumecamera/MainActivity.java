package com.example.volumecamera;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_PERMS = 100;
    private TextView status;
    private Switch floatingSwitch;
    private boolean changingFloatingSwitch = false;
    private boolean pendingOverlayPermission = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                .edit().putBoolean(CameraForegroundService.KEY_FLOAT_ENABLED, false).apply();
        setContentView(R.layout.activity_main);

        status = findViewById(R.id.status);
        floatingSwitch = findViewById(R.id.floating_shutter_switch);
        Button start = findViewById(R.id.start_service);
        requestNeededPermissions();

        start.setOnClickListener(v -> {
            if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                requestNeededPermissions();
                return;
            }
            Intent i = new Intent(this, CameraForegroundService.class);
            i.setAction(CameraForegroundService.ACTION_START);
            startForegroundService(i);
            status.setText("常駐通知を開始しました。");
        });

        floatingSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (changingFloatingSwitch) return;
            if (isChecked && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                changingFloatingSwitch = true;
                floatingSwitch.setChecked(false);
                changingFloatingSwitch = false;
                requestNeededPermissions();
                status.setText("フロートシャッターにはカメラ権限が必要です。");
                return;
            }
            if (isChecked && !Settings.canDrawOverlays(this)) {
                changingFloatingSwitch = true;
                floatingSwitch.setChecked(false);
                changingFloatingSwitch = false;
                pendingOverlayPermission = true;
                status.setText("「他のアプリの上に重ねて表示」を許可してください。");
                Intent overlayIntent = new Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(overlayIntent);
                return;
            }
            setFloatingShutterEnabled(isChecked);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (pendingOverlayPermission && Settings.canDrawOverlays(this)) {
            pendingOverlayPermission = false;
            setFloatingShutterEnabled(true);
        }
        syncFloatingSwitch();
    }

    private void syncFloatingSwitch() {
        boolean enabled = getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                .getBoolean(CameraForegroundService.KEY_FLOAT_ENABLED, false);
        if (enabled && !Settings.canDrawOverlays(this)) {
            enabled = false;
            getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                    .edit().putBoolean(CameraForegroundService.KEY_FLOAT_ENABLED, false).apply();
        }
        changingFloatingSwitch = true;
        floatingSwitch.setChecked(enabled);
        changingFloatingSwitch = false;
    }

    private void setFloatingShutterEnabled(boolean enabled) {
        getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                .edit().putBoolean(CameraForegroundService.KEY_FLOAT_ENABLED, enabled).apply();
        Intent i = new Intent(this, CameraForegroundService.class);
        i.setAction(enabled ? CameraForegroundService.ACTION_FLOAT_ON : CameraForegroundService.ACTION_FLOAT_OFF);
        startForegroundService(i);
        changingFloatingSwitch = true;
        floatingSwitch.setChecked(enabled);
        changingFloatingSwitch = false;
    }

    private void requestNeededPermissions() {
        List<String> perms = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            perms.add(Manifest.permission.CAMERA);
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (!perms.isEmpty()) requestPermissions(perms.toArray(new String[0]), REQ_PERMS);
    }
}
