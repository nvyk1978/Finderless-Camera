package com.example.volumecamera;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.ImageFormat;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.os.Build;
import android.os.Bundle;
import android.util.Size;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int REQ_PERMS = 100;

    private TextView status;
    private TextView concurrentStatus;
    private LinearLayout cameraList;
    private final Map<String, Switch> cameraSwitches = new LinkedHashMap<>();
    private final Map<String, CameraInfo> cameraInfos = new LinkedHashMap<>();
    private Set<Set<String>> concurrentSets = new HashSet<>();
    private boolean changingSwitches = false;

    private static class CameraInfo {
        String id;
        float focalMm;
        long maxPixels;
        String label;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        status = findViewById(R.id.status);
        concurrentStatus = findViewById(R.id.concurrent_status);
        cameraList = findViewById(R.id.camera_list);
        Button start = findViewById(R.id.start_service);

        requestNeededPermissions();
        loadCameraList();

        start.setOnClickListener(v -> {
            if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                requestNeededPermissions();
                return;
            }
            persistSelection();
            Intent i = new Intent(this, CameraForegroundService.class);
            i.setAction(CameraForegroundService.ACTION_START);
            startForegroundService(i);
            status.setText("常駐通知を開始しました。");
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            loadCameraList();
        }
    }

    private void requestNeededPermissions() {
        List<String> perms = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            perms.add(Manifest.permission.CAMERA);
        }
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (!perms.isEmpty()) {
            requestPermissions(perms.toArray(new String[0]), REQ_PERMS);
        }
    }

    private void loadCameraList() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            cameraList.removeAllViews();
            concurrentStatus.setText("カメラ権限を許可すると一覧を表示します。");
            return;
        }

        CameraManager manager = getSystemService(CameraManager.class);
        cameraInfos.clear();
        cameraSwitches.clear();
        cameraList.removeAllViews();
        concurrentSets = new HashSet<>();

        try {
            if (Build.VERSION.SDK_INT >= 30) {
                concurrentSets.addAll(manager.getConcurrentCameraIds());
            }

            List<CameraInfo> infos = new ArrayList<>();
            for (String id : manager.getCameraIdList()) {
                CameraCharacteristics c = manager.getCameraCharacteristics(id);
                Integer facing = c.get(CameraCharacteristics.LENS_FACING);
                if (facing == null || facing != CameraCharacteristics.LENS_FACING_BACK) continue;

                StreamConfigurationMap map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
                if (map == null) continue;
                Size[] jpegSizes = map.getOutputSizes(ImageFormat.JPEG);
                if (jpegSizes == null || jpegSizes.length == 0) continue;

                CameraInfo info = new CameraInfo();
                info.id = id;

                float[] focals = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS);
                info.focalMm = (focals != null && focals.length > 0) ? focals[0] : 0f;

                Size max = Arrays.stream(jpegSizes)
                        .max(Comparator.comparingLong(s -> (long) s.getWidth() * s.getHeight()))
                        .orElse(jpegSizes[0]);
                info.maxPixels = (long) max.getWidth() * max.getHeight();
                infos.add(info);
            }

            infos.sort(Comparator.comparingDouble(i -> i.focalMm <= 0 ? Double.MAX_VALUE : i.focalMm));

            for (int i = 0; i < infos.size(); i++) {
                CameraInfo info = infos.get(i);
                info.label = inferLabel(infos, i);
                cameraInfos.put(info.id, info);
            }

            SharedPreferences prefs = getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE);
            Set<String> saved = new HashSet<>(prefs.getStringSet(
                    CameraForegroundService.KEY_SELECTED_CAMERAS, new HashSet<>()));

            if (saved.isEmpty() && !infos.isEmpty()) {
                saved.add(infos.get(Math.min(infos.size() - 1, infos.size() / 2)).id);
            }

            for (CameraInfo info : infos) {
                Switch sw = new Switch(this);
                sw.setText(formatCameraLine(info));
                sw.setTextSize(16f);
                sw.setPadding(0, 14, 0, 14);
                sw.setChecked(saved.contains(info.id));
                sw.setTag(info.id);
                sw.setOnCheckedChangeListener((buttonView, isChecked) -> {
                    if (changingSwitches) return;
                    if (isChecked && !isSelectionAllowedWith(info.id)) {
                        changingSwitches = true;
                        buttonView.setChecked(false);
                        changingSwitches = false;
                        Toast.makeText(
                                this,
                                "このカメラの組み合わせは同時使用に対応していません",
                                Toast.LENGTH_SHORT
                        ).show();
                        return;
                    }
                    ensureOneSelected();
                    persistSelection();
                });
                cameraSwitches.put(info.id, sw);
                cameraList.addView(sw);
            }

            if (infos.isEmpty()) {
                concurrentStatus.setText("Camera2から利用可能な背面カメラを取得できませんでした。");
            } else if (Build.VERSION.SDK_INT < 30 || concurrentSets.isEmpty()) {
                concurrentStatus.setText("複数カメラ同時使用：非対応または非公開");
            } else {
                concurrentStatus.setText("複数カメラ同時使用：対応する組み合わせのみ複数選択できます");
            }
        } catch (CameraAccessException e) {
            concurrentStatus.setText("カメラ情報の取得に失敗しました。");
        }
    }

    private String inferLabel(List<CameraInfo> infos, int index) {
        if (infos.size() >= 3) {
            if (index == 0) return "超広角側";
            if (index == infos.size() - 1) return "望遠側";
            return "標準側";
        }
        if (infos.size() == 2) {
            return index == 0 ? "広角側" : "望遠側";
        }
        return "背面";
    }

    private String formatCameraLine(CameraInfo info) {
        String focal = info.focalMm > 0
                ? String.format(Locale.JAPAN, "%.1f mm", info.focalMm)
                : "焦点距離不明";
        double mp = info.maxPixels / 1_000_000.0;
        return String.format(
                Locale.JAPAN,
                "%s  Camera %s\n%s / 最大 %.1f MP",
                info.label, info.id, focal, mp
        );
    }

    private boolean isSelectionAllowedWith(String newlyCheckedId) {
        Set<String> selected = getSelectedIds();
        selected.add(newlyCheckedId);
        if (selected.size() <= 1) return true;
        if (Build.VERSION.SDK_INT < 30 || concurrentSets.isEmpty()) return false;

        for (Set<String> supported : concurrentSets) {
            if (supported.containsAll(selected)) return true;
        }
        return false;
    }

    private Set<String> getSelectedIds() {
        Set<String> selected = new HashSet<>();
        for (Map.Entry<String, Switch> e : cameraSwitches.entrySet()) {
            if (e.getValue().isChecked()) selected.add(e.getKey());
        }
        return selected;
    }

    private void ensureOneSelected() {
        Set<String> selected = getSelectedIds();
        if (!selected.isEmpty()) return;

        for (Map.Entry<String, Switch> e : cameraSwitches.entrySet()) {
            changingSwitches = true;
            e.getValue().setChecked(true);
            changingSwitches = false;
            break;
        }
    }

    private void persistSelection() {
        Set<String> selected = getSelectedIds();
        if (selected.isEmpty() && !cameraSwitches.isEmpty()) {
            String first = cameraSwitches.keySet().iterator().next();
            selected.add(first);
        }
        getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                .edit()
                .putStringSet(CameraForegroundService.KEY_SELECTED_CAMERAS, new HashSet<>(selected))
                .apply();
    }
}
