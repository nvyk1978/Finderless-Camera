package com.example.volumecamera;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final String KEY_SERVICE_RUNNING = "service_running";
    private static final String KEY_AUTO_START_RESIDENT = "auto_start_resident";
    private static final int REQ_PERMS = 100;

    private TextView status;
    private Button startServiceButton;
    private Switch floatingSwitch;
    private Switch burstSwitch;
    private Switch shutterVibrationSwitch;
    private Switch autoStartResidentSwitch;

    private boolean changingFloatingSwitch = false;
    private boolean pendingOverlayPermission = false;
    private boolean receiverRegistered = false;

    private final BroadcastReceiver stateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            syncFloatingSwitch();
            updateServiceButton();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        CrashLogger.log(this, "ACTIVITY onCreate");
        setContentView(R.layout.activity_main);

        status = findViewById(R.id.status);
        floatingSwitch = findViewById(R.id.floating_shutter_switch);
        burstSwitch = findViewById(R.id.burst_shot_switch);
        shutterVibrationSwitch = findViewById(R.id.shutter_vibration);
        autoStartResidentSwitch = findViewById(R.id.auto_start_resident);
        startServiceButton = findViewById(R.id.start_service);
        Button diagnostic = findViewById(R.id.show_diagnostic);

        requestNeededPermissions();
        bindSettings();
        diagnostic.setOnClickListener(v -> showDiagnosticReport());

        startServiceButton.setOnClickListener(v -> {
            if (isNotificationActive()) {
                stopResidentService();
            } else {
                startResidentService();
            }
            updateServiceButton();
        });
    }

    private void bindSettings() {
        floatingSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (changingFloatingSwitch) return;

            if (isChecked && checkSelfPermission(Manifest.permission.CAMERA)
                    != PackageManager.PERMISSION_GRANTED) {
                changingFloatingSwitch = true;
                floatingSwitch.setChecked(false);
                changingFloatingSwitch = false;
                requestNeededPermissions();
                status.setText("フロートシャッターにはカメラ権限が必要です。");
                return;
            }

            if (isChecked && !Settings.canDrawOverlays(this)) {
                changingFloatingSwitch = true;
                floatingSwitch.setChecked(false);
                changingFloatingSwitch = false;
                pendingOverlayPermission = true;
                status.setText("「他のアプリの上に重ねて表示」を許可してください。");
                Intent overlayIntent = new Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())
                );
                startActivity(overlayIntent);
                return;
            }

            setFloatingShutterEnabled(isChecked);
        });

        boolean burst = getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).getBoolean(CameraForegroundService.KEY_BURST_ENABLED, false);
        burstSwitch.setChecked(burst);
        burstSwitch.setOnCheckedChangeListener((buttonView, isChecked) ->
                getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                        .edit()
                        .putBoolean(CameraForegroundService.KEY_BURST_ENABLED, isChecked)
                        .apply()
        );

        boolean vibration = getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).getBoolean(CameraForegroundService.KEY_SHUTTER_VIBRATION, true);
        shutterVibrationSwitch.setChecked(vibration);
        shutterVibrationSwitch.setOnCheckedChangeListener((buttonView, isChecked) ->
                getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                        .edit()
                        .putBoolean(CameraForegroundService.KEY_SHUTTER_VIBRATION, isChecked)
                        .apply()
        );

        boolean autoStart = getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).getBoolean(KEY_AUTO_START_RESIDENT, false);
        autoStartResidentSwitch.setChecked(autoStart);
        autoStartResidentSwitch.setOnCheckedChangeListener((buttonView, isChecked) ->
                getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                        .edit()
                        .putBoolean(KEY_AUTO_START_RESIDENT, isChecked)
                        .apply()
        );
    }

    @Override
    protected void onResume() {
        super.onResume();
        CrashLogger.log(this, "ACTIVITY onResume");

        if (!receiverRegistered) {
            IntentFilter filter = new IntentFilter();
            filter.addAction(CameraForegroundService.ACTION_FLOAT_STATE_CHANGED);
            filter.addAction(CameraForegroundService.ACTION_SERVICE_STATE_CHANGED);
            registerReceiver(stateReceiver, filter, RECEIVER_NOT_EXPORTED);
            receiverRegistered = true;
        }

        if (pendingOverlayPermission && Settings.canDrawOverlays(this)) {
            pendingOverlayPermission = false;
            setFloatingShutterEnabled(true);
        }

        syncFloatingSwitch();

        boolean autoStart = getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).getBoolean(KEY_AUTO_START_RESIDENT, false);

        if (autoStart
                && !isNotificationActive()
                && checkSelfPermission(Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {
            startResidentService();
        }

        updateServiceButton();
    }

    @Override
    protected void onPause() {
        if (receiverRegistered) {
            try {
                unregisterReceiver(stateReceiver);
            } catch (Exception ignored) { }
            receiverRegistered = false;
        }
        super.onPause();
    }

    private void startResidentService() {
        if (checkSelfPermission(Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            requestNeededPermissions();
            return;
        }

        CrashLogger.log(this, "UI start resident");
        Intent i = new Intent(this, CameraForegroundService.class);
        i.setAction(CameraForegroundService.ACTION_START);
        startForegroundService(i);
    }

    private void stopResidentService() {
        CrashLogger.log(this, "UI stop resident");
        Intent stop = new Intent(this, CameraForegroundService.class);
        stop.setAction(CameraForegroundService.ACTION_STOP_SERVICE);
        startService(stop);
    }

    private boolean isNotificationActive() {
        try {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null && Build.VERSION.SDK_INT >= 23) {
                for (android.service.notification.StatusBarNotification n
                        : nm.getActiveNotifications()) {
                    if (n.getId() == CameraForegroundService.NOTIFICATION_ID_PUBLIC) {
                        return true;
                    }
                }
            }
        } catch (Exception ignored) { }

        return getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).getBoolean(KEY_SERVICE_RUNNING, false);
    }

    private void updateServiceButton() {
        boolean running = isNotificationActive();

        getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).edit().putBoolean(KEY_SERVICE_RUNNING, running).apply();

        if (running) {
            startServiceButton.setText("常駐終了");
            startServiceButton.setBackgroundResource(R.drawable.button_red);
        } else {
            startServiceButton.setText("常駐開始");
            startServiceButton.setBackgroundResource(R.drawable.button_orange);
        }
        startServiceButton.setTextColor(android.graphics.Color.WHITE);
    }

    private void syncFloatingSwitch() {
        boolean enabled = getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).getBoolean(CameraForegroundService.KEY_FLOAT_ENABLED, false);

        if (enabled && !Settings.canDrawOverlays(this)) {
            enabled = false;
            getSharedPreferences(
                    CameraForegroundService.PREFS, MODE_PRIVATE
            ).edit()
                    .putBoolean(CameraForegroundService.KEY_FLOAT_ENABLED, false)
                    .apply();
        }

        changingFloatingSwitch = true;
        floatingSwitch.setChecked(enabled);
        changingFloatingSwitch = false;
    }

    private void setFloatingShutterEnabled(boolean enabled) {
        Intent i = new Intent(this, CameraForegroundService.class);
        i.setAction(enabled
                ? CameraForegroundService.ACTION_FLOAT_ON
                : CameraForegroundService.ACTION_FLOAT_OFF);
        startForegroundService(i);

        changingFloatingSwitch = true;
        floatingSwitch.setChecked(enabled);
        changingFloatingSwitch = false;
    }

    private void showDiagnosticReport() {
        CrashLogger.log(this, "UI diagnostic report opened");

        TextView text = new TextView(this);
        text.setText(CrashLogger.getReport(this));
        text.setTextSize(12f);
        text.setTextIsSelectable(true);
        text.setPadding(24, 16, 24, 16);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(text);

        new AlertDialog.Builder(this)
                .setTitle("FinderlessCamera 診断ログ")
                .setView(scroll)
                .setPositiveButton("閉じる", null)
                .setNegativeButton("ログ消去", (dialog, which) -> {
                    CrashLogger.clear(this);
                    status.setText("診断ログを消去しました。");
                })
                .show();
    }

    private void requestNeededPermissions() {
        List<String> perms = new ArrayList<>();

        if (checkSelfPermission(Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            perms.add(Manifest.permission.CAMERA);
        }

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS);
        }

        if (!perms.isEmpty()) {
            requestPermissions(perms.toArray(new String[0]), REQ_PERMS);
        }
    }
}
