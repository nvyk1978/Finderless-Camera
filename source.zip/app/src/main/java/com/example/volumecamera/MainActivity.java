package com.example.volumecamera;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.ImageFormat;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.util.Size;
import java.util.Arrays;
import java.util.Comparator;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.SeekBar;
import android.widget.TextView;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.os.VibrationEffect;
import android.os.Vibrator;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int UI_DARK_RED = android.graphics.Color.rgb(136, 34, 17);
    private static final String KEY_SERVICE_RUNNING = "service_running";
    private static final String KEY_NOTIFICATION_SWIPE_END = "notification_swipe_end";
    private static final String KEY_USE_FRONT_CAMERA = "use_front_camera";
    private static final String KEY_START_LAUNCHER_ON_APP_OPEN = "start_launcher_on_app_open";
    public static final String EXTRA_FORCE_SETTINGS = "force_show_settings";
    private static final String KEY_PEEK_MODE = "peek_mode";
    private static final String KEY_PEEK_PREV_FRONT = "peek_prev_front";
    private static final String KEY_PEEK_PREV_VIBRATION = "peek_prev_vibration";
    private static final String KEY_PEEK_PREV_FLOAT = "peek_prev_float";
    private static final int REQ_PERMS = 100;
    private static final int REQ_SAVE_FOLDER = 200;
    private static final String KEY_INTERRUPTION_SHOWN = "interruption_shown_session";

    private Button startServiceButton;
    private Button autoCaptureButton;
    private Button peekModeButton;

    private Switch floatingSwitch;
    private Switch miniFinderSwitch;
    private Switch shutterVibrationSwitch;
    private Switch gyroImageSwitch;
    private Switch frontCameraSwitch;
    private Switch startupLauncherSwitch;
    private TextView autofocusLabel;
    private TextView autofocusValue;
    private TextView imageQualityLabel;
    private TextView imageQualityValue;
    private TextView jpegQualityLabel, jpegQualityValue;
    private TextView imageAspectLabel, imageAspectValue;
    private TextView autoIntervalLabel, autoIntervalValue;
    private TextView burstLabel, burstValue;
    private Button afLowButton, afMidButton, afHighButton;
    private Button qualityLowButton, qualityMidButton, qualityHighButton;
    private Button jpegLowButton, jpegMidButton, jpegHighButton;
    private Button aspect43Button, aspect169Button, aspectDefaultButton;
    private Button interval3Button, interval5Button, interval10Button;
    private Button burstNoButton, burst3Button, burst5Button;
    private Button hideModeButton;
    private View completeExitFloating;
    private boolean exitDragging = false;
    private boolean exitLongPress = false;
    private float exitDownRawX, exitDownRawY, exitStartX, exitStartY;
    private Runnable exitLongPressRunnable;

    private boolean changingFloatingSwitch = false;
    private boolean changingMiniFinderSwitch = false;
    private boolean pendingOverlayPermission = false;
    private static final int PENDING_OVERLAY_NONE = 0;
    private static final int PENDING_OVERLAY_FLOAT = 1;
    private static final int PENDING_OVERLAY_MINI = 2;
    private int pendingOverlayTarget = PENDING_OVERLAY_NONE;
    private boolean receiverRegistered = false;
    private boolean applyingPeekMode = false;
    private boolean removeTaskAfterMonitorEnable = false;
    private boolean residentStartRequested = false;
    private boolean startupLauncherHandled = false;

    private final BroadcastReceiver stateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            syncFloatingSwitch();
            syncMiniFinderSwitch();
            // HIDE temporarily forces shutter vibration OFF. When HIDE exits, the
            // service restores the saved preference before broadcasting state changes,
            // so mirror that restored value back into the settings UI as well.
            if (shutterVibrationSwitch != null && !isPeekMode()) {
                boolean restoredVibration = getSharedPreferences(
                        CameraForegroundService.PREFS, MODE_PRIVATE
                ).getBoolean(CameraForegroundService.KEY_SHUTTER_VIBRATION, true);
                if (shutterVibrationSwitch.isChecked() != restoredVibration) {
                    shutterVibrationSwitch.setChecked(restoredVibration);
                }
            }
            updateServiceButton();
            updateAutoCaptureButton();
            updateSegmentUi(getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE).getInt(CameraForegroundService.KEY_AF_STRENGTH,1), getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE).getInt(CameraForegroundService.KEY_IMAGE_QUALITY,1));
            updateCameraInfo();
            updateSaveInfo();
            if (CameraForegroundService.ACTION_COMPLETE_EXIT_UI.equals(intent.getAction())) {
                finishCompletely();
                return;
            }
            if (CameraForegroundService.ACTION_HIDE_MODE_ACTIVATED.equals(intent.getAction())) {
                getWindow().getDecorView().postDelayed(() -> {
                    if (Build.VERSION.SDK_INT >= 21) finishAndRemoveTask();
                    else finish();
                }, 520L);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        CrashLogger.log(this, "ACTIVITY onCreate");

        android.content.SharedPreferences launchPrefs = getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        );
        boolean forceSettings = getIntent() != null
                && getIntent().getBooleanExtra(EXTRA_FORCE_SETTINGS, false);
        if (!forceSettings && launchPrefs.getBoolean(KEY_START_LAUNCHER_ON_APP_OPEN, false)) {
            // App-icon launch in launcher-only mode: do not display the settings Activity.
            // Explicit notification taps carry EXTRA_FORCE_SETTINGS and still open settings.
            if (launchPrefs.getBoolean(KEY_PEEK_MODE, false)) {
                Intent stopMonitor = new Intent(this, CameraForegroundService.class);
                stopMonitor.setAction(CameraForegroundService.ACTION_MONITOR_SHUTDOWN);
                startForegroundService(stopMonitor);
            }
            launchPrefs.edit().putBoolean(KEY_NOTIFICATION_SWIPE_END, false).apply();
            Intent launcher = new Intent(this, CameraForegroundService.class);
            launcher.setAction(CameraForegroundService.ACTION_START);
            startForegroundService(launcher);
            if (Build.VERSION.SDK_INT >= 21) finishAndRemoveTask();
            else finish();
            return;
        }

        setContentView(R.layout.activity_main);

        floatingSwitch = findViewById(R.id.floating_shutter_switch);
        miniFinderSwitch = findViewById(R.id.mini_finder_switch);
        shutterVibrationSwitch = findViewById(R.id.shutter_vibration);
        gyroImageSwitch = findViewById(R.id.gyro_image_orientation);
        frontCameraSwitch = findViewById(R.id.front_camera_switch);
        startupLauncherSwitch = findViewById(R.id.start_launcher_on_app_open);
        autofocusLabel = findViewById(R.id.autofocus_label);
        autofocusValue = findViewById(R.id.autofocus_value);
        imageQualityLabel = findViewById(R.id.image_quality_label);
        imageQualityValue = findViewById(R.id.image_quality_value);
        jpegQualityLabel = findViewById(R.id.jpeg_quality_label);
        jpegQualityValue = findViewById(R.id.jpeg_quality_value);
        afLowButton = findViewById(R.id.af_low);
        afMidButton = findViewById(R.id.af_mid);
        afHighButton = findViewById(R.id.af_high);
        qualityLowButton = findViewById(R.id.quality_low);
        qualityMidButton = findViewById(R.id.quality_mid);
        qualityHighButton = findViewById(R.id.quality_high);
        jpegLowButton = findViewById(R.id.jpeg_low);
        jpegMidButton = findViewById(R.id.jpeg_mid);
        jpegHighButton = findViewById(R.id.jpeg_high);
        imageAspectLabel = findViewById(R.id.image_aspect_label);
        imageAspectValue = findViewById(R.id.image_aspect_value);
        aspect43Button = findViewById(R.id.aspect_43);
        aspect169Button = findViewById(R.id.aspect_169);
        aspectDefaultButton = findViewById(R.id.aspect_default);
        autoIntervalLabel = findViewById(R.id.auto_interval_label);
        autoIntervalValue = findViewById(R.id.auto_interval_value);
        interval3Button = findViewById(R.id.interval_3);
        interval5Button = findViewById(R.id.interval_5);
        interval10Button = findViewById(R.id.interval_10);
        burstLabel = findViewById(R.id.burst_label);
        burstValue = findViewById(R.id.burst_value);
        burstNoButton = findViewById(R.id.burst_no);
        burst3Button = findViewById(R.id.burst_3);
        burst5Button = findViewById(R.id.burst_5);

        startServiceButton = findViewById(R.id.start_service);
        autoCaptureButton = findViewById(R.id.auto_capture_button);
        peekModeButton = findViewById(R.id.peek_mode_button);
        hideModeButton = findViewById(R.id.hide_mode_button);
        Button saveFolderButton = findViewById(R.id.change_save_folder);
        Button diagnostic = findViewById(R.id.show_diagnostic);
        completeExitFloating = findViewById(R.id.complete_exit_floating);


        requestNeededPermissions();
        bindSettings();
        // Opening the main app is the explicit escape from smartphone monitor mode.
        if (isPeekMode()) {
            shutdownMonitorModeCompletely();
        }
        showInterruptedCaptureIfNeeded();

        startServiceButton.setOnClickListener(v -> {
            if (isPeekMode()) {
                shutdownMonitorModeCompletely();
                return;
            }

            if (isResidentRunning()) {
                boolean floating = getSharedPreferences(
                        CameraForegroundService.PREFS, MODE_PRIVATE
                ).getBoolean(CameraForegroundService.KEY_FLOAT_ENABLED, false);

                if (floating) {
                    return;
                }

                stopResidentService();
            } else {
                startResidentService();
            }
        });

        autoCaptureButton.setOnClickListener(v -> {
            if (isPeekMode()) {
                shutdownMonitorModeCompletely();
                return;
            }

            boolean auto = getSharedPreferences(
                    CameraForegroundService.PREFS, MODE_PRIVATE
            ).getBoolean(CameraForegroundService.KEY_ENABLED, false);

            if (!auto && !isResidentRunning()) {
                startResidentService();
            }

            Intent i = new Intent(this, CameraForegroundService.class);
            i.setAction(CameraForegroundService.ACTION_TOGGLE);
            startForegroundService(i);
        });

        peekModeButton.setOnClickListener(v -> {
            if (isPeekMode()) shutdownMonitorModeCompletely();
            else setPeekMode(true);
        });
        hideModeButton.setOnClickListener(v -> activateHideMode());

        saveFolderButton.setOnClickListener(v -> chooseSaveFolder());
        diagnostic.setOnClickListener(v -> showDiagnosticReport());
        bindCompleteExitFloating();
    }

    private void bindSettings() {
        floatingSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (changingFloatingSwitch) return;

            if (isPeekMode()) {
                floatingSwitch.postDelayed(() -> applyPeekLockedStates(true), 120L);
                return;
            }

            if (isChecked && checkSelfPermission(Manifest.permission.CAMERA)
                    != PackageManager.PERMISSION_GRANTED) {
                changingFloatingSwitch = true;
                floatingSwitch.setChecked(false);
                changingFloatingSwitch = false;
                requestNeededPermissions();
                return;
            }

            if (isChecked && !Settings.canDrawOverlays(this)) {
                changingFloatingSwitch = true;
                floatingSwitch.setChecked(false);
                changingFloatingSwitch = false;
                pendingOverlayPermission = true;
                pendingOverlayTarget = PENDING_OVERLAY_FLOAT;
                Intent overlayIntent = new Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())
                );
                startActivity(overlayIntent);
                return;
            }

            setFloatingShutterEnabled(isChecked);
        });

        miniFinderSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (changingMiniFinderSwitch) return;
            if (isPeekMode()) {
                changingMiniFinderSwitch = true;
                miniFinderSwitch.setChecked(false);
                changingMiniFinderSwitch = false;
                return;
            }
            if (isChecked && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                changingMiniFinderSwitch = true;
                miniFinderSwitch.setChecked(false);
                changingMiniFinderSwitch = false;
                requestNeededPermissions();
                return;
            }
            if (isChecked && !Settings.canDrawOverlays(this)) {
                changingMiniFinderSwitch = true;
                miniFinderSwitch.setChecked(false);
                changingMiniFinderSwitch = false;
                pendingOverlayPermission = true;
                pendingOverlayTarget = PENDING_OVERLAY_MINI;
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
                return;
            }
            Intent i = new Intent(this, CameraForegroundService.class);
            i.setAction(isChecked ? CameraForegroundService.ACTION_MINI_FINDER_ON
                    : CameraForegroundService.ACTION_MINI_FINDER_OFF);
            startForegroundService(i);
        });

        shutterVibrationSwitch.setChecked(getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).getBoolean(CameraForegroundService.KEY_SHUTTER_VIBRATION, true));
        shutterVibrationSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (applyingPeekMode) return;
            if (isPeekMode()) {
                shutterVibrationSwitch.postDelayed(() -> applyPeekLockedStates(true), 120L);
                return;
            }
            getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                    .edit()
                    .putBoolean(CameraForegroundService.KEY_SHUTTER_VIBRATION, isChecked)
                    .apply();
        });

        gyroImageSwitch.setChecked(getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).getBoolean(CameraForegroundService.KEY_GYRO_IMAGE_ORIENTATION, true));
        gyroImageSwitch.setOnCheckedChangeListener((buttonView, isChecked) ->
                getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                        .edit()
                        .putBoolean(CameraForegroundService.KEY_GYRO_IMAGE_ORIENTATION, isChecked)
                        .apply()
        );

        frontCameraSwitch.setChecked(getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).getBoolean(KEY_USE_FRONT_CAMERA, false));
        frontCameraSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (applyingPeekMode) return;
            if (isPeekMode()) {
                frontCameraSwitch.postDelayed(() -> applyPeekLockedStates(true), 120L);
                return;
            }
            getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                    .edit()
                    .putBoolean(KEY_USE_FRONT_CAMERA, isChecked)
                    .apply();
            switchCameraIfActive();
            updateCameraInfo();
            updateSegmentUi(
                    getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                            .getInt(CameraForegroundService.KEY_AF_STRENGTH, 1),
                    getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                            .getInt(CameraForegroundService.KEY_IMAGE_QUALITY, 1)
            );
        });

        startupLauncherSwitch.setChecked(getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).getBoolean(KEY_START_LAUNCHER_ON_APP_OPEN, false));
        startupLauncherSwitch.setOnCheckedChangeListener((buttonView, isChecked) ->
                getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                        .edit()
                        .putBoolean(KEY_START_LAUNCHER_ON_APP_OPEN, isChecked)
                        .apply()
        );

        int afStrength = getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                .getInt(CameraForegroundService.KEY_AF_STRENGTH, 1);
        int quality = getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                .getInt(CameraForegroundService.KEY_IMAGE_QUALITY, 1);
        updateSegmentUi(afStrength, quality);

        afLowButton.setOnClickListener(v -> setAfStrength(0));
        afMidButton.setOnClickListener(v -> setAfStrength(1));
        afHighButton.setOnClickListener(v -> setAfStrength(2));
        qualityLowButton.setOnClickListener(v -> setImageQuality(0));
        qualityMidButton.setOnClickListener(v -> setImageQuality(1));
        qualityHighButton.setOnClickListener(v -> setImageQuality(2));
        jpegLowButton.setOnClickListener(v -> setJpegQuality(0));
        jpegMidButton.setOnClickListener(v -> setJpegQuality(1));
        jpegHighButton.setOnClickListener(v -> setJpegQuality(2));
        aspect43Button.setOnClickListener(v -> setImageAspect(0));
        aspect169Button.setOnClickListener(v -> setImageAspect(1));
        aspectDefaultButton.setOnClickListener(v -> setImageAspect(2));
        interval3Button.setOnClickListener(v -> setAutoInterval(3000));
        interval5Button.setOnClickListener(v -> setAutoInterval(5000));
        interval10Button.setOnClickListener(v -> setAutoInterval(10000));
        burstNoButton.setOnClickListener(v -> setBurstCount(1));
        burst3Button.setOnClickListener(v -> setBurstCount(3));
        burst5Button.setOnClickListener(v -> setBurstCount(5));
    }

    private void setAfStrength(int value) {
        if (isAutoCapturing()) return;
        getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE).edit()
                .putInt(CameraForegroundService.KEY_AF_STRENGTH, value).apply();
        updateSegmentUi(value, getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                .getInt(CameraForegroundService.KEY_IMAGE_QUALITY, 1));
    }

    private void setImageQuality(int value) {
        if (isAutoCapturing()) return;
        getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE).edit()
                .putInt(CameraForegroundService.KEY_IMAGE_QUALITY, value).apply();
        updateSegmentUi(getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                .getInt(CameraForegroundService.KEY_AF_STRENGTH, 1), value);
        if (isAnyCameraServiceUseActive()) {
            Intent i = new Intent(this, CameraForegroundService.class);
            i.setAction(CameraForegroundService.ACTION_REOPEN_CAMERA);
            startService(i);
        }
    }

    private void setImageAspect(int value) {
        if (isAutoCapturing()) return;

        getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                .edit()
                .putInt(CameraForegroundService.KEY_IMAGE_ASPECT, value)
                .apply();

        updateSegmentUi(
                getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                        .getInt(CameraForegroundService.KEY_AF_STRENGTH, 1),
                getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                        .getInt(CameraForegroundService.KEY_IMAGE_QUALITY, 1)
        );

        if (isAnyCameraServiceUseActive()) {
            Intent i = new Intent(this, CameraForegroundService.class);
            i.setAction(CameraForegroundService.ACTION_REOPEN_CAMERA);
            startService(i);
        }
    }

    private void setJpegQuality(int value) {
        if (isAutoCapturing()) return;
        getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE).edit()
                .putInt(CameraForegroundService.KEY_JPEG_QUALITY, value).apply();
        updateSegmentUi(
                getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE).getInt(CameraForegroundService.KEY_AF_STRENGTH, 1),
                getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE).getInt(CameraForegroundService.KEY_IMAGE_QUALITY, 1));
    }

    private void setAutoInterval(int intervalMs) {
        if (isAutoCapturing()) return;
        getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE).edit()
                .putInt(CameraForegroundService.KEY_AUTO_INTERVAL_MS, intervalMs).apply();
        updateSegmentUi(
                getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE).getInt(CameraForegroundService.KEY_AF_STRENGTH, 1),
                getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE).getInt(CameraForegroundService.KEY_IMAGE_QUALITY, 1));
    }

    private void setBurstCount(int count) {
        if (isAutoCapturing()) return;
        int normalized = count >= 5 ? 5 : (count >= 3 ? 3 : 1);
        getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE).edit()
                .putInt(CameraForegroundService.KEY_BURST_COUNT, normalized)
                .putBoolean(CameraForegroundService.KEY_BURST_ENABLED, normalized == 3)
                .apply();
        updateSegmentUi(
                getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE).getInt(CameraForegroundService.KEY_AF_STRENGTH, 1),
                getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE).getInt(CameraForegroundService.KEY_IMAGE_QUALITY, 1));
    }

    private boolean isAutoCapturing() {
        return getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                .getBoolean(CameraForegroundService.KEY_ENABLED, false);
    }

    private void updateSegmentUi(int af, int quality) {
        boolean live = !isAutoCapturing();

        Button[] afs={afLowButton,afMidButton,afHighButton};
        Button[] qs={qualityLowButton,qualityMidButton,qualityHighButton};
        Button[] jqs={jpegLowButton,jpegMidButton,jpegHighButton};
        Button[] ars={aspect43Button,aspect169Button,aspectDefaultButton};
        Button[] intervals={interval3Button,interval5Button,interval10Button};
        Button[] bursts={burstNoButton,burst3Button,burst5Button};

        int jq=getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                .getInt(CameraForegroundService.KEY_JPEG_QUALITY,2);
        int ar=getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                .getInt(CameraForegroundService.KEY_IMAGE_ASPECT,1);
        int intervalMs=getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                .getInt(CameraForegroundService.KEY_AUTO_INTERVAL_MS,5000);
        int intervalIndex=intervalMs >= 10000 ? 2 : (intervalMs <= 3000 ? 0 : 1);
        int burstCount=getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                .getInt(CameraForegroundService.KEY_BURST_COUNT, 1);
        int burstIndex=burstCount >= 5 ? 2 : (burstCount >= 3 ? 1 : 0);

        for(int i=0;i<3;i++){
            styleSegment(afs[i], i==af, live);
            styleSegment(qs[i], i==quality, live);
            styleSegment(jqs[i], i==jq, live);
            styleSegment(ars[i], i==ar, live);
            styleSegment(intervals[i], i==intervalIndex, live);
            styleSegment(bursts[i], i==burstIndex, live);
        }

        autofocusValue.setText(af <= 0 ? "0.5秒" : (af == 1 ? "1.0秒" : "1.8秒"));
        imageQualityValue.setText(getSelectedJpegResolutionText(quality));
        jpegQualityValue.setText(jq==0?"60":(jq==1?"80":"100"));

        int normal=android.graphics.Color.rgb(235,235,235);
        int disabled=android.graphics.Color.rgb(110,110,110);

        autofocusLabel.setTextColor(live?normal:disabled);
        autofocusValue.setTextColor(live?normal:disabled);
        imageQualityLabel.setTextColor(live?normal:disabled);
        imageQualityValue.setTextColor(live?normal:disabled);
        jpegQualityLabel.setTextColor(live?normal:disabled);
        jpegQualityValue.setTextColor(live?normal:disabled);
        imageAspectLabel.setTextColor(live?normal:disabled);
        imageAspectValue.setTextColor(live?normal:disabled);
        imageAspectValue.setText(ar == 2 ? getDefaultAspectExplanation() : "");
        autoIntervalLabel.setTextColor(live?normal:disabled);
        autoIntervalValue.setTextColor(live?normal:disabled);
        autoIntervalValue.setText("");
        burstLabel.setTextColor(live?normal:disabled);
        burstValue.setTextColor(live?normal:disabled);
        burstValue.setText("");
    }

    private String getSelectedJpegResolutionText(int quality) {
        try {
            CameraManager manager = getSystemService(CameraManager.class);
            if (manager == null) return "--";

            boolean front = getSharedPreferences(
                    CameraForegroundService.PREFS, MODE_PRIVATE
            ).getBoolean(KEY_USE_FRONT_CAMERA, false);

            int wantedFacing = front
                    ? CameraCharacteristics.LENS_FACING_FRONT
                    : CameraCharacteristics.LENS_FACING_BACK;

            int aspect = getSharedPreferences(
                    CameraForegroundService.PREFS, MODE_PRIVATE
            ).getInt(CameraForegroundService.KEY_IMAGE_ASPECT, 1);

            for (String id : manager.getCameraIdList()) {
                CameraCharacteristics c = manager.getCameraCharacteristics(id);
                Integer facing = c.get(CameraCharacteristics.LENS_FACING);
                if (facing == null || facing != wantedFacing) continue;

                StreamConfigurationMap map =
                        c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
                if (map == null) continue;

                Size[] sizes = map.getOutputSizes(ImageFormat.JPEG);
                if (sizes == null || sizes.length == 0) continue;

                java.util.List<Size> filtered = new java.util.ArrayList<>();
                if (aspect == 0 || aspect == 1) {
                    float target = aspect == 0 ? (4f / 3f) : (16f / 9f);
                    for (Size s : sizes) {
                        float r = Math.max(s.getWidth(), s.getHeight())
                                / (float)Math.min(s.getWidth(), s.getHeight());
                        if (Math.abs(r - target) < 0.02f) filtered.add(s);
                    }
                }

                Size[] sorted = filtered.isEmpty()
                        ? Arrays.copyOf(sizes, sizes.length)
                        : filtered.toArray(new Size[0]);

                Arrays.sort(sorted, Comparator.comparingLong(
                        s -> (long)s.getWidth() * s.getHeight()
                ));

                Size chosen;
                if (quality <= 0) {
                    chosen = sorted[0];
                    long targetArea = 1280L * 720L;
                    for (Size s : sorted) {
                        long area = (long)s.getWidth() * s.getHeight();
                        if (area <= targetArea) chosen = s;
                        else break;
                    }
                } else if (quality >= 2) {
                    chosen = sorted[sorted.length - 1];
                } else {
                    chosen = sorted[sorted.length / 2];
                }

                return chosen.getWidth() + "×" + chosen.getHeight();
            }
        } catch (Exception ignored) { }

        return "--";
    }

    private float getMonitorAspectRatio() {
        android.util.DisplayMetrics metrics = new android.util.DisplayMetrics();
        getWindowManager().getDefaultDisplay().getRealMetrics(metrics);
        int shortSide = Math.max(1, Math.min(metrics.widthPixels, metrics.heightPixels));
        int longSide = Math.max(1, Math.max(metrics.widthPixels, metrics.heightPixels));
        return longSide / (float)shortSide;
    }

    private String getSimplePortraitRatioText(float longToShort) {
        int bestShort = 1;
        int bestLong = 1;
        float bestError = Float.MAX_VALUE;

        // Prefer a readable small ratio, e.g. ~2.22 -> 9:20.
        for (int shortPart = 1; shortPart <= 20; shortPart++) {
            for (int longPart = shortPart; longPart <= 30; longPart++) {
                float candidate = longPart / (float)shortPart;
                float error = Math.abs(candidate - longToShort);
                if (error < bestError) {
                    bestError = error;
                    bestShort = shortPart;
                    bestLong = longPart;
                }
            }
        }
        return bestShort + ":" + bestLong;
    }

    private String getDefaultAspectExplanation() {
        try {
            CameraManager manager = getSystemService(CameraManager.class);
            if (manager == null) return "未取得";

            boolean front = getSharedPreferences(
                    CameraForegroundService.PREFS, MODE_PRIVATE
            ).getBoolean(KEY_USE_FRONT_CAMERA, false);

            int wantedFacing = front
                    ? CameraCharacteristics.LENS_FACING_FRONT
                    : CameraCharacteristics.LENS_FACING_BACK;

            float target = getMonitorAspectRatio();

            for (String id : manager.getCameraIdList()) {
                CameraCharacteristics c = manager.getCameraCharacteristics(id);
                Integer facing = c.get(CameraCharacteristics.LENS_FACING);
                if (facing == null || facing != wantedFacing) continue;

                StreamConfigurationMap map =
                        c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
                if (map == null) continue;

                Size[] sizes = map.getOutputSizes(ImageFormat.JPEG);
                if (sizes == null || sizes.length == 0) continue;

                float bestRatio = target;
                float bestError = Float.MAX_VALUE;
                for (Size s : sizes) {
                    if (s.getWidth() <= 0 || s.getHeight() <= 0) continue;
                    float r = Math.max(s.getWidth(), s.getHeight())
                            / (float)Math.min(s.getWidth(), s.getHeight());
                    float e = Math.abs(r - target);
                    if (e < bestError) {
                        bestError = e;
                        bestRatio = r;
                    }
                }
                return getSimplePortraitRatioText(bestRatio);
            }
        } catch (Exception ignored) { }

        return "未取得";
    }

    private void styleSegment(Button b, boolean selected, boolean enabled) {
        b.setEnabled(enabled);
        if(!enabled){
            b.setBackgroundResource(R.drawable.button_dark_gray);
            b.setTextColor(android.graphics.Color.rgb(110,110,110));
        } else if(selected){
            b.setBackgroundResource(R.drawable.button_blue);
            b.setTextColor(android.graphics.Color.WHITE);
        } else {
            b.setBackgroundResource(R.drawable.button_dark_gray);
            b.setTextColor(android.graphics.Color.rgb(235,235,235));
        }
    }

    private void showInterruptedCaptureIfNeeded() {
        android.content.SharedPreferences p=getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE);
        if (!p.getBoolean(CameraForegroundService.KEY_CAPTURE_SESSION_ACTIVE, false)) return;
        p.edit().putBoolean(CameraForegroundService.KEY_CAPTURE_SESSION_ACTIVE, false).apply();
        final android.app.Dialog d=new android.app.Dialog(this);
        TextView tv=new TextView(this);
        tv.setText("撮影が中断されました");
        tv.setTextSize(16f); tv.setTextColor(android.graphics.Color.WHITE);
        tv.setGravity(android.view.Gravity.CENTER);
        tv.setPadding(40,24,40,24);
        android.graphics.drawable.GradientDrawable bg=new android.graphics.drawable.GradientDrawable();
        bg.setColor(android.graphics.Color.rgb(45,45,45)); bg.setCornerRadius(48f); tv.setBackground(bg);
        d.setContentView(tv); d.setCancelable(true);
        android.view.Window win=d.getWindow();
        if(win!=null){ win.setBackgroundDrawableResource(android.R.color.transparent); win.clearFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND); }
        d.setOnShowListener(x->{ if(d.getWindow()!=null){ android.view.WindowManager.LayoutParams a=d.getWindow().getAttributes(); a.alpha=0f; d.getWindow().setAttributes(a); android.animation.ValueAnimator v=android.animation.ValueAnimator.ofFloat(0f,1f); v.setDuration(450); v.addUpdateListener(z->{ android.view.WindowManager.LayoutParams q=d.getWindow().getAttributes(); q.alpha=(float)z.getAnimatedValue(); d.getWindow().setAttributes(q);}); v.start(); }
            tv.postDelayed(()->{ if(!d.isShowing())return; tv.animate().alpha(0f).setDuration(650).withEndAction(d::dismiss).start(); },1800); });
        d.show();
    }

    private void activateHideMode() {
        Intent i=new Intent(this,CameraForegroundService.class);
        i.setAction(CameraForegroundService.ACTION_HIDE_MODE);
        startForegroundService(i);
    }

    @Override
    protected void onResume() {
        super.onResume();
        boolean exitedHideOnResume = false;
        android.content.SharedPreferences hidePrefs =
                getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE);
        if (hidePrefs.getBoolean(CameraForegroundService.KEY_HIDE_ACTIVE, false)) {
            exitedHideOnResume = true;
            Intent exitHide = new Intent(this, CameraForegroundService.class);
            exitHide.setAction(CameraForegroundService.ACTION_EXIT_HIDE);
            startService(exitHide);
        }
        if (!receiverRegistered) {
            IntentFilter filter = new IntentFilter();
            filter.addAction(CameraForegroundService.ACTION_FLOAT_STATE_CHANGED);
            filter.addAction(CameraForegroundService.ACTION_SERVICE_STATE_CHANGED);
            filter.addAction(CameraForegroundService.ACTION_AUTO_STATE_CHANGED);
            filter.addAction(CameraForegroundService.ACTION_CAMERA_STATE_CHANGED);
            filter.addAction(CameraForegroundService.ACTION_HIDE_MODE_ACTIVATED);
            filter.addAction(CameraForegroundService.ACTION_COMPLETE_EXIT_UI);
            registerReceiver(stateReceiver, filter, RECEIVER_NOT_EXPORTED);
            receiverRegistered = true;
        }

        if (pendingOverlayPermission && Settings.canDrawOverlays(this)) {
            int target = pendingOverlayTarget;
            pendingOverlayPermission = false;
            pendingOverlayTarget = PENDING_OVERLAY_NONE;
            if (target == PENDING_OVERLAY_MINI) {
                Intent mini = new Intent(this, CameraForegroundService.class);
                mini.setAction(CameraForegroundService.ACTION_MINI_FINDER_ON);
                startForegroundService(mini);
            } else if (target == PENDING_OVERLAY_FLOAT) {
                setFloatingShutterEnabled(true);
            }
        }

        recoverStaleFloatingState();
        syncFloatingSwitch();
        syncMiniFinderSwitch();
        if (exitedHideOnResume) {
            changingFloatingSwitch = true;
            floatingSwitch.setChecked(false);
            changingFloatingSwitch = false;
            changingMiniFinderSwitch = true;
            miniFinderSwitch.setChecked(false);
            changingMiniFinderSwitch = false;
        }

        if (isPeekMode()) {
            // A newly opened main Activity always terminates smartphone monitor mode.
            shutdownMonitorModeCompletely();
        }


        updateServiceButton();
        updateAutoCaptureButton();
        updateSegmentUi(getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE).getInt(CameraForegroundService.KEY_AF_STRENGTH,1), getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE).getInt(CameraForegroundService.KEY_IMAGE_QUALITY,1));
        updatePeekModeUi();
        updateCameraInfo();
        updateSaveInfo();
    }

    @Override
    protected void onPause() {
        if (receiverRegistered) {
            try {
                unregisterReceiver(stateReceiver);
            } catch (Exception ignored) { }
            receiverRegistered = false;
        }
        super.onPause();
    }

    private void maybeStartLauncherOnAppOpen(boolean modeExitInProgress) {
        if (startupLauncherHandled || startupLauncherSwitch == null || !startupLauncherSwitch.isChecked()) return;
        startupLauncherHandled = true;

        long delay = modeExitInProgress ? 650L : 120L;
        getWindow().getDecorView().postDelayed(() -> {
            if (isFinishing() || isDestroyed()) return;
            getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                    .edit()
                    .putBoolean(KEY_NOTIFICATION_SWIPE_END, false)
                    .apply();

            if (isResidentRunning()) {
                Intent show = new Intent(this, CameraForegroundService.class);
                show.setAction(CameraForegroundService.ACTION_SHOW_NOTIFICATION);
                startService(show);
            } else {
                startResidentService();
            }
        }, delay);
    }

    private void startResidentService() {
        if (checkSelfPermission(Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            requestNeededPermissions();
            return;
        }

        if (residentStartRequested || isResidentRunning()) {
            return;
        }

        residentStartRequested = true;
        getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).edit().putBoolean(KEY_SERVICE_RUNNING, true).apply();
        updateServiceButton();

        Intent i = new Intent(this, CameraForegroundService.class);
        i.setAction(CameraForegroundService.ACTION_START);
        startForegroundService(i);

        startServiceButton.postDelayed(() -> {
            residentStartRequested = false;
            updateServiceButton();
        }, 900L);
    }

    private void stopResidentService() {
        residentStartRequested = false;
        Intent stop = new Intent(this, CameraForegroundService.class);
        stop.setAction(CameraForegroundService.ACTION_STOP_SERVICE);
        startService(stop);
    }

    private boolean isResidentRunning() {
        // The notification launcher can be hidden independently from the camera
        // foreground service.  Do not use notification presence as service state.
        return getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).getBoolean(KEY_SERVICE_RUNNING, false);
    }

    private boolean isAnyCameraServiceUseActive() {
        boolean floating = getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).getBoolean(CameraForegroundService.KEY_FLOAT_ENABLED, false);

        boolean auto = getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).getBoolean(CameraForegroundService.KEY_ENABLED, false);

        // MINI finder is also an active camera-service user.  In particular,
        // immediately after returning from the overlay permission screen the
        // resident-running flag can still be catching up, while MINI is already
        // visible.  Treating MINI as active makes aspect/quality changes reach
        // the service on that very first run as well.
        boolean miniFinder = getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).getBoolean(CameraForegroundService.KEY_MINI_FINDER_ENABLED, false);

        return isResidentRunning() || floating || auto || miniFinder;
    }

    private void updateServiceButton() {
        boolean running = isResidentRunning();
        startServiceButton.setText(running ? "通知ランチャー停止" : "通知ランチャー起動");

        if (running) {
            startServiceButton.setBackgroundResource(R.drawable.button_dark_gray);
            startServiceButton.setTextColor(UI_DARK_RED);
        } else {
            startServiceButton.setBackgroundResource(R.drawable.button_orange);
            startServiceButton.setTextColor(android.graphics.Color.WHITE);
        }
    }

    private void updateAutoCaptureButton() {
        boolean auto = getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).getBoolean(CameraForegroundService.KEY_ENABLED, false);

        autoCaptureButton.setText(auto ? "STOP" : "AUTO");

        if (auto) {
            autoCaptureButton.setBackgroundResource(R.drawable.button_dark_gray);
            autoCaptureButton.setTextColor(UI_DARK_RED);
        } else {
            autoCaptureButton.setBackgroundResource(R.drawable.button_blue);
            autoCaptureButton.setTextColor(android.graphics.Color.WHITE);
        }
    }

    private boolean isPeekMode() {
        return getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                .getBoolean(KEY_PEEK_MODE, false);
    }

    private void setPeekMode(boolean enabled) {
        android.content.SharedPreferences prefs = getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        );

        if (enabled) {
            prefs.edit()
                    .putBoolean(KEY_PEEK_PREV_FRONT, prefs.getBoolean(KEY_USE_FRONT_CAMERA, false))
                    .putBoolean(KEY_PEEK_PREV_VIBRATION, prefs.getBoolean(CameraForegroundService.KEY_SHUTTER_VIBRATION, true))
                    .putBoolean(KEY_PEEK_PREV_FLOAT, prefs.getBoolean(CameraForegroundService.KEY_FLOAT_ENABLED, false))
                    .putBoolean(KEY_PEEK_MODE, true)
                    .apply();

            removeTaskAfterMonitorEnable = true;
            applyPeekLockedStates(true);
            ensureMonitorRuntime(true);
        } else {
            boolean front = prefs.getBoolean(KEY_PEEK_PREV_FRONT, false);
            boolean vibration = prefs.getBoolean(KEY_PEEK_PREV_VIBRATION, true);
            boolean floating = prefs.getBoolean(KEY_PEEK_PREV_FLOAT, false);

            prefs.edit()
                    .putBoolean(KEY_PEEK_MODE, false)
                    .putBoolean(KEY_USE_FRONT_CAMERA, front)
                    .putBoolean(CameraForegroundService.KEY_SHUTTER_VIBRATION, vibration)
                    .putBoolean(KEY_NOTIFICATION_SWIPE_END, false)
                    .putBoolean(CameraForegroundService.KEY_FLOAT_ENABLED, floating)
                    .apply();

            applyingPeekMode = true;
            frontCameraSwitch.setChecked(front);
            shutterVibrationSwitch.setChecked(vibration);
            applyingPeekMode = false;

            setFloatingShutterEnabled(floating);
            switchCameraIfActive();
            refreshNotificationIfActive();
        }

        updatePeekModeUi();
        updateCameraInfo();
    }

    private void ensureMonitorRuntime(boolean removeTaskWhenReady) {
        if (!isPeekMode()) return;

        if (!isResidentRunning()) {
            startResidentService();
        }

        boolean auto = getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).getBoolean(CameraForegroundService.KEY_ENABLED, false);

        if (!auto) {
            Intent autoIntent = new Intent(this, CameraForegroundService.class);
            autoIntent.setAction(CameraForegroundService.ACTION_AUTO_ON);
            startForegroundService(autoIntent);
        }

        if (removeTaskWhenReady || removeTaskAfterMonitorEnable) {
            removeTaskAfterMonitorEnable = false;
            getWindow().getDecorView().postDelayed(() -> {
                if (Build.VERSION.SDK_INT >= 21) {
                    finishAndRemoveTask();
                } else {
                    finish();
                }
            }, 450L);
        }
    }

    private void applyPeekLockedStates(boolean persist) {
        applyingPeekMode = true;
        frontCameraSwitch.setChecked(true);
        shutterVibrationSwitch.setChecked(false);
        changingFloatingSwitch = true;
        floatingSwitch.setChecked(false);
        changingFloatingSwitch = false;

        applyingPeekMode = false;

        if (persist) {
            getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                    .edit()
                    .putBoolean(KEY_USE_FRONT_CAMERA, true)
                    .putBoolean(CameraForegroundService.KEY_SHUTTER_VIBRATION, false)
                    .putBoolean(KEY_NOTIFICATION_SWIPE_END, true)
                    .putBoolean(CameraForegroundService.KEY_FLOAT_ENABLED, false)
                    .apply();

            Intent floatOff = new Intent(this, CameraForegroundService.class);
            floatOff.setAction(CameraForegroundService.ACTION_FLOAT_OFF);
            startForegroundService(floatOff);

            switchCameraIfActive();
            refreshNotificationIfActive();
        }
    }

    private void updatePeekModeUi() {
        boolean peek = isPeekMode();

        peekModeButton.setText(peek ? "スマホ監視モード中" : "スマホ監視モード");

        if (peek) {
            peekModeButton.setBackgroundResource(R.drawable.button_dark_gray);
            peekModeButton.setTextColor(UI_DARK_RED);
        } else {
            peekModeButton.setBackgroundResource(R.drawable.button_dark_red);
            peekModeButton.setTextColor(android.graphics.Color.WHITE);
        }

        applyPeekModeColors(peek);

        if (peek) {
            applyPeekLockedStates(false);
        }
    }

    private void applyPeekModeColors(boolean peek) {
        Switch[] allSwitches = new Switch[]{
                floatingSwitch,
                miniFinderSwitch,
                shutterVibrationSwitch,
                gyroImageSwitch,
                frontCameraSwitch,
                startupLauncherSwitch
        };

        Switch[] lockedSwitches = new Switch[]{
                floatingSwitch,
                shutterVibrationSwitch,
                frontCameraSwitch
        };

        int[][] states = new int[][]{
                new int[]{android.R.attr.state_checked},
                new int[]{-android.R.attr.state_checked}
        };

        if (peek) {
            ColorStateList normalThumb = new ColorStateList(
                    states,
                    new int[]{
                            android.graphics.Color.WHITE,
                            android.graphics.Color.WHITE
                    }
            );
            ColorStateList normalTrack = new ColorStateList(
                    states,
                    new int[]{
                            android.graphics.Color.rgb(68, 85, 119),
                            android.graphics.Color.rgb(42, 34, 34)
                    }
            );

            for (Switch item : allSwitches) {
                item.setThumbTintList(normalThumb);
                item.setTrackTintList(normalTrack);
            }

            ColorStateList red = ColorStateList.valueOf(
                    UI_DARK_RED
            );

            for (Switch item : lockedSwitches) {
                item.setTextColor(android.graphics.Color.WHITE);
                item.setThumbTintList(ColorStateList.valueOf(android.graphics.Color.WHITE));
                item.setTrackTintList(red);
            }
        } else {
            ColorStateList normalThumb = new ColorStateList(
                    states,
                    new int[]{
                            android.graphics.Color.WHITE,
                            android.graphics.Color.WHITE
                    }
            );
            ColorStateList normalTrack = new ColorStateList(
                    states,
                    new int[]{
                            android.graphics.Color.rgb(68, 85, 119),
                            android.graphics.Color.rgb(42, 34, 34)
                    }
            );

            int normalTextColor = shutterVibrationSwitch.getCurrentTextColor();

            for (Switch item : allSwitches) {
                item.setThumbTintList(normalThumb);
                item.setTrackTintList(normalTrack);
            }

            for (Switch item : lockedSwitches) {
                item.setTextColor(normalTextColor);
            }
        }
    }

    private void refreshNotificationIfActive() {
        if (!isAnyCameraServiceUseActive()) return;
        Intent i = new Intent(this, CameraForegroundService.class);
        i.setAction(CameraForegroundService.ACTION_REFRESH_NOTIFICATION);
        startForegroundService(i);
    }

    private void switchCameraIfActive() {
        if (!isAnyCameraServiceUseActive()) return;
        Intent i = new Intent(this, CameraForegroundService.class);
        i.setAction(CameraForegroundService.ACTION_SWITCH_CAMERA);
        startForegroundService(i);
    }

    private void syncFloatingSwitch() {
        boolean enabled = getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).getBoolean(CameraForegroundService.KEY_FLOAT_ENABLED, false);

        if (enabled && !Settings.canDrawOverlays(this)) {
            enabled = false;
            getSharedPreferences(
                    CameraForegroundService.PREFS, MODE_PRIVATE
            ).edit()
                    .putBoolean(CameraForegroundService.KEY_FLOAT_ENABLED, false)
                    .apply();
        }

        changingFloatingSwitch = true;
        floatingSwitch.setChecked(enabled);
        changingFloatingSwitch = false;
    }

    private void syncMiniFinderSwitch() {
        boolean enabled = getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                .getBoolean(CameraForegroundService.KEY_MINI_FINDER_ENABLED, false);
        if (enabled && !Settings.canDrawOverlays(this)) {
            enabled = false;
            getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE).edit()
                    .putBoolean(CameraForegroundService.KEY_MINI_FINDER_ENABLED, false).apply();
        }
        changingMiniFinderSwitch = true;
        miniFinderSwitch.setChecked(enabled);
        changingMiniFinderSwitch = false;
    }

    private void setFloatingShutterEnabled(boolean enabled) {
        Intent i = new Intent(this, CameraForegroundService.class);
        i.setAction(enabled
                ? CameraForegroundService.ACTION_FLOAT_ON
                : CameraForegroundService.ACTION_FLOAT_OFF);
        startForegroundService(i);

        changingFloatingSwitch = true;
        floatingSwitch.setChecked(enabled);
        changingFloatingSwitch = false;
        updateServiceButton();
    }

    private void updateCameraInfo() { }

    private void updateSaveInfo() { }

    private void chooseSaveFolder() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION
                        | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                        | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                        | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
        );
        startActivityForResult(intent, REQ_SAVE_FOLDER);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode != REQ_SAVE_FOLDER
                || resultCode != RESULT_OK
                || data == null
                || data.getData() == null) {
            return;
        }

        Uri treeUri = data.getData();

        try {
            int takeFlags = data.getFlags()
                    & (Intent.FLAG_GRANT_READ_URI_PERMISSION
                    | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            getContentResolver().takePersistableUriPermission(treeUri, takeFlags);
        } catch (Exception ignored) { }

        String displayName = Uri.decode(treeUri.getLastPathSegment());
        if (displayName == null || displayName.trim().isEmpty()) {
            displayName = "選択したフォルダ";
        } else {
            int colon = displayName.lastIndexOf(':');
            if (colon >= 0 && colon < displayName.length() - 1) {
                displayName = displayName.substring(colon + 1);
            }
            int slash = displayName.lastIndexOf('/');
            if (slash >= 0 && slash < displayName.length() - 1) {
                displayName = displayName.substring(slash + 1);
            }
        }

        getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).edit()
                .putString(CameraForegroundService.KEY_SAVE_FOLDER_URI, treeUri.toString())
                .putString(CameraForegroundService.KEY_SAVE_FOLDER_NAME, displayName)
                .apply();

        updateSaveInfo();
    }

    private void recoverStaleFloatingState() {
        android.content.SharedPreferences prefs = getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        );

        boolean requested = prefs.getBoolean(
                CameraForegroundService.KEY_FLOAT_ENABLED, false
        );
        boolean overlayAlive = prefs.getBoolean(
                CameraForegroundService.KEY_FLOAT_OVERLAY_ALIVE, false
        );

        if (requested && !overlayAlive) {
            prefs.edit()
                    .putBoolean(CameraForegroundService.KEY_FLOAT_ENABLED, false)
                    .apply();
        }
    }

    private void shutdownMonitorModeCompletely() {
        android.content.SharedPreferences prefs = getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        );

        boolean front = prefs.getBoolean(KEY_PEEK_PREV_FRONT, false);
        boolean vibration = prefs.getBoolean(KEY_PEEK_PREV_VIBRATION, true);
        boolean floating = prefs.getBoolean(KEY_PEEK_PREV_FLOAT, false);

        prefs.edit()
                .putBoolean(KEY_PEEK_MODE, false)
                .putBoolean(CameraForegroundService.KEY_ENABLED, false)
                .putBoolean(KEY_SERVICE_RUNNING, false)
                .putBoolean(KEY_USE_FRONT_CAMERA, front)
                .putBoolean(CameraForegroundService.KEY_SHUTTER_VIBRATION, vibration)
                .putBoolean(KEY_NOTIFICATION_SWIPE_END, false)
                .putBoolean(CameraForegroundService.KEY_FLOAT_ENABLED, false)
                .apply();

        applyingPeekMode = true;
        frontCameraSwitch.setChecked(front);
        shutterVibrationSwitch.setChecked(vibration);
        changingFloatingSwitch = true;
        floatingSwitch.setChecked(false);
        changingFloatingSwitch = false;
        applyingPeekMode = false;

        residentStartRequested = false;

        Intent stop = new Intent(this, CameraForegroundService.class);
        stop.setAction(CameraForegroundService.ACTION_MONITOR_SHUTDOWN);
        startService(stop);

        updatePeekModeUi();
        updateAutoCaptureButton();
        updateServiceButton();
        updateCameraInfo();
    }

    private void showDiagnosticReport() {
        TextView text = new TextView(this);
        text.setText(CrashLogger.getReport(this));
        text.setTextSize(12f);
        text.setTextIsSelectable(true);
        text.setPadding(24, 16, 24, 16);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(text);

        new AlertDialog.Builder(this)
                .setTitle("FinderlessCamera 診断ログ")
                .setView(scroll)
                .setPositiveButton("閉じる", null)
                .setNegativeButton("ログ消去", (dialog, which) ->
                        CrashLogger.clear(this)
                )
                .show();
    }

    private void requestNeededPermissions() {
        List<String> perms = new ArrayList<>();

        if (checkSelfPermission(Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            perms.add(Manifest.permission.CAMERA);
        }

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS);
        }

        if (!perms.isEmpty()) {
            requestPermissions(perms.toArray(new String[0]), REQ_PERMS);
        }
    }
    private void bindCompleteExitFloating() {
        if (completeExitFloating == null) return;
        completeExitFloating.setOnTouchListener((v, event) -> {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    exitDragging = false;
                    exitLongPress = false;
                    exitDownRawX = event.getRawX();
                    exitDownRawY = event.getRawY();
                    exitStartX = v.getX();
                    exitStartY = v.getY();
                    exitLongPressRunnable = () -> {
                        exitLongPress = true;
                        exitDragging = true;
                        vibrateExitLongPress();
                        v.animate().cancel();
                        v.animate().scaleX(1.18f).scaleY(1.18f).setDuration(45L)
                                .setInterpolator(new AccelerateInterpolator())
                                .withEndAction(() -> v.animate().scaleX(1f).scaleY(1f)
                                        .setDuration(155L).setInterpolator(new DecelerateInterpolator()).start())
                                .start();
                    };
                    v.postDelayed(exitLongPressRunnable, 250L);
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float dx = event.getRawX() - exitDownRawX;
                    float dy = event.getRawY() - exitDownRawY;
                    if (!exitLongPress && (Math.abs(dx) > 24f || Math.abs(dy) > 24f)) {
                        if (exitLongPressRunnable != null) v.removeCallbacks(exitLongPressRunnable);
                    }
                    if (exitDragging) {
                        View parent = (View) v.getParent();
                        float nx = Math.max(0f, Math.min(exitStartX + dx, parent.getWidth() - v.getWidth()));
                        float ny = Math.max(0f, Math.min(exitStartY + dy, parent.getHeight() - v.getHeight()));
                        v.setX(nx);
                        v.setY(ny);
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (exitLongPressRunnable != null) v.removeCallbacks(exitLongPressRunnable);
                    if (event.getActionMasked() == MotionEvent.ACTION_UP && !exitLongPress && !exitDragging) {
                        animateCompleteExit();
                    }
                    exitDragging = false;
                    exitLongPress = false;
                    return true;
            }
            return false;
        });
    }

    private void vibrateExitLongPress() {
        Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        if (vibrator == null || !vibrator.hasVibrator()) return;
        if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createOneShot(40L, 200));
        else vibrator.vibrate(40L);
    }

    private void animateCompleteExit() {
        if (completeExitFloating == null) {
            requestCompleteExit();
            return;
        }
        completeExitFloating.animate().cancel();
        completeExitFloating.animate()
                .scaleX(3f).scaleY(3f).alpha(0f)
                .setDuration(200L)
                .setInterpolator(new AccelerateInterpolator(2.0f))
                .withEndAction(this::requestCompleteExit)
                .start();
    }

    private void requestCompleteExit() {
        Intent i = new Intent(this, CameraForegroundService.class);
        i.setAction(CameraForegroundService.ACTION_COMPLETE_EXIT);
        try { startService(i); } catch (Exception ignored) { }
        getWindow().getDecorView().postDelayed(this::finishCompletely, 80L);
    }

    private void finishCompletely() {
        if (Build.VERSION.SDK_INT >= 21) finishAndRemoveTask();
        else finish();
    }

}
