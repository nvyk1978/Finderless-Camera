package com.example.volumecamera;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final String KEY_SERVICE_RUNNING = "service_running";
    private static final String KEY_AUTO_START_RESIDENT = "auto_start_resident";
    private static final String KEY_NOTIFICATION_SWIPE_END = "notification_swipe_end";
    private static final String KEY_USE_FRONT_CAMERA = "use_front_camera";
    private static final String KEY_PEEK_MODE = "peek_mode";
    private static final String KEY_PEEK_PREV_FRONT = "peek_prev_front";
    private static final String KEY_PEEK_PREV_VIBRATION = "peek_prev_vibration";
    private static final String KEY_PEEK_PREV_SWIPE = "peek_prev_swipe";
    private static final String KEY_PEEK_PREV_FLOAT = "peek_prev_float";
    private static final int REQ_PERMS = 100;
    private static final int REQ_SAVE_FOLDER = 200;

    private Button startServiceButton;
    private Button autoCaptureButton;
    private Button peekModeButton;
    private TextView cameraInfo;
    private TextView saveInfo;

    private Switch floatingSwitch;
    private Switch burstSwitch;
    private Switch shutterVibrationSwitch;
    private Switch autoStartResidentSwitch;
    private Switch notificationSwipeSwitch;
    private Switch frontCameraSwitch;

    private boolean changingFloatingSwitch = false;
    private boolean pendingOverlayPermission = false;
    private boolean receiverRegistered = false;
    private boolean applyingPeekMode = false;
    private boolean removeTaskAfterMonitorEnable = false;

    private final BroadcastReceiver stateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            syncFloatingSwitch();
            updateServiceButton();
            updateAutoCaptureButton();
            updateCameraInfo();
            updateSaveInfo();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        CrashLogger.log(this, "ACTIVITY onCreate");
        setContentView(R.layout.activity_main);

        floatingSwitch = findViewById(R.id.floating_shutter_switch);
        burstSwitch = findViewById(R.id.burst_shot_switch);
        shutterVibrationSwitch = findViewById(R.id.shutter_vibration);
        autoStartResidentSwitch = findViewById(R.id.auto_start_resident);
        notificationSwipeSwitch = findViewById(R.id.notification_swipe_end);
        frontCameraSwitch = findViewById(R.id.front_camera_switch);

        startServiceButton = findViewById(R.id.start_service);
        autoCaptureButton = findViewById(R.id.auto_capture_button);
        peekModeButton = findViewById(R.id.peek_mode_button);
        Button saveFolderButton = findViewById(R.id.change_save_folder);
        Button diagnostic = findViewById(R.id.show_diagnostic);

        cameraInfo = findViewById(R.id.camera_info);
        saveInfo = findViewById(R.id.save_info);

        requestNeededPermissions();
        bindSettings();

        startServiceButton.setOnClickListener(v -> {
            if (isResidentRunning()) {
                boolean floating = getSharedPreferences(
                        CameraForegroundService.PREFS, MODE_PRIVATE
                ).getBoolean(CameraForegroundService.KEY_FLOAT_ENABLED, false);

                if (floating) {
                    return;
                }

                stopResidentService();
            } else {
                startResidentService();
            }
        });

        autoCaptureButton.setOnClickListener(v -> {
            boolean auto = getSharedPreferences(
                    CameraForegroundService.PREFS, MODE_PRIVATE
            ).getBoolean(CameraForegroundService.KEY_ENABLED, false);

            if (!auto && !isResidentRunning()) {
                startResidentService();
            }

            Intent i = new Intent(this, CameraForegroundService.class);
            i.setAction(CameraForegroundService.ACTION_TOGGLE);
            startForegroundService(i);
        });

        peekModeButton.setOnClickListener(v -> setPeekMode(!isPeekMode()));

        saveFolderButton.setOnClickListener(v -> chooseSaveFolder());
        diagnostic.setOnClickListener(v -> showDiagnosticReport());
    }

    private void bindSettings() {
        floatingSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (changingFloatingSwitch) return;

            if (isPeekMode()) {
                floatingSwitch.postDelayed(() -> applyPeekLockedStates(true), 120L);
                return;
            }

            if (isChecked && checkSelfPermission(Manifest.permission.CAMERA)
                    != PackageManager.PERMISSION_GRANTED) {
                changingFloatingSwitch = true;
                floatingSwitch.setChecked(false);
                changingFloatingSwitch = false;
                requestNeededPermissions();
                return;
            }

            if (isChecked && !Settings.canDrawOverlays(this)) {
                changingFloatingSwitch = true;
                floatingSwitch.setChecked(false);
                changingFloatingSwitch = false;
                pendingOverlayPermission = true;
                Intent overlayIntent = new Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())
                );
                startActivity(overlayIntent);
                return;
            }

            setFloatingShutterEnabled(isChecked);
        });

        burstSwitch.setChecked(getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).getBoolean(CameraForegroundService.KEY_BURST_ENABLED, false));
        burstSwitch.setOnCheckedChangeListener((buttonView, isChecked) ->
                getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                        .edit()
                        .putBoolean(CameraForegroundService.KEY_BURST_ENABLED, isChecked)
                        .apply()
        );

        shutterVibrationSwitch.setChecked(getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).getBoolean(CameraForegroundService.KEY_SHUTTER_VIBRATION, true));
        shutterVibrationSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (applyingPeekMode) return;
            if (isPeekMode()) {
                shutterVibrationSwitch.postDelayed(() -> applyPeekLockedStates(true), 120L);
                return;
            }
            getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                    .edit()
                    .putBoolean(CameraForegroundService.KEY_SHUTTER_VIBRATION, isChecked)
                    .apply();
        });

        autoStartResidentSwitch.setChecked(getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).getBoolean(KEY_AUTO_START_RESIDENT, false));
        autoStartResidentSwitch.setOnCheckedChangeListener((buttonView, isChecked) ->
                getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                        .edit()
                        .putBoolean(KEY_AUTO_START_RESIDENT, isChecked)
                        .apply()
        );

        notificationSwipeSwitch.setChecked(getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).getBoolean(KEY_NOTIFICATION_SWIPE_END, true));
        notificationSwipeSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (applyingPeekMode) return;
            if (isPeekMode()) {
                notificationSwipeSwitch.postDelayed(() -> applyPeekLockedStates(true), 120L);
                return;
            }
            getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                    .edit()
                    .putBoolean(KEY_NOTIFICATION_SWIPE_END, isChecked)
                    .apply();
            refreshNotificationIfActive();
        });

        frontCameraSwitch.setChecked(getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).getBoolean(KEY_USE_FRONT_CAMERA, false));
        frontCameraSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (applyingPeekMode) return;
            if (isPeekMode()) {
                frontCameraSwitch.postDelayed(() -> applyPeekLockedStates(true), 120L);
                return;
            }
            getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                    .edit()
                    .putBoolean(KEY_USE_FRONT_CAMERA, isChecked)
                    .apply();
            switchCameraIfActive();
            updateCameraInfo();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (!receiverRegistered) {
            IntentFilter filter = new IntentFilter();
            filter.addAction(CameraForegroundService.ACTION_FLOAT_STATE_CHANGED);
            filter.addAction(CameraForegroundService.ACTION_SERVICE_STATE_CHANGED);
            filter.addAction(CameraForegroundService.ACTION_AUTO_STATE_CHANGED);
            filter.addAction(CameraForegroundService.ACTION_CAMERA_STATE_CHANGED);
            registerReceiver(stateReceiver, filter, RECEIVER_NOT_EXPORTED);
            receiverRegistered = true;
        }

        if (pendingOverlayPermission && Settings.canDrawOverlays(this)) {
            pendingOverlayPermission = false;
            setFloatingShutterEnabled(true);
        }

        syncFloatingSwitch();

        if (isPeekMode()) {
            applyPeekLockedStates(true);
            ensureMonitorRuntime(false);
        } else {
            boolean autoStart = getSharedPreferences(
                    CameraForegroundService.PREFS, MODE_PRIVATE
            ).getBoolean(KEY_AUTO_START_RESIDENT, false);

            if (autoStart
                    && !isResidentRunning()
                    && checkSelfPermission(Manifest.permission.CAMERA)
                    == PackageManager.PERMISSION_GRANTED) {
                startResidentService();
            }
        }

        updateServiceButton();
        updateAutoCaptureButton();
        updatePeekModeUi();
        updateCameraInfo();
        updateSaveInfo();
    }

    @Override
    protected void onPause() {
        if (receiverRegistered) {
            try {
                unregisterReceiver(stateReceiver);
            } catch (Exception ignored) { }
            receiverRegistered = false;
        }
        super.onPause();
    }

    private void startResidentService() {
        if (checkSelfPermission(Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            requestNeededPermissions();
            return;
        }

        Intent i = new Intent(this, CameraForegroundService.class);
        i.setAction(CameraForegroundService.ACTION_START);
        startForegroundService(i);
    }

    private void stopResidentService() {
        Intent stop = new Intent(this, CameraForegroundService.class);
        stop.setAction(CameraForegroundService.ACTION_STOP_SERVICE);
        startService(stop);
    }

    private boolean isResidentRunning() {
        boolean pref = getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).getBoolean(KEY_SERVICE_RUNNING, false);

        if (!pref) return false;

        try {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null && Build.VERSION.SDK_INT >= 23) {
                for (android.service.notification.StatusBarNotification n
                        : nm.getActiveNotifications()) {
                    if (n.getId() == CameraForegroundService.NOTIFICATION_ID_PUBLIC) {
                        return true;
                    }
                }

                getSharedPreferences(
                        CameraForegroundService.PREFS, MODE_PRIVATE
                ).edit().putBoolean(KEY_SERVICE_RUNNING, false).apply();
                return false;
            }
        } catch (Exception ignored) { }

        return pref;
    }

    private boolean isAnyCameraServiceUseActive() {
        boolean floating = getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).getBoolean(CameraForegroundService.KEY_FLOAT_ENABLED, false);

        boolean auto = getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).getBoolean(CameraForegroundService.KEY_ENABLED, false);

        return isResidentRunning() || floating || auto;
    }

    private void updateServiceButton() {
        boolean running = isResidentRunning();
        startServiceButton.setText(running ? "常駐終了" : "常駐開始");

        if (running) {
            startServiceButton.setBackgroundResource(R.drawable.button_dark_gray);
            startServiceButton.setTextColor(android.graphics.Color.RED);
        } else {
            startServiceButton.setBackgroundResource(R.drawable.button_orange);
            startServiceButton.setTextColor(android.graphics.Color.WHITE);
        }
    }

    private void updateAutoCaptureButton() {
        boolean auto = getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).getBoolean(CameraForegroundService.KEY_ENABLED, false);

        autoCaptureButton.setText(auto ? "STOP" : "AUTO");

        if (auto) {
            autoCaptureButton.setBackgroundResource(R.drawable.button_dark_gray);
            autoCaptureButton.setTextColor(android.graphics.Color.RED);
        } else {
            autoCaptureButton.setBackgroundResource(R.drawable.button_blue);
            autoCaptureButton.setTextColor(android.graphics.Color.WHITE);
        }
    }

    private boolean isPeekMode() {
        return getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                .getBoolean(KEY_PEEK_MODE, false);
    }

    private void setPeekMode(boolean enabled) {
        android.content.SharedPreferences prefs = getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        );

        if (enabled) {
            prefs.edit()
                    .putBoolean(KEY_PEEK_PREV_FRONT, prefs.getBoolean(KEY_USE_FRONT_CAMERA, false))
                    .putBoolean(KEY_PEEK_PREV_VIBRATION, prefs.getBoolean(CameraForegroundService.KEY_SHUTTER_VIBRATION, true))
                    .putBoolean(KEY_PEEK_PREV_SWIPE, prefs.getBoolean(KEY_NOTIFICATION_SWIPE_END, true))
                    .putBoolean(KEY_PEEK_PREV_FLOAT, prefs.getBoolean(CameraForegroundService.KEY_FLOAT_ENABLED, false))
                    .putBoolean(KEY_PEEK_MODE, true)
                    .apply();

            removeTaskAfterMonitorEnable = true;
            applyPeekLockedStates(true);
            ensureMonitorRuntime(true);
        } else {
            boolean front = prefs.getBoolean(KEY_PEEK_PREV_FRONT, false);
            boolean vibration = prefs.getBoolean(KEY_PEEK_PREV_VIBRATION, true);
            boolean swipe = prefs.getBoolean(KEY_PEEK_PREV_SWIPE, true);
            boolean floating = prefs.getBoolean(KEY_PEEK_PREV_FLOAT, false);

            prefs.edit()
                    .putBoolean(KEY_PEEK_MODE, false)
                    .putBoolean(KEY_USE_FRONT_CAMERA, front)
                    .putBoolean(CameraForegroundService.KEY_SHUTTER_VIBRATION, vibration)
                    .putBoolean(KEY_NOTIFICATION_SWIPE_END, swipe)
                    .putBoolean(CameraForegroundService.KEY_FLOAT_ENABLED, floating)
                    .apply();

            applyingPeekMode = true;
            frontCameraSwitch.setChecked(front);
            shutterVibrationSwitch.setChecked(vibration);
            notificationSwipeSwitch.setChecked(swipe);
            applyingPeekMode = false;

            setFloatingShutterEnabled(floating);
            switchCameraIfActive();
            refreshNotificationIfActive();
        }

        updatePeekModeUi();
        updateCameraInfo();
    }

    private void ensureMonitorRuntime(boolean removeTaskWhenReady) {
        if (!isPeekMode()) return;

        if (!isResidentRunning()) {
            startResidentService();
        }

        boolean auto = getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).getBoolean(CameraForegroundService.KEY_ENABLED, false);

        if (!auto) {
            Intent autoIntent = new Intent(this, CameraForegroundService.class);
            autoIntent.setAction(CameraForegroundService.ACTION_AUTO_ON);
            startForegroundService(autoIntent);
        }

        if (removeTaskWhenReady || removeTaskAfterMonitorEnable) {
            removeTaskAfterMonitorEnable = false;
            getWindow().getDecorView().postDelayed(() -> {
                if (Build.VERSION.SDK_INT >= 21) {
                    finishAndRemoveTask();
                } else {
                    finish();
                }
            }, 450L);
        }
    }

    private void applyPeekLockedStates(boolean persist) {
        applyingPeekMode = true;
        frontCameraSwitch.setChecked(true);
        shutterVibrationSwitch.setChecked(false);
        notificationSwipeSwitch.setChecked(true);

        changingFloatingSwitch = true;
        floatingSwitch.setChecked(false);
        changingFloatingSwitch = false;

        applyingPeekMode = false;

        if (persist) {
            getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                    .edit()
                    .putBoolean(KEY_USE_FRONT_CAMERA, true)
                    .putBoolean(CameraForegroundService.KEY_SHUTTER_VIBRATION, false)
                    .putBoolean(KEY_NOTIFICATION_SWIPE_END, true)
                    .putBoolean(CameraForegroundService.KEY_FLOAT_ENABLED, false)
                    .apply();

            Intent floatOff = new Intent(this, CameraForegroundService.class);
            floatOff.setAction(CameraForegroundService.ACTION_FLOAT_OFF);
            startForegroundService(floatOff);

            switchCameraIfActive();
            refreshNotificationIfActive();
        }
    }

    private void updatePeekModeUi() {
        boolean peek = isPeekMode();

        peekModeButton.setText(peek ? "スマホ監視モード中" : "スマホ監視モード");

        if (peek) {
            peekModeButton.setBackgroundResource(R.drawable.button_dark_gray);
            peekModeButton.setTextColor(android.graphics.Color.RED);
        } else {
            peekModeButton.setBackgroundResource(R.drawable.button_dark_red);
            peekModeButton.setTextColor(android.graphics.Color.WHITE);
        }

        applyPeekModeColors(peek);

        if (peek) {
            applyPeekLockedStates(false);
        }
    }

    private void applyPeekModeColors(boolean peek) {
        Switch[] allSwitches = new Switch[]{
                floatingSwitch,
                burstSwitch,
                shutterVibrationSwitch,
                autoStartResidentSwitch,
                notificationSwipeSwitch,
                frontCameraSwitch
        };

        Switch[] lockedSwitches = new Switch[]{
                floatingSwitch,
                shutterVibrationSwitch,
                notificationSwipeSwitch,
                frontCameraSwitch
        };

        int[][] states = new int[][]{
                new int[]{android.R.attr.state_checked},
                new int[]{-android.R.attr.state_checked}
        };

        if (peek) {
            ColorStateList normalThumb = new ColorStateList(
                    states,
                    new int[]{
                            android.graphics.Color.rgb(25, 118, 210),
                            android.graphics.Color.WHITE
                    }
            );
            ColorStateList normalTrack = new ColorStateList(
                    states,
                    new int[]{
                            android.graphics.Color.rgb(100, 181, 246),
                            android.graphics.Color.rgb(117, 117, 117)
                    }
            );

            for (Switch item : allSwitches) {
                item.setThumbTintList(normalThumb);
                item.setTrackTintList(normalTrack);
            }

            ColorStateList red = ColorStateList.valueOf(
                    android.graphics.Color.rgb(220, 45, 45)
            );

            for (Switch item : lockedSwitches) {
                item.setTextColor(android.graphics.Color.rgb(220, 45, 45));
                item.setThumbTintList(red);
                item.setTrackTintList(red);
            }
        } else {
            ColorStateList normalThumb = new ColorStateList(
                    states,
                    new int[]{
                            android.graphics.Color.rgb(25, 118, 210),
                            android.graphics.Color.WHITE
                    }
            );
            ColorStateList normalTrack = new ColorStateList(
                    states,
                    new int[]{
                            android.graphics.Color.rgb(100, 181, 246),
                            android.graphics.Color.rgb(117, 117, 117)
                    }
            );

            int normalTextColor = burstSwitch.getCurrentTextColor();

            for (Switch item : allSwitches) {
                item.setThumbTintList(normalThumb);
                item.setTrackTintList(normalTrack);
            }

            for (Switch item : lockedSwitches) {
                item.setTextColor(normalTextColor);
            }
        }
    }

    private void refreshNotificationIfActive() {
        if (!isAnyCameraServiceUseActive()) return;
        Intent i = new Intent(this, CameraForegroundService.class);
        i.setAction(CameraForegroundService.ACTION_REFRESH_NOTIFICATION);
        startForegroundService(i);
    }

    private void switchCameraIfActive() {
        if (!isAnyCameraServiceUseActive()) return;
        Intent i = new Intent(this, CameraForegroundService.class);
        i.setAction(CameraForegroundService.ACTION_SWITCH_CAMERA);
        startForegroundService(i);
    }

    private void syncFloatingSwitch() {
        boolean enabled = getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).getBoolean(CameraForegroundService.KEY_FLOAT_ENABLED, false);

        if (enabled && !Settings.canDrawOverlays(this)) {
            enabled = false;
            getSharedPreferences(
                    CameraForegroundService.PREFS, MODE_PRIVATE
            ).edit()
                    .putBoolean(CameraForegroundService.KEY_FLOAT_ENABLED, false)
                    .apply();
        }

        changingFloatingSwitch = true;
        floatingSwitch.setChecked(enabled);
        changingFloatingSwitch = false;
    }

    private void setFloatingShutterEnabled(boolean enabled) {
        if (enabled && !isResidentRunning()) {
            startResidentService();
        }

        Intent i = new Intent(this, CameraForegroundService.class);
        i.setAction(enabled
                ? CameraForegroundService.ACTION_FLOAT_ON
                : CameraForegroundService.ACTION_FLOAT_OFF);
        startForegroundService(i);

        changingFloatingSwitch = true;
        floatingSwitch.setChecked(enabled);
        changingFloatingSwitch = false;
        updateServiceButton();
    }

    private void updateCameraInfo() {
        boolean front = getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).getBoolean(KEY_USE_FRONT_CAMERA, false);

        cameraInfo.setText(
                front
                        ? "撮影: 前面カメラ/フラッシュOFF/AF待機 最大1.8秒/JPEG品質100"
                        : "撮影: 背面カメラ/フラッシュOFF/AF待機 最大1.8秒/JPEG品質100"
        );
    }

    private void updateSaveInfo() {
        String name = getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).getString(
                CameraForegroundService.KEY_SAVE_FOLDER_NAME,
                "Pictures/FinderlessCamera"
        );
        saveInfo.setText("保存先: " + name);
    }

    private void chooseSaveFolder() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION
                        | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                        | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                        | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
        );
        startActivityForResult(intent, REQ_SAVE_FOLDER);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode != REQ_SAVE_FOLDER
                || resultCode != RESULT_OK
                || data == null
                || data.getData() == null) {
            return;
        }

        Uri treeUri = data.getData();

        try {
            int takeFlags = data.getFlags()
                    & (Intent.FLAG_GRANT_READ_URI_PERMISSION
                    | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            getContentResolver().takePersistableUriPermission(treeUri, takeFlags);
        } catch (Exception ignored) { }

        String displayName = Uri.decode(treeUri.getLastPathSegment());
        if (displayName == null || displayName.trim().isEmpty()) {
            displayName = "選択したフォルダ";
        } else {
            int colon = displayName.lastIndexOf(':');
            if (colon >= 0 && colon < displayName.length() - 1) {
                displayName = displayName.substring(colon + 1);
            }
            int slash = displayName.lastIndexOf('/');
            if (slash >= 0 && slash < displayName.length() - 1) {
                displayName = displayName.substring(slash + 1);
            }
        }

        getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).edit()
                .putString(CameraForegroundService.KEY_SAVE_FOLDER_URI, treeUri.toString())
                .putString(CameraForegroundService.KEY_SAVE_FOLDER_NAME, displayName)
                .apply();

        updateSaveInfo();
    }

    private void showDiagnosticReport() {
        TextView text = new TextView(this);
        text.setText(CrashLogger.getReport(this));
        text.setTextSize(12f);
        text.setTextIsSelectable(true);
        text.setPadding(24, 16, 24, 16);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(text);

        new AlertDialog.Builder(this)
                .setTitle("FinderlessCamera 診断ログ")
                .setView(scroll)
                .setPositiveButton("閉じる", null)
                .setNegativeButton("ログ消去", (dialog, which) ->
                        CrashLogger.clear(this)
                )
                .show();
    }

    private void requestNeededPermissions() {
        List<String> perms = new ArrayList<>();

        if (checkSelfPermission(Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            perms.add(Manifest.permission.CAMERA);
        }

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS);
        }

        if (!perms.isEmpty()) {
            requestPermissions(perms.toArray(new String[0]), REQ_PERMS);
        }
    }
}
