package com.example.volumecamera;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.ImageFormat;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Size;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_PERMS = 100;

    private TextView status;
    private TextView cameraStatus;
    private LinearLayout cameraList;
    private Switch floatingSwitch;

    private boolean changingCameraSwitches = false;
    private boolean changingFloatingSwitch = false;
    private boolean pendingOverlayPermission = false;

    private static class CameraInfo {
        String id;
        float focalMm;
        long maxPixels;
        String label;
        Switch control;
    }

    private final List<CameraInfo> availableCameras = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        status = findViewById(R.id.status);
        cameraStatus = findViewById(R.id.camera_status);
        cameraList = findViewById(R.id.camera_list);
        floatingSwitch = findViewById(R.id.floating_shutter_switch);
        Button start = findViewById(R.id.start_service);

        requestNeededPermissions();

        start.setOnClickListener(v -> {
            if (checkSelfPermission(Manifest.permission.CAMERA)
                    != PackageManager.PERMISSION_GRANTED) {
                requestNeededPermissions();
                return;
            }

            Intent i = new Intent(this, CameraForegroundService.class);
            i.setAction(CameraForegroundService.ACTION_START);
            startForegroundService(i);
            status.setText("常駐通知を開始しました。");
        });

        floatingSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (changingFloatingSwitch) return;

            if (isChecked && !Settings.canDrawOverlays(this)) {
                changingFloatingSwitch = true;
                floatingSwitch.setChecked(false);
                changingFloatingSwitch = false;

                pendingOverlayPermission = true;
                status.setText("「他のアプリの上に重ねて表示」を許可してください。");

                Intent overlayIntent = new Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())
                );
                startActivity(overlayIntent);
                return;
            }

            setFloatingShutterEnabled(isChecked);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (checkSelfPermission(Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {
            loadCameraListSafely();
        }

        if (pendingOverlayPermission && Settings.canDrawOverlays(this)) {
            pendingOverlayPermission = false;
            setFloatingShutterEnabled(true);
        }

        syncFloatingSwitch();
    }

    private void syncFloatingSwitch() {
        boolean enabled = getSharedPreferences(
                CameraForegroundService.PREFS,
                MODE_PRIVATE
        ).getBoolean(CameraForegroundService.KEY_FLOAT_ENABLED, false);

        if (enabled && !Settings.canDrawOverlays(this)) {
            enabled = false;
            getSharedPreferences(
                    CameraForegroundService.PREFS,
                    MODE_PRIVATE
            ).edit()
                    .putBoolean(CameraForegroundService.KEY_FLOAT_ENABLED, false)
                    .apply();
        }

        changingFloatingSwitch = true;
        floatingSwitch.setChecked(enabled);
        changingFloatingSwitch = false;
    }

    private void setFloatingShutterEnabled(boolean enabled) {
        if (enabled && checkSelfPermission(Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            requestNeededPermissions();
            status.setText("フロートシャッターにはカメラ権限が必要です。");
            changingFloatingSwitch = true;
            floatingSwitch.setChecked(false);
            changingFloatingSwitch = false;
            return;
        }

        getSharedPreferences(
                CameraForegroundService.PREFS,
                MODE_PRIVATE
        ).edit()
                .putBoolean(CameraForegroundService.KEY_FLOAT_ENABLED, enabled)
                .apply();

        Intent i = new Intent(this, CameraForegroundService.class);
        i.setAction(
                enabled
                        ? CameraForegroundService.ACTION_FLOAT_ON
                        : CameraForegroundService.ACTION_FLOAT_OFF
        );
        startForegroundService(i);

        changingFloatingSwitch = true;
        floatingSwitch.setChecked(enabled);
        changingFloatingSwitch = false;
    }

    private void requestNeededPermissions() {
        List<String> perms = new ArrayList<>();

        if (checkSelfPermission(Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            perms.add(Manifest.permission.CAMERA);
        }

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS);
        }

        if (!perms.isEmpty()) {
            requestPermissions(perms.toArray(new String[0]), REQ_PERMS);
        }
    }

    private void loadCameraListSafely() {
        cameraList.removeAllViews();
        availableCameras.clear();

        CameraManager manager = getSystemService(CameraManager.class);
        if (manager == null) {
            cameraStatus.setText("カメラ情報を取得できませんでした。");
            return;
        }

        try {
            for (String id : manager.getCameraIdList()) {
                try {
                    CameraCharacteristics c =
                            manager.getCameraCharacteristics(id);

                    Integer facing = c.get(CameraCharacteristics.LENS_FACING);
                    if (facing == null
                            || facing != CameraCharacteristics.LENS_FACING_BACK) {
                        continue;
                    }

                    StreamConfigurationMap map =
                            c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
                    if (map == null) continue;

                    Size[] jpegSizes = map.getOutputSizes(ImageFormat.JPEG);
                    if (jpegSizes == null || jpegSizes.length == 0) continue;

                    CameraInfo info = new CameraInfo();
                    info.id = id;

                    float[] focals =
                            c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS);
                    info.focalMm =
                            (focals != null && focals.length > 0)
                                    ? (float) Arrays.stream(toDoubleArray(focals))
                                            .min()
                                            .orElse(0.0)
                                    : 0f;

                    Size max = Arrays.stream(jpegSizes)
                            .max(Comparator.comparingLong(
                                    s -> (long) s.getWidth() * s.getHeight()
                            ))
                            .orElse(jpegSizes[0]);

                    info.maxPixels =
                            (long) max.getWidth() * max.getHeight();

                    availableCameras.add(info);
                } catch (Exception ignored) {
                    // A vendor-specific camera entry must not crash the settings screen.
                }
            }
        } catch (Exception e) {
            cameraStatus.setText("カメラ一覧の取得に失敗しました。");
            return;
        }

        availableCameras.sort(Comparator.comparingDouble(
                i -> i.focalMm > 0 ? i.focalMm : Double.MAX_VALUE
        ));

        for (int i = 0; i < availableCameras.size(); i++) {
            CameraInfo info = availableCameras.get(i);
            info.label = inferCameraLabel(i, availableCameras.size());
        }

        SharedPreferences prefs = getSharedPreferences(
                CameraForegroundService.PREFS,
                MODE_PRIVATE
        );
        String selectedId = prefs.getString(
                CameraForegroundService.KEY_SELECTED_CAMERA,
                null
        );

        boolean selectedStillExists = false;
        for (CameraInfo info : availableCameras) {
            if (info.id.equals(selectedId)) {
                selectedStillExists = true;
                break;
            }
        }

        if (!selectedStillExists && !availableCameras.isEmpty()) {
            selectedId = availableCameras.get(0).id;
            prefs.edit()
                    .putString(
                            CameraForegroundService.KEY_SELECTED_CAMERA,
                            selectedId
                    )
                    .apply();
        }

        for (CameraInfo info : availableCameras) {
            Switch sw = new Switch(this);
            sw.setText(formatCameraLine(info));
            sw.setTextSize(16f);
            sw.setPadding(0, 14, 0, 14);
            sw.setChecked(info.id.equals(selectedId));

            info.control = sw;

            sw.setOnCheckedChangeListener((buttonView, isChecked) -> {
                if (changingCameraSwitches) return;

                if (!isChecked) {
                    changingCameraSwitches = true;
                    buttonView.setChecked(true);
                    changingCameraSwitches = false;
                    return;
                }

                changingCameraSwitches = true;
                for (CameraInfo other : availableCameras) {
                    if (other.control != null) {
                        other.control.setChecked(other == info);
                    }
                }
                changingCameraSwitches = false;

                prefs.edit()
                        .putString(
                                CameraForegroundService.KEY_SELECTED_CAMERA,
                                info.id
                        )
                        .apply();

                Toast.makeText(
                        this,
                        "使用カメラを " + info.label + " に変更しました",
                        Toast.LENGTH_SHORT
                ).show();
            });

            cameraList.addView(sw);
        }

        if (availableCameras.isEmpty()) {
            cameraStatus.setText(
                    "Camera2から利用可能な背面カメラを取得できませんでした。"
            );
        } else if (availableCameras.size() == 1) {
            cameraStatus.setText(
                    "この端末では背面カメラを1台だけ取得できました。"
            );
        } else {
            cameraStatus.setText(
                    "使用するカメラを1台だけ選択してください。"
            );
        }
    }

    private static double[] toDoubleArray(float[] values) {
        double[] out = new double[values.length];
        for (int i = 0; i < values.length; i++) {
            out[i] = values[i];
        }
        return out;
    }

    private String inferCameraLabel(int index, int count) {
        if (count >= 3) {
            if (index == 0) return "超広角側";
            if (index == count - 1) return "望遠側";
            return "標準側";
        }

        if (count == 2) {
            return index == 0 ? "広角側" : "望遠側";
        }

        return "背面カメラ";
    }

    private String formatCameraLine(CameraInfo info) {
        String focal =
                info.focalMm > 0
                        ? String.format(Locale.JAPAN, "%.1f mm", info.focalMm)
                        : "焦点距離不明";

        double mp = info.maxPixels / 1_000_000.0;

        return String.format(
                Locale.JAPAN,
                "%s  Camera %s\n%s / 最大 %.1f MP",
                info.label,
                info.id,
                focal,
                mp
        );
    }
}
