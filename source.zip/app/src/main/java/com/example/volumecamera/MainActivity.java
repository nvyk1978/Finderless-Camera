package com.example.volumecamera;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.ImageFormat;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.util.Size;
import java.util.Arrays;
import java.util.Comparator;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int UI_DARK_RED = android.graphics.Color.rgb(139, 0, 0);
    private static final String KEY_SERVICE_RUNNING = "service_running";
    private static final String KEY_AUTO_START_RESIDENT = "auto_start_resident";
    private static final String KEY_NOTIFICATION_SWIPE_END = "notification_swipe_end";
    private static final String KEY_USE_FRONT_CAMERA = "use_front_camera";
    private static final String KEY_PEEK_MODE = "peek_mode";
    private static final String KEY_PEEK_PREV_FRONT = "peek_prev_front";
    private static final String KEY_PEEK_PREV_VIBRATION = "peek_prev_vibration";
    private static final String KEY_PEEK_PREV_SWIPE = "peek_prev_swipe";
    private static final String KEY_PEEK_PREV_FLOAT = "peek_prev_float";
    private static final int REQ_PERMS = 100;
    private static final int REQ_SAVE_FOLDER = 200;
    private static final String KEY_INTERRUPTION_SHOWN = "interruption_shown_session";

    private Button startServiceButton;
    private Button autoCaptureButton;
    private Button peekModeButton;
    private TextView cameraInfo;
    private TextView saveInfo;

    private Switch floatingSwitch;
    private Switch miniFinderSwitch;
    private Switch burstSwitch;
    private Switch shutterVibrationSwitch;
    private Switch autoStartResidentSwitch;
    private Switch notificationSwipeSwitch;
    private Switch frontCameraSwitch;
    private TextView autofocusLabel;
    private TextView autofocusValue;
    private TextView imageQualityLabel;
    private TextView imageQualityValue;
    private TextView jpegQualityLabel, jpegQualityValue;
    private TextView imageAspectLabel;
    private Button afLowButton, afMidButton, afHighButton;
    private Button qualityLowButton, qualityMidButton, qualityHighButton;
    private Button jpegLowButton, jpegMidButton, jpegHighButton;
    private Button aspect43Button, aspect169Button, aspectDefaultButton;
    private Button hideModeButton;

    private boolean changingFloatingSwitch = false;
    private boolean changingMiniFinderSwitch = false;
    private boolean pendingOverlayPermission = false;
    private boolean receiverRegistered = false;
    private boolean applyingPeekMode = false;
    private boolean removeTaskAfterMonitorEnable = false;
    private boolean residentStartRequested = false;

    private final BroadcastReceiver stateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            syncFloatingSwitch();
            syncMiniFinderSwitch();
            updateServiceButton();
            updateAutoCaptureButton();
            updateSegmentUi(getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE).getInt(CameraForegroundService.KEY_AF_STRENGTH,2), getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE).getInt(CameraForegroundService.KEY_IMAGE_QUALITY,1));
            updateCameraInfo();
            updateSaveInfo();
            if (CameraForegroundService.ACTION_HIDE_MODE_ACTIVATED.equals(intent.getAction())) {
                getWindow().getDecorView().postDelayed(() -> {
                    if (Build.VERSION.SDK_INT >= 21) finishAndRemoveTask();
                    else finish();
                }, 520L);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        CrashLogger.log(this, "ACTIVITY onCreate");
        setContentView(R.layout.activity_main);

        floatingSwitch = findViewById(R.id.floating_shutter_switch);
        miniFinderSwitch = findViewById(R.id.mini_finder_switch);
        burstSwitch = findViewById(R.id.burst_shot_switch);
        shutterVibrationSwitch = findViewById(R.id.shutter_vibration);
        autoStartResidentSwitch = findViewById(R.id.auto_start_resident);
        notificationSwipeSwitch = findViewById(R.id.notification_swipe_end);
        frontCameraSwitch = findViewById(R.id.front_camera_switch);
        autofocusLabel = findViewById(R.id.autofocus_label);
        autofocusValue = findViewById(R.id.autofocus_value);
        imageQualityLabel = findViewById(R.id.image_quality_label);
        imageQualityValue = findViewById(R.id.image_quality_value);
        jpegQualityLabel = findViewById(R.id.jpeg_quality_label);
        jpegQualityValue = findViewById(R.id.jpeg_quality_value);
        afLowButton = findViewById(R.id.af_low);
        afMidButton = findViewById(R.id.af_mid);
        afHighButton = findViewById(R.id.af_high);
        qualityLowButton = findViewById(R.id.quality_low);
        qualityMidButton = findViewById(R.id.quality_mid);
        qualityHighButton = findViewById(R.id.quality_high);
        jpegLowButton = findViewById(R.id.jpeg_low);
        jpegMidButton = findViewById(R.id.jpeg_mid);
        jpegHighButton = findViewById(R.id.jpeg_high);
        imageAspectLabel = findViewById(R.id.image_aspect_label);
        aspect43Button = findViewById(R.id.aspect_43);
        aspect169Button = findViewById(R.id.aspect_169);
        aspectDefaultButton = findViewById(R.id.aspect_default);

        startServiceButton = findViewById(R.id.start_service);
        autoCaptureButton = findViewById(R.id.auto_capture_button);
        peekModeButton = findViewById(R.id.peek_mode_button);
        hideModeButton = findViewById(R.id.hide_mode_button);
        Button saveFolderButton = findViewById(R.id.change_save_folder);
        Button diagnostic = findViewById(R.id.show_diagnostic);

        cameraInfo = findViewById(R.id.camera_info);
        saveInfo = findViewById(R.id.save_info);

        requestNeededPermissions();
        bindSettings();
        showInterruptedCaptureIfNeeded();

        startServiceButton.setOnClickListener(v -> {
            if (isPeekMode()) {
                shutdownMonitorModeCompletely();
                return;
            }

            if (isResidentRunning()) {
                boolean floating = getSharedPreferences(
                        CameraForegroundService.PREFS, MODE_PRIVATE
                ).getBoolean(CameraForegroundService.KEY_FLOAT_ENABLED, false);

                if (floating) {
                    return;
                }

                stopResidentService();
            } else {
                startResidentService();
            }
        });

        autoCaptureButton.setOnClickListener(v -> {
            if (isPeekMode()) {
                shutdownMonitorModeCompletely();
                return;
            }

            boolean auto = getSharedPreferences(
                    CameraForegroundService.PREFS, MODE_PRIVATE
            ).getBoolean(CameraForegroundService.KEY_ENABLED, false);

            if (!auto && !isResidentRunning()) {
                startResidentService();
            }

            Intent i = new Intent(this, CameraForegroundService.class);
            i.setAction(CameraForegroundService.ACTION_TOGGLE);
            startForegroundService(i);
        });

        peekModeButton.setOnClickListener(v -> {
            if (isPeekMode()) shutdownMonitorModeCompletely();
            else setPeekMode(true);
        });
        hideModeButton.setOnClickListener(v -> activateHideMode());

        saveFolderButton.setOnClickListener(v -> chooseSaveFolder());
        diagnostic.setOnClickListener(v -> showDiagnosticReport());
    }

    private void bindSettings() {
        floatingSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (changingFloatingSwitch) return;

            if (isPeekMode()) {
                floatingSwitch.postDelayed(() -> applyPeekLockedStates(true), 120L);
                return;
            }

            if (isChecked && checkSelfPermission(Manifest.permission.CAMERA)
                    != PackageManager.PERMISSION_GRANTED) {
                changingFloatingSwitch = true;
                floatingSwitch.setChecked(false);
                changingFloatingSwitch = false;
                requestNeededPermissions();
                return;
            }

            if (isChecked && !Settings.canDrawOverlays(this)) {
                changingFloatingSwitch = true;
                floatingSwitch.setChecked(false);
                changingFloatingSwitch = false;
                pendingOverlayPermission = true;
                Intent overlayIntent = new Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())
                );
                startActivity(overlayIntent);
                return;
            }

            setFloatingShutterEnabled(isChecked);
        });

        miniFinderSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (changingMiniFinderSwitch) return;
            if (isPeekMode()) {
                changingMiniFinderSwitch = true;
                miniFinderSwitch.setChecked(false);
                changingMiniFinderSwitch = false;
                return;
            }
            if (isChecked && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                changingMiniFinderSwitch = true;
                miniFinderSwitch.setChecked(false);
                changingMiniFinderSwitch = false;
                requestNeededPermissions();
                return;
            }
            if (isChecked && !Settings.canDrawOverlays(this)) {
                changingMiniFinderSwitch = true;
                miniFinderSwitch.setChecked(false);
                changingMiniFinderSwitch = false;
                pendingOverlayPermission = true;
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
                return;
            }
            if (isChecked && !isResidentRunning()) startResidentService();
            Intent i = new Intent(this, CameraForegroundService.class);
            i.setAction(isChecked ? CameraForegroundService.ACTION_MINI_FINDER_ON
                    : CameraForegroundService.ACTION_MINI_FINDER_OFF);
            startForegroundService(i);
        });

        burstSwitch.setChecked(getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).getBoolean(CameraForegroundService.KEY_BURST_ENABLED, false));
        burstSwitch.setOnCheckedChangeListener((buttonView, isChecked) ->
                getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                        .edit()
                        .putBoolean(CameraForegroundService.KEY_BURST_ENABLED, isChecked)
                        .apply()
        );

        shutterVibrationSwitch.setChecked(getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).getBoolean(CameraForegroundService.KEY_SHUTTER_VIBRATION, true));
        shutterVibrationSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (applyingPeekMode) return;
            if (isPeekMode()) {
                shutterVibrationSwitch.postDelayed(() -> applyPeekLockedStates(true), 120L);
                return;
            }
            getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                    .edit()
                    .putBoolean(CameraForegroundService.KEY_SHUTTER_VIBRATION, isChecked)
                    .apply();
        });

        autoStartResidentSwitch.setChecked(getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).getBoolean(KEY_AUTO_START_RESIDENT, false));
        autoStartResidentSwitch.setOnCheckedChangeListener((buttonView, isChecked) ->
                getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                        .edit()
                        .putBoolean(KEY_AUTO_START_RESIDENT, isChecked)
                        .apply()
        );

        android.content.SharedPreferences notificationPrefs = getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        );
        if (!notificationPrefs.contains(KEY_NOTIFICATION_SWIPE_END)) {
            notificationPrefs.edit().putBoolean(KEY_NOTIFICATION_SWIPE_END, false).apply();
        }
        notificationSwipeSwitch.setChecked(
                notificationPrefs.getBoolean(KEY_NOTIFICATION_SWIPE_END, false)
        );
        notificationSwipeSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (applyingPeekMode) return;
            if (isPeekMode()) {
                notificationSwipeSwitch.postDelayed(() -> applyPeekLockedStates(true), 120L);
                return;
            }
            getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                    .edit()
                    .putBoolean(KEY_NOTIFICATION_SWIPE_END, isChecked)
                    .apply();
            Intent visibility = new Intent(this, CameraForegroundService.class);
            visibility.setAction(isChecked
                    ? CameraForegroundService.ACTION_HIDE_NOTIFICATION
                    : CameraForegroundService.ACTION_SHOW_NOTIFICATION);
            startService(visibility);
        });

        frontCameraSwitch.setChecked(getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).getBoolean(KEY_USE_FRONT_CAMERA, false));
        frontCameraSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (applyingPeekMode) return;
            if (isPeekMode()) {
                frontCameraSwitch.postDelayed(() -> applyPeekLockedStates(true), 120L);
                return;
            }
            getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                    .edit()
                    .putBoolean(KEY_USE_FRONT_CAMERA, isChecked)
                    .apply();
            switchCameraIfActive();
            updateCameraInfo();
            updateSegmentUi(
                    getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                            .getInt(CameraForegroundService.KEY_AF_STRENGTH, 2),
                    getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                            .getInt(CameraForegroundService.KEY_IMAGE_QUALITY, 1)
            );
        });

        int afStrength = getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                .getInt(CameraForegroundService.KEY_AF_STRENGTH, 2);
        int quality = getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                .getInt(CameraForegroundService.KEY_IMAGE_QUALITY, 1);
        updateSegmentUi(afStrength, quality);

        afLowButton.setOnClickListener(v -> setAfStrength(0));
        afMidButton.setOnClickListener(v -> setAfStrength(1));
        afHighButton.setOnClickListener(v -> setAfStrength(2));
        qualityLowButton.setOnClickListener(v -> setImageQuality(0));
        qualityMidButton.setOnClickListener(v -> setImageQuality(1));
        qualityHighButton.setOnClickListener(v -> setImageQuality(2));
        jpegLowButton.setOnClickListener(v -> setJpegQuality(0));
        jpegMidButton.setOnClickListener(v -> setJpegQuality(1));
        jpegHighButton.setOnClickListener(v -> setJpegQuality(2));
        aspect43Button.setOnClickListener(v -> setImageAspect(0));
        aspect169Button.setOnClickListener(v -> setImageAspect(1));
        aspectDefaultButton.setOnClickListener(v -> setImageAspect(2));
    }

    private void setAfStrength(int value) {
        if (isAutoCapturing()) return;
        getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE).edit()
                .putInt(CameraForegroundService.KEY_AF_STRENGTH, value).apply();
        updateSegmentUi(value, getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                .getInt(CameraForegroundService.KEY_IMAGE_QUALITY, 1));
    }

    private void setImageQuality(int value) {
        if (isAutoCapturing()) return;
        getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE).edit()
                .putInt(CameraForegroundService.KEY_IMAGE_QUALITY, value).apply();
        updateSegmentUi(getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                .getInt(CameraForegroundService.KEY_AF_STRENGTH, 2), value);
        if (isAnyCameraServiceUseActive()) {
            Intent i = new Intent(this, CameraForegroundService.class);
            i.setAction(CameraForegroundService.ACTION_REOPEN_CAMERA);
            startService(i);
        }
    }

    private void setImageAspect(int value) {
        if (isAutoCapturing()) return;

        getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                .edit()
                .putInt(CameraForegroundService.KEY_IMAGE_ASPECT, value)
                .apply();

        updateSegmentUi(
                getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                        .getInt(CameraForegroundService.KEY_AF_STRENGTH, 2),
                getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                        .getInt(CameraForegroundService.KEY_IMAGE_QUALITY, 1)
        );

        if (isAnyCameraServiceUseActive()) {
            Intent i = new Intent(this, CameraForegroundService.class);
            i.setAction(CameraForegroundService.ACTION_REOPEN_CAMERA);
            startService(i);
        }
    }

    private void setJpegQuality(int value) {
        if (isAutoCapturing()) return;
        getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE).edit()
                .putInt(CameraForegroundService.KEY_JPEG_QUALITY, value).apply();
        updateSegmentUi(
                getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE).getInt(CameraForegroundService.KEY_AF_STRENGTH, 2),
                getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE).getInt(CameraForegroundService.KEY_IMAGE_QUALITY, 1));
    }

    private boolean isAutoCapturing() {
        return getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                .getBoolean(CameraForegroundService.KEY_ENABLED, false);
    }

    private void updateSegmentUi(int af, int quality) {
        boolean live = !isAutoCapturing();

        Button[] afs={afLowButton,afMidButton,afHighButton};
        Button[] qs={qualityLowButton,qualityMidButton,qualityHighButton};
        Button[] jqs={jpegLowButton,jpegMidButton,jpegHighButton};
        Button[] ars={aspect43Button,aspect169Button,aspectDefaultButton};

        int jq=getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                .getInt(CameraForegroundService.KEY_JPEG_QUALITY,2);
        int ar=getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                .getInt(CameraForegroundService.KEY_IMAGE_ASPECT,2);

        for(int i=0;i<3;i++){
            styleSegment(afs[i], i==af, live);
            styleSegment(qs[i], i==quality, live);
            styleSegment(jqs[i], i==jq, live);
            styleSegment(ars[i], i==ar, live);
        }

        autofocusValue.setText(af <= 0 ? "0.5秒" : (af == 1 ? "1.0秒" : "1.8秒"));
        imageQualityValue.setText(getSelectedJpegResolutionText(quality));
        jpegQualityValue.setText(jq==0?"60":(jq==1?"80":"100"));

        int normal=android.graphics.Color.rgb(235,235,235);
        int disabled=android.graphics.Color.rgb(110,110,110);

        autofocusLabel.setTextColor(live?normal:disabled);
        autofocusValue.setTextColor(live?normal:disabled);
        imageQualityLabel.setTextColor(live?normal:disabled);
        imageQualityValue.setTextColor(live?normal:disabled);
        jpegQualityLabel.setTextColor(live?normal:disabled);
        jpegQualityValue.setTextColor(live?normal:disabled);
        imageAspectLabel.setTextColor(live?normal:disabled);
    }

    private String getSelectedJpegResolutionText(int quality) {
        try {
            CameraManager manager = getSystemService(CameraManager.class);
            if (manager == null) return "--";

            boolean front = getSharedPreferences(
                    CameraForegroundService.PREFS, MODE_PRIVATE
            ).getBoolean(KEY_USE_FRONT_CAMERA, false);

            int wantedFacing = front
                    ? CameraCharacteristics.LENS_FACING_FRONT
                    : CameraCharacteristics.LENS_FACING_BACK;

            int aspect = getSharedPreferences(
                    CameraForegroundService.PREFS, MODE_PRIVATE
            ).getInt(CameraForegroundService.KEY_IMAGE_ASPECT, 2);

            for (String id : manager.getCameraIdList()) {
                CameraCharacteristics c = manager.getCameraCharacteristics(id);
                Integer facing = c.get(CameraCharacteristics.LENS_FACING);
                if (facing == null || facing != wantedFacing) continue;

                StreamConfigurationMap map =
                        c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
                if (map == null) continue;

                Size[] sizes = map.getOutputSizes(ImageFormat.JPEG);
                if (sizes == null || sizes.length == 0) continue;

                java.util.List<Size> filtered = new java.util.ArrayList<>();
                if (aspect == 0 || aspect == 1) {
                    float target = aspect == 0 ? (4f / 3f) : (16f / 9f);
                    for (Size s : sizes) {
                        float r = Math.max(s.getWidth(), s.getHeight())
                                / (float)Math.min(s.getWidth(), s.getHeight());
                        if (Math.abs(r - target) < 0.02f) filtered.add(s);
                    }
                }

                Size[] sorted = filtered.isEmpty()
                        ? Arrays.copyOf(sizes, sizes.length)
                        : filtered.toArray(new Size[0]);

                Arrays.sort(sorted, Comparator.comparingLong(
                        s -> (long)s.getWidth() * s.getHeight()
                ));

                Size chosen;
                if (quality <= 0) {
                    chosen = sorted[0];
                    long targetArea = 1280L * 720L;
                    for (Size s : sorted) {
                        long area = (long)s.getWidth() * s.getHeight();
                        if (area <= targetArea) chosen = s;
                        else break;
                    }
                } else if (quality >= 2) {
                    chosen = sorted[sorted.length - 1];
                } else {
                    chosen = sorted[sorted.length / 2];
                }

                return chosen.getWidth() + "×" + chosen.getHeight();
            }
        } catch (Exception ignored) { }

        return "--";
    }

    private void styleSegment(Button b, boolean selected, boolean enabled) {
        b.setEnabled(enabled);
        if(!enabled){
            b.setBackgroundResource(R.drawable.button_dark_gray);
            b.setTextColor(android.graphics.Color.rgb(110,110,110));
        } else if(selected){
            b.setBackgroundResource(R.drawable.button_blue);
            b.setTextColor(android.graphics.Color.WHITE);
        } else {
            b.setBackgroundResource(R.drawable.button_dark_gray);
            b.setTextColor(android.graphics.Color.rgb(235,235,235));
        }
    }

    private void showInterruptedCaptureIfNeeded() {
        android.content.SharedPreferences p=getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE);
        if (!p.getBoolean(CameraForegroundService.KEY_CAPTURE_SESSION_ACTIVE, false)) return;
        p.edit().putBoolean(CameraForegroundService.KEY_CAPTURE_SESSION_ACTIVE, false).apply();
        final android.app.Dialog d=new android.app.Dialog(this);
        TextView tv=new TextView(this);
        tv.setText("撮影が中断されました");
        tv.setTextSize(16f); tv.setTextColor(android.graphics.Color.WHITE);
        tv.setGravity(android.view.Gravity.CENTER);
        tv.setPadding(40,24,40,24);
        android.graphics.drawable.GradientDrawable bg=new android.graphics.drawable.GradientDrawable();
        bg.setColor(android.graphics.Color.rgb(45,45,45)); bg.setCornerRadius(48f); tv.setBackground(bg);
        d.setContentView(tv); d.setCancelable(true);
        android.view.Window win=d.getWindow();
        if(win!=null){ win.setBackgroundDrawableResource(android.R.color.transparent); win.clearFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND); }
        d.setOnShowListener(x->{ if(d.getWindow()!=null){ android.view.WindowManager.LayoutParams a=d.getWindow().getAttributes(); a.alpha=0f; d.getWindow().setAttributes(a); android.animation.ValueAnimator v=android.animation.ValueAnimator.ofFloat(0f,1f); v.setDuration(450); v.addUpdateListener(z->{ android.view.WindowManager.LayoutParams q=d.getWindow().getAttributes(); q.alpha=(float)z.getAnimatedValue(); d.getWindow().setAttributes(q);}); v.start(); }
            tv.postDelayed(()->{ if(!d.isShowing())return; tv.animate().alpha(0f).setDuration(650).withEndAction(d::dismiss).start(); },1800); });
        d.show();
    }

    private void activateHideMode() {
        Intent i=new Intent(this,CameraForegroundService.class);
        i.setAction(CameraForegroundService.ACTION_HIDE_MODE);
        startForegroundService(i);
    }

    @Override
    protected void onResume() {
        super.onResume();
        boolean exitedHideOnResume = false;
        android.content.SharedPreferences hidePrefs =
                getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE);
        if (hidePrefs.getBoolean(CameraForegroundService.KEY_HIDE_ACTIVE, false)) {
            exitedHideOnResume = true;
            Intent exitHide = new Intent(this, CameraForegroundService.class);
            exitHide.setAction(CameraForegroundService.ACTION_EXIT_HIDE);
            startService(exitHide);
        }
        if (!receiverRegistered) {
            IntentFilter filter = new IntentFilter();
            filter.addAction(CameraForegroundService.ACTION_FLOAT_STATE_CHANGED);
            filter.addAction(CameraForegroundService.ACTION_SERVICE_STATE_CHANGED);
            filter.addAction(CameraForegroundService.ACTION_AUTO_STATE_CHANGED);
            filter.addAction(CameraForegroundService.ACTION_CAMERA_STATE_CHANGED);
            filter.addAction(CameraForegroundService.ACTION_HIDE_MODE_ACTIVATED);
            registerReceiver(stateReceiver, filter, RECEIVER_NOT_EXPORTED);
            receiverRegistered = true;
        }

        if (pendingOverlayPermission && Settings.canDrawOverlays(this)) {
            pendingOverlayPermission = false;
            setFloatingShutterEnabled(true);
        }

        recoverStaleFloatingState();
        syncFloatingSwitch();
        syncMiniFinderSwitch();
        if (exitedHideOnResume) {
            applyingPeekMode = true;
            notificationSwipeSwitch.setChecked(false);
            applyingPeekMode = false;
            changingFloatingSwitch = true;
            floatingSwitch.setChecked(false);
            changingFloatingSwitch = false;
            changingMiniFinderSwitch = true;
            miniFinderSwitch.setChecked(false);
            changingMiniFinderSwitch = false;
        }

        if (isPeekMode()) {
            applyPeekLockedStates(true);
            ensureMonitorRuntime(false);
        } else {
            boolean autoStart = getSharedPreferences(
                    CameraForegroundService.PREFS, MODE_PRIVATE
            ).getBoolean(KEY_AUTO_START_RESIDENT, false);

            if (!exitedHideOnResume
                    && autoStart
                    && !isResidentRunning()
                    && checkSelfPermission(Manifest.permission.CAMERA)
                    == PackageManager.PERMISSION_GRANTED) {
                startResidentService();
            }
        }

        updateServiceButton();
        updateAutoCaptureButton();
        updateSegmentUi(getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE).getInt(CameraForegroundService.KEY_AF_STRENGTH,2), getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE).getInt(CameraForegroundService.KEY_IMAGE_QUALITY,1));
        updatePeekModeUi();
        updateCameraInfo();
        updateSaveInfo();
    }

    @Override
    protected void onPause() {
        if (receiverRegistered) {
            try {
                unregisterReceiver(stateReceiver);
            } catch (Exception ignored) { }
            receiverRegistered = false;
        }
        super.onPause();
    }

    private void startResidentService() {
        if (checkSelfPermission(Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            requestNeededPermissions();
            return;
        }

        if (residentStartRequested || isResidentRunning()) {
            return;
        }

        residentStartRequested = true;
        getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).edit().putBoolean(KEY_SERVICE_RUNNING, true).apply();
        updateServiceButton();

        Intent i = new Intent(this, CameraForegroundService.class);
        i.setAction(CameraForegroundService.ACTION_START);
        startForegroundService(i);

        startServiceButton.postDelayed(() -> {
            residentStartRequested = false;
            updateServiceButton();
        }, 900L);
    }

    private void stopResidentService() {
        residentStartRequested = false;
        Intent stop = new Intent(this, CameraForegroundService.class);
        stop.setAction(CameraForegroundService.ACTION_STOP_SERVICE);
        startService(stop);
    }

    private boolean isResidentRunning() {
        boolean pref = getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).getBoolean(KEY_SERVICE_RUNNING, false);

        if (!pref) return false;

        try {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null && Build.VERSION.SDK_INT >= 23) {
                for (android.service.notification.StatusBarNotification n
                        : nm.getActiveNotifications()) {
                    if (n.getId() == CameraForegroundService.NOTIFICATION_ID_PUBLIC) {
                        return true;
                    }
                }

                if (residentStartRequested) {
                    return true;
                }

                getSharedPreferences(
                        CameraForegroundService.PREFS, MODE_PRIVATE
                ).edit().putBoolean(KEY_SERVICE_RUNNING, false).apply();
                return false;
            }
        } catch (Exception ignored) { }

        return pref;
    }

    private boolean isAnyCameraServiceUseActive() {
        boolean floating = getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).getBoolean(CameraForegroundService.KEY_FLOAT_ENABLED, false);

        boolean auto = getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).getBoolean(CameraForegroundService.KEY_ENABLED, false);

        return isResidentRunning() || floating || auto;
    }

    private void updateServiceButton() {
        boolean running = isResidentRunning();
        startServiceButton.setText(running ? "常駐終了" : "常駐開始");

        if (running) {
            startServiceButton.setBackgroundResource(R.drawable.button_dark_gray);
            startServiceButton.setTextColor(UI_DARK_RED);
        } else {
            startServiceButton.setBackgroundResource(R.drawable.button_orange);
            startServiceButton.setTextColor(android.graphics.Color.WHITE);
        }
    }

    private void updateAutoCaptureButton() {
        boolean auto = getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).getBoolean(CameraForegroundService.KEY_ENABLED, false);

        autoCaptureButton.setText(auto ? "STOP" : "AUTO");

        if (auto) {
            autoCaptureButton.setBackgroundResource(R.drawable.button_dark_gray);
            autoCaptureButton.setTextColor(UI_DARK_RED);
        } else {
            autoCaptureButton.setBackgroundResource(R.drawable.button_blue);
            autoCaptureButton.setTextColor(android.graphics.Color.WHITE);
        }
    }

    private boolean isPeekMode() {
        return getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                .getBoolean(KEY_PEEK_MODE, false);
    }

    private void setPeekMode(boolean enabled) {
        android.content.SharedPreferences prefs = getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        );

        if (enabled) {
            prefs.edit()
                    .putBoolean(KEY_PEEK_PREV_FRONT, prefs.getBoolean(KEY_USE_FRONT_CAMERA, false))
                    .putBoolean(KEY_PEEK_PREV_VIBRATION, prefs.getBoolean(CameraForegroundService.KEY_SHUTTER_VIBRATION, true))
                    .putBoolean(KEY_PEEK_PREV_SWIPE, prefs.getBoolean(KEY_NOTIFICATION_SWIPE_END, true))
                    .putBoolean(KEY_PEEK_PREV_FLOAT, prefs.getBoolean(CameraForegroundService.KEY_FLOAT_ENABLED, false))
                    .putBoolean(KEY_PEEK_MODE, true)
                    .apply();

            removeTaskAfterMonitorEnable = true;
            applyPeekLockedStates(true);
            ensureMonitorRuntime(true);
        } else {
            boolean front = prefs.getBoolean(KEY_PEEK_PREV_FRONT, false);
            boolean vibration = prefs.getBoolean(KEY_PEEK_PREV_VIBRATION, true);
            boolean swipe = prefs.getBoolean(KEY_PEEK_PREV_SWIPE, true);
            boolean floating = prefs.getBoolean(KEY_PEEK_PREV_FLOAT, false);

            prefs.edit()
                    .putBoolean(KEY_PEEK_MODE, false)
                    .putBoolean(KEY_USE_FRONT_CAMERA, front)
                    .putBoolean(CameraForegroundService.KEY_SHUTTER_VIBRATION, vibration)
                    .putBoolean(KEY_NOTIFICATION_SWIPE_END, swipe)
                    .putBoolean(CameraForegroundService.KEY_FLOAT_ENABLED, floating)
                    .apply();

            applyingPeekMode = true;
            frontCameraSwitch.setChecked(front);
            shutterVibrationSwitch.setChecked(vibration);
            notificationSwipeSwitch.setChecked(swipe);
            applyingPeekMode = false;

            setFloatingShutterEnabled(floating);
            switchCameraIfActive();
            refreshNotificationIfActive();
        }

        updatePeekModeUi();
        updateCameraInfo();
    }

    private void ensureMonitorRuntime(boolean removeTaskWhenReady) {
        if (!isPeekMode()) return;

        if (!isResidentRunning()) {
            startResidentService();
        }

        boolean auto = getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).getBoolean(CameraForegroundService.KEY_ENABLED, false);

        if (!auto) {
            Intent autoIntent = new Intent(this, CameraForegroundService.class);
            autoIntent.setAction(CameraForegroundService.ACTION_AUTO_ON);
            startForegroundService(autoIntent);
        }

        if (removeTaskWhenReady || removeTaskAfterMonitorEnable) {
            removeTaskAfterMonitorEnable = false;
            getWindow().getDecorView().postDelayed(() -> {
                if (Build.VERSION.SDK_INT >= 21) {
                    finishAndRemoveTask();
                } else {
                    finish();
                }
            }, 450L);
        }
    }

    private void applyPeekLockedStates(boolean persist) {
        applyingPeekMode = true;
        frontCameraSwitch.setChecked(true);
        shutterVibrationSwitch.setChecked(false);
        notificationSwipeSwitch.setChecked(true);

        changingFloatingSwitch = true;
        floatingSwitch.setChecked(false);
        changingFloatingSwitch = false;

        applyingPeekMode = false;

        if (persist) {
            getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                    .edit()
                    .putBoolean(KEY_USE_FRONT_CAMERA, true)
                    .putBoolean(CameraForegroundService.KEY_SHUTTER_VIBRATION, false)
                    .putBoolean(KEY_NOTIFICATION_SWIPE_END, true)
                    .putBoolean(CameraForegroundService.KEY_FLOAT_ENABLED, false)
                    .apply();

            Intent floatOff = new Intent(this, CameraForegroundService.class);
            floatOff.setAction(CameraForegroundService.ACTION_FLOAT_OFF);
            startForegroundService(floatOff);

            switchCameraIfActive();
            refreshNotificationIfActive();
        }
    }

    private void updatePeekModeUi() {
        boolean peek = isPeekMode();

        peekModeButton.setText(peek ? "スマホ監視モード中" : "スマホ監視モード");

        if (peek) {
            peekModeButton.setBackgroundResource(R.drawable.button_dark_gray);
            peekModeButton.setTextColor(UI_DARK_RED);
        } else {
            peekModeButton.setBackgroundResource(R.drawable.button_dark_red);
            peekModeButton.setTextColor(android.graphics.Color.WHITE);
        }

        applyPeekModeColors(peek);

        if (peek) {
            applyPeekLockedStates(false);
        }
    }

    private void applyPeekModeColors(boolean peek) {
        Switch[] allSwitches = new Switch[]{
                floatingSwitch,
                miniFinderSwitch,
                burstSwitch,
                shutterVibrationSwitch,
                autoStartResidentSwitch,
                notificationSwipeSwitch,
                frontCameraSwitch
        };

        Switch[] lockedSwitches = new Switch[]{
                floatingSwitch,
                shutterVibrationSwitch,
                notificationSwipeSwitch,
                frontCameraSwitch
        };

        int[][] states = new int[][]{
                new int[]{android.R.attr.state_checked},
                new int[]{-android.R.attr.state_checked}
        };

        if (peek) {
            ColorStateList normalThumb = new ColorStateList(
                    states,
                    new int[]{
                            android.graphics.Color.rgb(25, 118, 210),
                            android.graphics.Color.WHITE
                    }
            );
            ColorStateList normalTrack = new ColorStateList(
                    states,
                    new int[]{
                            android.graphics.Color.rgb(100, 181, 246),
                            android.graphics.Color.rgb(117, 117, 117)
                    }
            );

            for (Switch item : allSwitches) {
                item.setThumbTintList(normalThumb);
                item.setTrackTintList(normalTrack);
            }

            ColorStateList red = ColorStateList.valueOf(
                    UI_DARK_RED
            );

            for (Switch item : lockedSwitches) {
                item.setTextColor(UI_DARK_RED);
                item.setThumbTintList(red);
                item.setTrackTintList(red);
            }
        } else {
            ColorStateList normalThumb = new ColorStateList(
                    states,
                    new int[]{
                            android.graphics.Color.rgb(25, 118, 210),
                            android.graphics.Color.WHITE
                    }
            );
            ColorStateList normalTrack = new ColorStateList(
                    states,
                    new int[]{
                            android.graphics.Color.rgb(100, 181, 246),
                            android.graphics.Color.rgb(117, 117, 117)
                    }
            );

            int normalTextColor = burstSwitch.getCurrentTextColor();

            for (Switch item : allSwitches) {
                item.setThumbTintList(normalThumb);
                item.setTrackTintList(normalTrack);
            }

            for (Switch item : lockedSwitches) {
                item.setTextColor(normalTextColor);
            }
        }
    }

    private void refreshNotificationIfActive() {
        if (!isAnyCameraServiceUseActive()) return;
        Intent i = new Intent(this, CameraForegroundService.class);
        i.setAction(CameraForegroundService.ACTION_REFRESH_NOTIFICATION);
        startForegroundService(i);
    }

    private void switchCameraIfActive() {
        if (!isAnyCameraServiceUseActive()) return;
        Intent i = new Intent(this, CameraForegroundService.class);
        i.setAction(CameraForegroundService.ACTION_SWITCH_CAMERA);
        startForegroundService(i);
    }

    private void syncFloatingSwitch() {
        boolean enabled = getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).getBoolean(CameraForegroundService.KEY_FLOAT_ENABLED, false);

        if (enabled && !Settings.canDrawOverlays(this)) {
            enabled = false;
            getSharedPreferences(
                    CameraForegroundService.PREFS, MODE_PRIVATE
            ).edit()
                    .putBoolean(CameraForegroundService.KEY_FLOAT_ENABLED, false)
                    .apply();
        }

        changingFloatingSwitch = true;
        floatingSwitch.setChecked(enabled);
        changingFloatingSwitch = false;
    }

    private void syncMiniFinderSwitch() {
        boolean enabled = getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                .getBoolean(CameraForegroundService.KEY_MINI_FINDER_ENABLED, false);
        if (enabled && !Settings.canDrawOverlays(this)) {
            enabled = false;
            getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE).edit()
                    .putBoolean(CameraForegroundService.KEY_MINI_FINDER_ENABLED, false).apply();
        }
        changingMiniFinderSwitch = true;
        miniFinderSwitch.setChecked(enabled);
        changingMiniFinderSwitch = false;
    }

    private void setFloatingShutterEnabled(boolean enabled) {
        if (enabled && !isResidentRunning()) {
            startResidentService();
        }

        Intent i = new Intent(this, CameraForegroundService.class);
        i.setAction(enabled
                ? CameraForegroundService.ACTION_FLOAT_ON
                : CameraForegroundService.ACTION_FLOAT_OFF);
        startForegroundService(i);

        changingFloatingSwitch = true;
        floatingSwitch.setChecked(enabled);
        changingFloatingSwitch = false;
        updateServiceButton();
    }

    private void updateCameraInfo() {
        boolean front = getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).getBoolean(KEY_USE_FRONT_CAMERA, false);

        cameraInfo.setText(
                front
                        ? "撮影: 前面カメラ/フラッシュOFF/AF待機 最大1.8秒/JPEG品質100"
                        : "撮影: 背面カメラ/フラッシュOFF/AF待機 最大1.8秒/JPEG品質100"
        );
    }

    private void updateSaveInfo() {
        String name = getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).getString(
                CameraForegroundService.KEY_SAVE_FOLDER_NAME,
                "Pictures/FinderlessCamera"
        );
        saveInfo.setText("保存先: " + name);
    }

    private void chooseSaveFolder() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION
                        | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                        | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                        | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
        );
        startActivityForResult(intent, REQ_SAVE_FOLDER);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode != REQ_SAVE_FOLDER
                || resultCode != RESULT_OK
                || data == null
                || data.getData() == null) {
            return;
        }

        Uri treeUri = data.getData();

        try {
            int takeFlags = data.getFlags()
                    & (Intent.FLAG_GRANT_READ_URI_PERMISSION
                    | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            getContentResolver().takePersistableUriPermission(treeUri, takeFlags);
        } catch (Exception ignored) { }

        String displayName = Uri.decode(treeUri.getLastPathSegment());
        if (displayName == null || displayName.trim().isEmpty()) {
            displayName = "選択したフォルダ";
        } else {
            int colon = displayName.lastIndexOf(':');
            if (colon >= 0 && colon < displayName.length() - 1) {
                displayName = displayName.substring(colon + 1);
            }
            int slash = displayName.lastIndexOf('/');
            if (slash >= 0 && slash < displayName.length() - 1) {
                displayName = displayName.substring(slash + 1);
            }
        }

        getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        ).edit()
                .putString(CameraForegroundService.KEY_SAVE_FOLDER_URI, treeUri.toString())
                .putString(CameraForegroundService.KEY_SAVE_FOLDER_NAME, displayName)
                .apply();

        updateSaveInfo();
    }

    private void recoverStaleFloatingState() {
        android.content.SharedPreferences prefs = getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        );

        boolean requested = prefs.getBoolean(
                CameraForegroundService.KEY_FLOAT_ENABLED, false
        );
        boolean overlayAlive = prefs.getBoolean(
                CameraForegroundService.KEY_FLOAT_OVERLAY_ALIVE, false
        );

        if (requested && !overlayAlive) {
            prefs.edit()
                    .putBoolean(CameraForegroundService.KEY_FLOAT_ENABLED, false)
                    .apply();
        }
    }

    private void shutdownMonitorModeCompletely() {
        android.content.SharedPreferences prefs = getSharedPreferences(
                CameraForegroundService.PREFS, MODE_PRIVATE
        );

        boolean front = prefs.getBoolean(KEY_PEEK_PREV_FRONT, false);
        boolean vibration = prefs.getBoolean(KEY_PEEK_PREV_VIBRATION, true);
        boolean swipe = prefs.getBoolean(KEY_PEEK_PREV_SWIPE, true);
        boolean floating = prefs.getBoolean(KEY_PEEK_PREV_FLOAT, false);

        prefs.edit()
                .putBoolean(KEY_PEEK_MODE, false)
                .putBoolean(CameraForegroundService.KEY_ENABLED, false)
                .putBoolean(KEY_SERVICE_RUNNING, false)
                .putBoolean(KEY_USE_FRONT_CAMERA, front)
                .putBoolean(CameraForegroundService.KEY_SHUTTER_VIBRATION, vibration)
                .putBoolean(KEY_NOTIFICATION_SWIPE_END, swipe)
                .putBoolean(CameraForegroundService.KEY_FLOAT_ENABLED, false)
                .apply();

        applyingPeekMode = true;
        frontCameraSwitch.setChecked(front);
        shutterVibrationSwitch.setChecked(vibration);
        notificationSwipeSwitch.setChecked(swipe);
        changingFloatingSwitch = true;
        floatingSwitch.setChecked(false);
        changingFloatingSwitch = false;
        applyingPeekMode = false;

        residentStartRequested = false;

        Intent stop = new Intent(this, CameraForegroundService.class);
        stop.setAction(CameraForegroundService.ACTION_MONITOR_SHUTDOWN);
        startService(stop);

        updatePeekModeUi();
        updateAutoCaptureButton();
        updateServiceButton();
        updateCameraInfo();
    }

    private void showDiagnosticReport() {
        TextView text = new TextView(this);
        text.setText(CrashLogger.getReport(this));
        text.setTextSize(12f);
        text.setTextIsSelectable(true);
        text.setPadding(24, 16, 24, 16);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(text);

        new AlertDialog.Builder(this)
                .setTitle("FinderlessCamera 診断ログ")
                .setView(scroll)
                .setPositiveButton("閉じる", null)
                .setNegativeButton("ログ消去", (dialog, which) ->
                        CrashLogger.clear(this)
                )
                .show();
    }

    private void requestNeededPermissions() {
        List<String> perms = new ArrayList<>();

        if (checkSelfPermission(Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            perms.add(Manifest.permission.CAMERA);
        }

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS);
        }

        if (!perms.isEmpty()) {
            requestPermissions(perms.toArray(new String[0]), REQ_PERMS);
        }
    }
}
