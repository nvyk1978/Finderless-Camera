package com.example.volumecamera;
import android.content.Context; import android.graphics.*; import android.util.AttributeSet; import android.view.Gravity; import android.widget.Switch;
class NToggleSwitchLegacy extends Switch {
 private final Paint track=new Paint(Paint.ANTI_ALIAS_FLAG),thumb=new Paint(Paint.ANTI_ALIAS_FLAG); private boolean lockedRed=false; private int trackColor=Color.rgb(42,34,34);
 public NToggleSwitchLegacy(Context c){super(c);init();} public NToggleSwitchLegacy(Context c,AttributeSet a){super(c,a);init();} public NToggleSwitchLegacy(Context c,AttributeSet a,int s){super(c,a,s);init();}
 private int dp(float v){return Math.round(v*getResources().getDisplayMetrics().density);}
 private void init(){setButtonDrawable(null);setShowText(false);setText("");setGravity(Gravity.CENTER);setSwitchMinWidth(dp(44));setMinimumWidth(dp(44));setMinimumHeight(dp(24));setPadding(0,0,0,0);setSwitchPadding(0);setThumbTextPadding(0);super.setThumbDrawable(null);super.setTrackDrawable(null);}
 public void setLockedRed(boolean v){lockedRed=v;invalidate();} public void setNTrackColor(int c){trackColor=c;invalidate();}
 @Override protected void onDraw(Canvas c){float d=getResources().getDisplayMetrics().density,w=44*d,h=24*d,r=12*d,l=(getWidth()-w)/2f,t=(getHeight()-h)/2f,rr=l+w,b=t+h;track.setColor(trackColor);c.drawRoundRect(l,t,rr,b,h/2,h/2,track);thumb.setColor(lockedRed?Color.rgb(68,17,0):(isChecked()?Color.rgb(68,85,119):Color.WHITE));c.drawCircle(isChecked()?rr-r:l+r,t+r,r,thumb);}
}
