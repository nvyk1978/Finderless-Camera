package com.example.volumecamera;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

/** Foreground bridge for QS: Android 16 only allows camera FGS startup from an eligible UI state. */
public class NotificationLauncherBootstrapActivity extends Activity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        NotificationLauncher.show(this);
        Intent service = new Intent(this, CameraForegroundService.class)
                .setAction(CameraForegroundService.ACTION_START);
        startForegroundService(service);
        finish();
        overridePendingTransition(0, 0);
    }
}
