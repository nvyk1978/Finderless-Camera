package com.example.volumecamera;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;

public class VolumeKeyAccessibilityService extends AccessibilityService {
    private boolean keyHeld = false;

    @Override
    protected boolean onKeyEvent(KeyEvent event) {
        if (event.getKeyCode() != KeyEvent.KEYCODE_VOLUME_DOWN) return false;

        boolean enabled = getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                .getBoolean(CameraForegroundService.KEY_ENABLED, false);
        if (!enabled) return false;

        if (event.getAction() == KeyEvent.ACTION_DOWN) {
            if (!keyHeld && event.getRepeatCount() == 0) {
                keyHeld = true;
                Intent intent = new Intent(this, CameraForegroundService.class);
                intent.setAction(CameraForegroundService.ACTION_CAPTURE);
                startService(intent);
            }
            return true;
        }

        if (event.getAction() == KeyEvent.ACTION_UP) {
            keyHeld = false;
            return true;
        }
        return true;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) { }

    @Override
    public void onInterrupt() { }
}
