package com.example.volumecamera;
import android.content.Intent; import android.os.Build; import android.service.quicksettings.TileService;
public class NotificationLauncherTileService extends TileService {@Override public void onClick(){super.onClick();Intent i=new Intent(this,CameraForegroundService.class);i.setAction(CameraForegroundService.ACTION_SHOW_NOTIFICATION);if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);}}
