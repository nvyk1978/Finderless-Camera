package com.example.volumecamera;

import android.content.Intent;
import android.service.quicksettings.TileService;

public class NotificationLauncherTileService extends TileService {
    @Override public void onClick() {
        super.onClick();
        boolean running = getSharedPreferences(CameraForegroundService.PREFS, MODE_PRIVATE)
                .getBoolean("service_running", false);
        if (running) {
            // The camera FGS already exists, so asking it to expose its launcher is safe.
            Intent i = new Intent(this, CameraForegroundService.class);
            i.setAction(CameraForegroundService.ACTION_SHOW_NOTIFICATION);
            startService(i);
        } else {
            // Important: a QS tile is not an eligible state for starting a camera FGS on
            // Android 16/target 36. Publish a normal notification instead.
            NotificationLauncher.show(this);
        }
    }
}
