package com.example.volumecamera;

import android.content.Intent;
import android.service.quicksettings.TileService;

public class NotificationLauncherTileService extends TileService {
    @Override public void onClick() {
        super.onClick();
        // QS controls only the user-facing launcher notification. Camera/overlay
        // lifetime is deliberately independent from this card.
        NotificationLauncher.show(this);
    }
}
