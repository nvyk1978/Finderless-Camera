package com.example.volumecamera;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.ImageFormat;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.Image;
import android.media.ImageReader;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.MediaStore;
import android.util.Size;
import android.widget.RemoteViews;

import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class CameraForegroundService extends Service {
    public static final String ACTION_START = "com.example.volumecamera.START";
    public static final String ACTION_TOGGLE = "com.example.volumecamera.TOGGLE";
    public static final String ACTION_CAPTURE = "com.example.volumecamera.CAPTURE";
    public static final String PREFS = "volume_camera_prefs";
    public static final String KEY_ENABLED = "enabled";

    private static final String CHANNEL_ID = "volume_camera_channel";
    private static final int NOTIFICATION_ID = 20;

    private HandlerThread cameraThread;
    private Handler cameraHandler;
    private CameraDevice cameraDevice;
    private CameraCaptureSession session;
    private ImageReader jpegReader;
    private ImageReader focusReader;
    private String cameraId;
    private Size jpegSize;
    private Size focusSize;
    private boolean openingCamera = false;
    private boolean enabled = false;
    private boolean captureInProgress = false;

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();
        cameraThread = new HandlerThread("VolumeCameraThread");
        cameraThread.start();
        cameraHandler = new Handler(cameraThread.getLooper());
        enabled = getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(KEY_ENABLED, false);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : ACTION_START;
        startForeground(NOTIFICATION_ID, buildNotification());

        if (ACTION_TOGGLE.equals(action)) {
            setEnabled(!enabled);
        } else if (ACTION_CAPTURE.equals(action)) {
            if (enabled) capturePhoto();
        } else if (enabled) {
            openCameraIfNeeded();
        }
        return START_STICKY;
    }

    private void setEnabled(boolean newValue) {
        enabled = newValue;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_ENABLED, enabled).apply();
        if (enabled) openCameraIfNeeded(); else closeCamera();
        updateNotification();
    }

    private Notification buildNotification() {
        Intent toggleIntent = new Intent(this, CameraForegroundService.class);
        toggleIntent.setAction(ACTION_TOGGLE);
        PendingIntent togglePending = PendingIntent.getService(
                this, 1, toggleIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent openPending = PendingIntent.getActivity(
                this, 2, openIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        RemoteViews view = new RemoteViews(getPackageName(), R.layout.notification_camera);
        view.setTextViewText(R.id.notification_status, enabled ? "撮影待機中" : "停止中");
        view.setTextViewText(R.id.notification_toggle, enabled ? "ON" : "OFF");
        view.setInt(R.id.notification_toggle, "setBackgroundResource",
                enabled ? R.drawable.toggle_on : R.drawable.toggle_off);
        view.setOnClickPendingIntent(R.id.notification_toggle, togglePending);

        return new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .setOngoing(true)
                .setContentIntent(openPending)
                .setCustomContentView(view)
                .setStyle(new Notification.DecoratedCustomViewStyle())
                .build();
    }

    private void updateNotification() {
        getSystemService(NotificationManager.class).notify(NOTIFICATION_ID, buildNotification());
    }

    private void createChannel() {
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "Volume Camera", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("音量ボタン撮影の待機状態");
        getSystemService(NotificationManager.class).createNotificationChannel(channel);
    }

    private void openCameraIfNeeded() {
        if (!enabled || cameraDevice != null || openingCamera) return;
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return;
        openingCamera = true;

        CameraManager manager = getSystemService(CameraManager.class);
        try {
            chooseBackCamera(manager);
            if (cameraId == null) {
                openingCamera = false;
                return;
            }
            manager.openCamera(cameraId, new CameraDevice.StateCallback() {
                @Override public void onOpened(CameraDevice camera) {
                    openingCamera = false;
                    cameraDevice = camera;
                    createSession();
                }
                @Override public void onDisconnected(CameraDevice camera) {
                    openingCamera = false;
                    camera.close();
                    cameraDevice = null;
                }
                @Override public void onError(CameraDevice camera, int error) {
                    openingCamera = false;
                    camera.close();
                    cameraDevice = null;
                }
            }, cameraHandler);
        } catch (Exception e) {
            openingCamera = false;
        }
    }

    private void chooseBackCamera(CameraManager manager) throws CameraAccessException {
        for (String id : manager.getCameraIdList()) {
            CameraCharacteristics c = manager.getCameraCharacteristics(id);
            Integer facing = c.get(CameraCharacteristics.LENS_FACING);
            if (facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) {
                StreamConfigurationMap map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
                if (map == null) continue;
                Size[] sizes = map.getOutputSizes(ImageFormat.JPEG);
                Size[] focusSizes = map.getOutputSizes(ImageFormat.YUV_420_888);
                if (sizes == null || sizes.length == 0 || focusSizes == null || focusSizes.length == 0) continue;
                cameraId = id;
                jpegSize = Arrays.stream(sizes)
                        .filter(s -> ((long) s.getWidth() * s.getHeight()) <= 12_500_000L)
                        .max(Comparator.comparingLong(s -> (long) s.getWidth() * s.getHeight()))
                        .orElse(Arrays.stream(sizes)
                                .max(Comparator.comparingLong(s -> (long) s.getWidth() * s.getHeight()))
                                .orElse(sizes[0]));
                focusSize = Arrays.stream(focusSizes)
                        .filter(s -> s.getWidth() >= 640 && s.getHeight() >= 480)
                        .min(Comparator.comparingLong(s -> (long) s.getWidth() * s.getHeight()))
                        .orElse(focusSizes[0]);
                return;
            }
        }
    }

    private void createSession() {
        if (cameraDevice == null || jpegSize == null || focusSize == null) return;
        closeReadersOnly();

        jpegReader = ImageReader.newInstance(jpegSize.getWidth(), jpegSize.getHeight(), ImageFormat.JPEG, 2);
        focusReader = ImageReader.newInstance(focusSize.getWidth(), focusSize.getHeight(), ImageFormat.YUV_420_888, 2);
        focusReader.setOnImageAvailableListener(reader -> {
            Image image = reader.acquireLatestImage();
            if (image != null) image.close();
        }, cameraHandler);
        jpegReader.setOnImageAvailableListener(this::saveImage, cameraHandler);

        List<android.view.Surface> surfaces = new ArrayList<>();
        surfaces.add(focusReader.getSurface());
        surfaces.add(jpegReader.getSurface());

        try {
            cameraDevice.createCaptureSession(surfaces, new CameraCaptureSession.StateCallback() {
                @Override public void onConfigured(CameraCaptureSession s) {
                    if (cameraDevice == null) return;
                    session = s;
                    try {
                        CaptureRequest.Builder preview = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
                        preview.addTarget(focusReader.getSurface());
                        preview.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
                        preview.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
                        preview.set(CaptureRequest.FLASH_MODE, CaptureRequest.FLASH_MODE_OFF);
                        session.setRepeatingRequest(preview.build(), null, cameraHandler);
                    } catch (CameraAccessException ignored) { }
                }
                @Override public void onConfigureFailed(CameraCaptureSession s) { }
            }, cameraHandler);
        } catch (CameraAccessException ignored) { }
    }

    private void capturePhoto() {
        if (!enabled) return;
        if (cameraDevice == null || session == null || jpegReader == null) {
            openCameraIfNeeded();
            return;
        }
        if (captureInProgress) return;
        captureInProgress = true;
        try {
            CaptureRequest.Builder still = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
            still.addTarget(jpegReader.getSurface());
            still.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            still.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
            still.set(CaptureRequest.FLASH_MODE, CaptureRequest.FLASH_MODE_OFF);
            session.capture(still.build(), new CameraCaptureSession.CaptureCallback() {
                @Override
                public void onCaptureCompleted(CameraCaptureSession s, CaptureRequest request,
                                               android.hardware.camera2.TotalCaptureResult result) {
                    vibrateOnce();
                    captureInProgress = false;
                }
                @Override
                public void onCaptureFailed(CameraCaptureSession s, CaptureRequest request,
                                            android.hardware.camera2.CaptureFailure failure) {
                    captureInProgress = false;
                }
            }, cameraHandler);
        } catch (CameraAccessException e) {
            captureInProgress = false;
        }
    }

    private void saveImage(ImageReader reader) {
        Image image = reader.acquireNextImage();
        if (image == null) return;
        try {
            ByteBuffer buffer = image.getPlanes()[0].getBuffer();
            byte[] bytes = new byte[buffer.remaining()];
            buffer.get(bytes);

            String name = "IMG_" + new SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US)
                    .format(new Date()) + ".jpg";
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, name);
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            if (Build.VERSION.SDK_INT >= 29) {
                values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/VolumeCamera");
                values.put(MediaStore.Images.Media.IS_PENDING, 1);
            }
            Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri != null) {
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out != null) out.write(bytes);
                }
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues done = new ContentValues();
                    done.put(MediaStore.Images.Media.IS_PENDING, 0);
                    getContentResolver().update(uri, done, null, null);
                }
            }
        } catch (Exception ignored) {
        } finally {
            image.close();
        }
    }

    private void vibrateOnce() {
        Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        if (vibrator == null || !vibrator.hasVibrator()) return;
        if (Build.VERSION.SDK_INT >= 26) {
            vibrator.vibrate(VibrationEffect.createOneShot(45, VibrationEffect.DEFAULT_AMPLITUDE));
        } else {
            vibrator.vibrate(45);
        }
    }

    private void closeReadersOnly() {
        if (jpegReader != null) { jpegReader.close(); jpegReader = null; }
        if (focusReader != null) { focusReader.close(); focusReader = null; }
    }

    private void closeCamera() {
        if (session != null) { session.close(); session = null; }
        if (cameraDevice != null) { cameraDevice.close(); cameraDevice = null; }
        closeReadersOnly();
        captureInProgress = false;
        openingCamera = false;
    }

    @Override
    public void onDestroy() {
        closeCamera();
        if (cameraThread != null) cameraThread.quitSafely();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
