package com.example.volumecamera;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.ImageFormat;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.CaptureResult;
import android.hardware.camera2.TotalCaptureResult;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.Image;
import android.media.ImageReader;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.util.Size;
import android.view.Surface;
import android.view.WindowManager;
import android.widget.RemoteViews;

import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class CameraForegroundService extends Service {
    public static final String ACTION_START = "com.example.volumecamera.START";
    public static final String ACTION_TOGGLE = "com.example.volumecamera.TOGGLE";
    public static final String ACTION_CAPTURE_ONCE = "com.example.volumecamera.CAPTURE_ONCE";

    public static final String PREFS = "finderless_camera_prefs";
    public static final String KEY_ENABLED = "enabled";
    public static final String KEY_SELECTED_CAMERAS = "selected_cameras";

    private static final String CHANNEL_ID = "finderless_camera_channel";
    private static final int NOTIFICATION_ID = 20;
    private static final long CAPTURE_INTERVAL_MS = 5000L;
    private static final long AF_FALLBACK_MS = 1800L;

    private HandlerThread cameraThread;
    private Handler cameraHandler;
    private boolean enabled = false;
    private boolean openingBatch = false;
    private boolean manualBatchPending = false;
    private boolean closeAfterManualBatch = false;

    private final Map<String, CameraContext> cameras = new LinkedHashMap<>();

    private static class CameraContext {
        String id;
        CameraDevice device;
        CameraCaptureSession session;
        CaptureRequest.Builder previewBuilder;
        ImageReader jpegReader;
        ImageReader focusReader;
        Size jpegSize;
        Size focusSize;
        int sensorOrientation = 90;
        boolean opening = false;
        boolean configured = false;
        boolean captureInProgress = false;
        boolean stillRequested = false;
    }

    private final Runnable autoCaptureRunnable = new Runnable() {
        @Override
        public void run() {
            if (!enabled) return;
            captureAllSelected(false);
            if (cameraHandler != null) {
                cameraHandler.postDelayed(this, CAPTURE_INTERVAL_MS);
            }
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();
        cameraThread = new HandlerThread("FinderlessCameraThread");
        cameraThread.start();
        cameraHandler = new Handler(cameraThread.getLooper());
        enabled = getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(KEY_ENABLED, false);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : ACTION_START;
        startForeground(NOTIFICATION_ID, buildNotification());

        if (ACTION_TOGGLE.equals(action)) {
            setEnabled(!enabled);
        } else if (ACTION_CAPTURE_ONCE.equals(action)) {
            manualBatchPending = true;
            closeAfterManualBatch = !enabled;
            ensureSelectedCamerasOpen();
            cameraHandler.postDelayed(this::tryManualBatch, 250L);
        } else if (enabled) {
            ensureSelectedCamerasOpen();
        }

        return START_STICKY;
    }

    private void setEnabled(boolean value) {
        enabled = value;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_ENABLED, enabled).apply();

        if (enabled) {
            ensureSelectedCamerasOpen();
        } else {
            stopAutoCapture();
            if (!manualBatchPending) closeAllCameras();
        }
        updateNotification();
    }

    private Notification buildNotification() {
        Intent toggleIntent = new Intent(this, CameraForegroundService.class);
        toggleIntent.setAction(ACTION_TOGGLE);
        PendingIntent togglePending = PendingIntent.getService(
                this, 1, toggleIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent captureIntent = new Intent(this, CameraForegroundService.class);
        captureIntent.setAction(ACTION_CAPTURE_ONCE);
        PendingIntent capturePending = PendingIntent.getService(
                this, 3, captureIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent openPending = PendingIntent.getActivity(
                this, 2, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        RemoteViews view = new RemoteViews(getPackageName(), R.layout.notification_camera);
        view.setTextViewText(R.id.notification_toggle, enabled ? "ON" : "OFF");
        view.setInt(
                R.id.notification_toggle,
                "setBackgroundResource",
                enabled ? R.drawable.toggle_on : R.drawable.toggle_off
        );
        view.setOnClickPendingIntent(R.id.notification_capture, capturePending);
        view.setOnClickPendingIntent(R.id.notification_toggle, togglePending);

        return new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .setOngoing(true)
                .setContentIntent(openPending)
                .setCustomContentView(view)
                .setStyle(new Notification.DecoratedCustomViewStyle())
                .build();
    }

    private void updateNotification() {
        getSystemService(NotificationManager.class).notify(NOTIFICATION_ID, buildNotification());
    }

    private void createChannel() {
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "FinderlessCamera",
                NotificationManager.IMPORTANCE_LOW
        );
        getSystemService(NotificationManager.class).createNotificationChannel(channel);
    }

    private Set<String> getSelectedCameraIds(CameraManager manager) throws CameraAccessException {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        Set<String> selected = new HashSet<>(
                prefs.getStringSet(KEY_SELECTED_CAMERAS, new HashSet<>())
        );

        List<String> validBackIds = new ArrayList<>();
        for (String id : manager.getCameraIdList()) {
            CameraCharacteristics c = manager.getCameraCharacteristics(id);
            Integer facing = c.get(CameraCharacteristics.LENS_FACING);
            StreamConfigurationMap map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            if (facing != null
                    && facing == CameraCharacteristics.LENS_FACING_BACK
                    && map != null
                    && map.getOutputSizes(ImageFormat.JPEG) != null) {
                validBackIds.add(id);
            }
        }

        selected.retainAll(validBackIds);
        if (selected.isEmpty() && !validBackIds.isEmpty()) {
            selected.add(validBackIds.get(0));
        }

        if (selected.size() > 1 && !isConcurrentSelectionSupported(manager, selected)) {
            String first = selected.iterator().next();
            selected.clear();
            selected.add(first);
        }
        return selected;
    }

    private boolean isConcurrentSelectionSupported(CameraManager manager, Set<String> selected) {
        if (selected.size() <= 1) return true;
        if (Build.VERSION.SDK_INT < 30) return false;
        try {
            for (Set<String> supported : manager.getConcurrentCameraIds()) {
                if (supported.containsAll(selected)) return true;
            }
        } catch (CameraAccessException ignored) { }
        return false;
    }

    private void ensureSelectedCamerasOpen() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return;
        if (openingBatch) return;

        CameraManager manager = getSystemService(CameraManager.class);
        try {
            Set<String> selected = getSelectedCameraIds(manager);
            if (selected.isEmpty()) return;

            // Close cameras no longer selected.
            List<String> toClose = new ArrayList<>();
            for (String id : cameras.keySet()) {
                if (!selected.contains(id)) toClose.add(id);
            }
            for (String id : toClose) closeCamera(id);

            openingBatch = true;
            for (String id : selected) {
                CameraContext existing = cameras.get(id);
                if (existing != null && (existing.device != null || existing.opening)) continue;
                openOneCamera(manager, id);
            }
            openingBatch = false;

            if (allSelectedConfigured(selected)) {
                if (enabled) startAutoCapture();
                tryManualBatch();
            }
        } catch (CameraAccessException ignored) {
            openingBatch = false;
        }
    }

    private void openOneCamera(CameraManager manager, String id) throws CameraAccessException {
        CameraCharacteristics c = manager.getCameraCharacteristics(id);
        StreamConfigurationMap map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
        if (map == null) return;

        Size[] jpegSizes = map.getOutputSizes(ImageFormat.JPEG);
        Size[] focusSizes = map.getOutputSizes(ImageFormat.YUV_420_888);
        if (jpegSizes == null || jpegSizes.length == 0
                || focusSizes == null || focusSizes.length == 0) return;

        CameraContext ctx = new CameraContext();
        ctx.id = id;
        ctx.jpegSize = chooseJpegSize(map);
        ctx.focusSize = Arrays.stream(focusSizes)
                .filter(s -> s.getWidth() >= 640 && s.getHeight() >= 480)
                .min(Comparator.comparingLong(s -> (long) s.getWidth() * s.getHeight()))
                .orElse(focusSizes[0]);

        Integer so = c.get(CameraCharacteristics.SENSOR_ORIENTATION);
        if (so != null) ctx.sensorOrientation = so;

        ctx.opening = true;
        cameras.put(id, ctx);

        manager.openCamera(id, new CameraDevice.StateCallback() {
            @Override
            public void onOpened(CameraDevice camera) {
                ctx.opening = false;
                ctx.device = camera;
                createSession(ctx);
            }

            @Override
            public void onDisconnected(CameraDevice camera) {
                camera.close();
                ctx.device = null;
                ctx.opening = false;
                ctx.configured = false;
            }

            @Override
            public void onError(CameraDevice camera, int error) {
                camera.close();
                ctx.device = null;
                ctx.opening = false;
                ctx.configured = false;
            }
        }, cameraHandler);
    }

    private void createSession(CameraContext ctx) {
        if (ctx.device == null || ctx.jpegSize == null || ctx.focusSize == null) return;

        closeReaders(ctx);

        ctx.jpegReader = ImageReader.newInstance(
                ctx.jpegSize.getWidth(),
                ctx.jpegSize.getHeight(),
                ImageFormat.JPEG,
                2
        );
        ctx.focusReader = ImageReader.newInstance(
                ctx.focusSize.getWidth(),
                ctx.focusSize.getHeight(),
                ImageFormat.YUV_420_888,
                2
        );

        ctx.focusReader.setOnImageAvailableListener(reader -> {
            Image image = reader.acquireLatestImage();
            if (image != null) image.close();
        }, cameraHandler);

        ctx.jpegReader.setOnImageAvailableListener(
                reader -> saveImage(reader, ctx.id),
                cameraHandler
        );

        List<Surface> surfaces = new ArrayList<>();
        surfaces.add(ctx.focusReader.getSurface());
        surfaces.add(ctx.jpegReader.getSurface());

        try {
            ctx.device.createCaptureSession(surfaces, new CameraCaptureSession.StateCallback() {
                @Override
                public void onConfigured(CameraCaptureSession session) {
                    if (ctx.device == null) return;
                    ctx.session = session;
                    try {
                        ctx.previewBuilder = ctx.device.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
                        ctx.previewBuilder.addTarget(ctx.focusReader.getSurface());
                        ctx.previewBuilder.set(
                                CaptureRequest.CONTROL_AF_MODE,
                                CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE
                        );
                        ctx.previewBuilder.set(
                                CaptureRequest.CONTROL_AE_MODE,
                                CaptureRequest.CONTROL_AE_MODE_ON
                        );
                        ctx.previewBuilder.set(
                                CaptureRequest.FLASH_MODE,
                                CaptureRequest.FLASH_MODE_OFF
                        );
                        ctx.session.setRepeatingRequest(
                                ctx.previewBuilder.build(),
                                null,
                                cameraHandler
                        );
                        ctx.configured = true;

                        if (allOpenCamerasConfigured()) {
                            if (enabled) startAutoCapture();
                            tryManualBatch();
                        }
                    } catch (CameraAccessException ignored) { }
                }

                @Override
                public void onConfigureFailed(CameraCaptureSession session) {
                    ctx.configured = false;
                }
            }, cameraHandler);
        } catch (CameraAccessException ignored) { }
    }

    private boolean allSelectedConfigured(Set<String> selected) {
        for (String id : selected) {
            CameraContext ctx = cameras.get(id);
            if (ctx == null || !ctx.configured) return false;
        }
        return true;
    }

    private boolean allOpenCamerasConfigured() {
        if (cameras.isEmpty()) return false;
        for (CameraContext ctx : cameras.values()) {
            if (!ctx.configured) return false;
        }
        return true;
    }

    private void startAutoCapture() {
        if (cameraHandler == null || !enabled) return;
        cameraHandler.removeCallbacks(autoCaptureRunnable);
        cameraHandler.postDelayed(autoCaptureRunnable, CAPTURE_INTERVAL_MS);
    }

    private void stopAutoCapture() {
        if (cameraHandler != null) cameraHandler.removeCallbacks(autoCaptureRunnable);
    }

    private void tryManualBatch() {
        if (!manualBatchPending) return;
        if (!allOpenCamerasConfigured()) {
            if (cameraHandler != null) {
                cameraHandler.postDelayed(this::tryManualBatch, 250L);
            }
            return;
        }

        manualBatchPending = false;
        captureAllSelected(true);
    }

    private void captureAllSelected(boolean manual) {
        if (!manual && !enabled) return;
        if (cameras.isEmpty()) {
            if (manual) manualBatchPending = true;
            ensureSelectedCamerasOpen();
            return;
        }

        for (CameraContext ctx : new ArrayList<>(cameras.values())) {
            capturePhoto(ctx, manual);
        }
    }

    private Size chooseJpegSize(StreamConfigurationMap map) {
        Size[] sizes = map.getOutputSizes(ImageFormat.JPEG);
        if (sizes == null || sizes.length == 0) return new Size(1920, 1080);

        double targetRatio = 16.0 / 9.0;
        try {
            WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
            if (wm != null) {
                DisplayMetrics metrics = new DisplayMetrics();
                wm.getDefaultDisplay().getRealMetrics(metrics);
                int longSide = Math.max(metrics.widthPixels, metrics.heightPixels);
                int shortSide = Math.min(metrics.widthPixels, metrics.heightPixels);
                if (shortSide > 0) {
                    targetRatio = (double) longSide / (double) shortSide;
                }
            }
        } catch (Exception ignored) { }

        double bestRatioError = Double.MAX_VALUE;
        for (Size s : sizes) {
            int longSide = Math.max(s.getWidth(), s.getHeight());
            int shortSide = Math.min(s.getWidth(), s.getHeight());
            if (shortSide == 0) continue;
            double ratio = (double) longSide / (double) shortSide;
            bestRatioError = Math.min(bestRatioError, Math.abs(ratio - targetRatio));
        }

        final double allowedError = bestRatioError + 0.015;
        Size best = sizes[0];
        long bestPixels = 0L;

        for (Size s : sizes) {
            int longSide = Math.max(s.getWidth(), s.getHeight());
            int shortSide = Math.min(s.getWidth(), s.getHeight());
            if (shortSide == 0) continue;

            double ratio = (double) longSide / (double) shortSide;
            double error = Math.abs(ratio - targetRatio);
            long pixels = (long) s.getWidth() * s.getHeight();

            if (error <= allowedError && pixels > bestPixels) {
                best = s;
                bestPixels = pixels;
            }
        }
        return best;
    }

    private void capturePhoto(CameraContext ctx, boolean manual) {
        if (!manual && !enabled) return;
        if (ctx.device == null
                || ctx.session == null
                || ctx.jpegReader == null
                || ctx.previewBuilder == null
                || !ctx.configured) {
            if (manual) manualBatchPending = true;
            ensureSelectedCamerasOpen();
            return;
        }
        if (ctx.captureInProgress) return;

        ctx.captureInProgress = true;
        ctx.stillRequested = false;

        try {
            ctx.previewBuilder.set(
                    CaptureRequest.CONTROL_AF_TRIGGER,
                    CaptureRequest.CONTROL_AF_TRIGGER_START
            );

            ctx.session.capture(
                    ctx.previewBuilder.build(),
                    new CameraCaptureSession.CaptureCallback() {
                        @Override
                        public void onCaptureCompleted(
                                CameraCaptureSession session,
                                CaptureRequest request,
                                TotalCaptureResult result
                        ) {
                            Integer afState = result.get(CaptureResult.CONTROL_AF_STATE);
                            if (afState == null
                                    || afState == CaptureResult.CONTROL_AF_STATE_FOCUSED_LOCKED
                                    || afState == CaptureResult.CONTROL_AF_STATE_NOT_FOCUSED_LOCKED
                                    || afState == CaptureResult.CONTROL_AF_STATE_PASSIVE_FOCUSED
                                    || afState == CaptureResult.CONTROL_AF_STATE_PASSIVE_UNFOCUSED) {
                                requestStill(ctx);
                            }
                        }
                    },
                    cameraHandler
            );

            cameraHandler.postDelayed(
                    () -> {
                        if (ctx.captureInProgress) requestStill(ctx);
                    },
                    AF_FALLBACK_MS
            );
        } catch (CameraAccessException e) {
            ctx.captureInProgress = false;
        }
    }

    private void requestStill(CameraContext ctx) {
        if (!ctx.captureInProgress || ctx.stillRequested) return;
        ctx.stillRequested = true;
        takeStillPhoto(ctx);
    }

    private int getJpegOrientation(CameraContext ctx) {
        int deviceDegrees = 0;
        try {
            WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
            if (wm != null) {
                int rotation = wm.getDefaultDisplay().getRotation();
                if (rotation == Surface.ROTATION_90) deviceDegrees = 90;
                else if (rotation == Surface.ROTATION_180) deviceDegrees = 180;
                else if (rotation == Surface.ROTATION_270) deviceDegrees = 270;
            }
        } catch (Exception ignored) { }
        return (ctx.sensorOrientation - deviceDegrees + 360) % 360;
    }

    private void takeStillPhoto(CameraContext ctx) {
        if (ctx.device == null || ctx.session == null || ctx.jpegReader == null) {
            finishFocusCycle(ctx);
            return;
        }

        try {
            CaptureRequest.Builder still = ctx.device.createCaptureRequest(
                    CameraDevice.TEMPLATE_STILL_CAPTURE
            );
            still.addTarget(ctx.jpegReader.getSurface());
            still.set(
                    CaptureRequest.CONTROL_AF_MODE,
                    CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE
            );
            still.set(
                    CaptureRequest.CONTROL_AE_MODE,
                    CaptureRequest.CONTROL_AE_MODE_ON
            );
            still.set(CaptureRequest.FLASH_MODE, CaptureRequest.FLASH_MODE_OFF);
            still.set(CaptureRequest.JPEG_ORIENTATION, getJpegOrientation(ctx));
            still.set(CaptureRequest.JPEG_QUALITY, (byte) 100);

            ctx.session.capture(
                    still.build(),
                    new CameraCaptureSession.CaptureCallback() {
                        @Override
                        public void onCaptureCompleted(
                                CameraCaptureSession session,
                                CaptureRequest request,
                                TotalCaptureResult result
                        ) {
                            vibrateOnce();
                            finishFocusCycle(ctx);
                            maybeCloseAfterManualBatch();
                        }

                        @Override
                        public void onCaptureFailed(
                                CameraCaptureSession session,
                                CaptureRequest request,
                                android.hardware.camera2.CaptureFailure failure
                        ) {
                            finishFocusCycle(ctx);
                            maybeCloseAfterManualBatch();
                        }
                    },
                    cameraHandler
            );
        } catch (CameraAccessException e) {
            finishFocusCycle(ctx);
            maybeCloseAfterManualBatch();
        }
    }

    private void maybeCloseAfterManualBatch() {
        if (!closeAfterManualBatch) return;

        for (CameraContext c : cameras.values()) {
            if (c.captureInProgress) return;
        }

        closeAfterManualBatch = false;
        cameraHandler.postDelayed(this::closeAllCameras, 150L);
    }

    private void finishFocusCycle(CameraContext ctx) {
        ctx.captureInProgress = false;
        ctx.stillRequested = false;

        if (ctx.session == null || ctx.previewBuilder == null || cameraHandler == null) return;

        try {
            ctx.previewBuilder.set(
                    CaptureRequest.CONTROL_AF_TRIGGER,
                    CaptureRequest.CONTROL_AF_TRIGGER_CANCEL
            );
            ctx.session.capture(ctx.previewBuilder.build(), null, cameraHandler);

            ctx.previewBuilder.set(
                    CaptureRequest.CONTROL_AF_TRIGGER,
                    CaptureRequest.CONTROL_AF_TRIGGER_IDLE
            );
            ctx.session.setRepeatingRequest(
                    ctx.previewBuilder.build(),
                    null,
                    cameraHandler
            );
        } catch (CameraAccessException ignored) { }
    }

    private void saveImage(ImageReader reader, String cameraId) {
        Image image = reader.acquireNextImage();
        if (image == null) return;

        try {
            ByteBuffer buffer = image.getPlanes()[0].getBuffer();
            byte[] bytes = new byte[buffer.remaining()];
            buffer.get(bytes);

            String safeCameraId = cameraId.replaceAll("[^A-Za-z0-9_-]", "_");
            String name = "IMG_"
                    + new SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(new Date())
                    + "_C" + safeCameraId
                    + ".jpg";

            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, name);
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");

            if (Build.VERSION.SDK_INT >= 29) {
                values.put(
                        MediaStore.Images.Media.RELATIVE_PATH,
                        "Pictures/FinderlessCamera"
                );
                values.put(MediaStore.Images.Media.IS_PENDING, 1);
            }

            Uri uri = getContentResolver().insert(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    values
            );

            if (uri != null) {
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out != null) out.write(bytes);
                }

                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues done = new ContentValues();
                    done.put(MediaStore.Images.Media.IS_PENDING, 0);
                    getContentResolver().update(uri, done, null, null);
                }
            }
        } catch (Exception ignored) {
        } finally {
            image.close();
        }
    }

    private void vibrateOnce() {
        Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        if (vibrator == null || !vibrator.hasVibrator()) return;

        if (Build.VERSION.SDK_INT >= 26) {
            vibrator.vibrate(VibrationEffect.createOneShot(55, 220));
        } else {
            vibrator.vibrate(55);
        }
    }

    private void closeReaders(CameraContext ctx) {
        if (ctx.jpegReader != null) {
            ctx.jpegReader.close();
            ctx.jpegReader = null;
        }
        if (ctx.focusReader != null) {
            ctx.focusReader.close();
            ctx.focusReader = null;
        }
    }

    private void closeCamera(String id) {
        CameraContext ctx = cameras.remove(id);
        if (ctx == null) return;

        if (ctx.session != null) {
            ctx.session.close();
            ctx.session = null;
        }
        if (ctx.device != null) {
            ctx.device.close();
            ctx.device = null;
        }
        closeReaders(ctx);
        ctx.previewBuilder = null;
        ctx.configured = false;
        ctx.captureInProgress = false;
        ctx.opening = false;
    }

    private void closeAllCameras() {
        stopAutoCapture();
        for (String id : new ArrayList<>(cameras.keySet())) {
            closeCamera(id);
        }
        openingBatch = false;
    }

    @Override
    public void onDestroy() {
        closeAllCameras();
        if (cameraThread != null) {
            cameraThread.quitSafely();
            cameraThread = null;
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
