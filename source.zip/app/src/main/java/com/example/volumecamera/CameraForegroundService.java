package com.example.volumecamera;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.ImageFormat;
import android.graphics.Paint;
import android.graphics.Canvas;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.CaptureResult;
import android.hardware.camera2.TotalCaptureResult;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.Image;
import android.media.ImageReader;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.Size;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.View;
import android.view.WindowManager;
import android.widget.RemoteViews;
import android.widget.TextView;

import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class CameraForegroundService extends Service {
    public static final String ACTION_START = "com.example.volumecamera.START";
    public static final String ACTION_TOGGLE = "com.example.volumecamera.TOGGLE";
    public static final String ACTION_CAPTURE_ONCE = "com.example.volumecamera.CAPTURE_ONCE";
    public static final String ACTION_FLOAT_ON = "com.example.volumecamera.FLOAT_ON";
    public static final String ACTION_FLOAT_OFF = "com.example.volumecamera.FLOAT_OFF";
    public static final String ACTION_STOP_SERVICE = "com.example.volumecamera.STOP_SERVICE";

    public static final String PREFS = "finderless_camera_prefs";
    public static final String KEY_ENABLED = "enabled";
    public static final String KEY_FLOAT_ENABLED = "float_enabled";
    private static final String KEY_FLOAT_X = "float_x";
    private static final String KEY_FLOAT_Y = "float_y";

    private static final String CHANNEL_ID = "finderless_camera_channel";
    private static final int NOTIFICATION_ID = 20;
    private static final long CAPTURE_INTERVAL_MS = 5000L;
    private static final long AF_FALLBACK_MS = 1800L;
    private static final int FLOAT_SIZE_PX = 200;
    private static final int DELETE_TARGET_SIZE_PX = 200;
    private static final long LONG_PRESS_MS = 450L;
    private static final float SNAP_DISTANCE_PX = 200f;
    private static final float RELEASE_DISTANCE_PX = 260f;

    private HandlerThread cameraThread;
    private Handler cameraHandler;
    private final Handler mainHandler = new Handler();

    private CameraDevice cameraDevice;
    private CameraCaptureSession session;
    private CaptureRequest.Builder previewBuilder;
    private ImageReader jpegReader;
    private ImageReader focusReader;
    private int sensorOrientation = 90;
    private Size jpegSize;
    private Size focusSize;

    private boolean openingCamera = false;
    private boolean enabled = false;
    private boolean captureInProgress = false;
    private boolean stillRequested = false;
    private boolean manualCapturePending = false;
    private boolean closeAfterManualCapture = false;
    private boolean manualQueued = false;

    private WindowManager windowManager;
    private FloatingShutterView floatingShutter;
    private WindowManager.LayoutParams floatingParams;
    private TextView deleteTarget;
    private WindowManager.LayoutParams deleteTargetParams;
    private boolean draggingFloat = false;
    private boolean snappedToDelete = false;
    private float downRawX;
    private float downRawY;
    private int downWindowX;
    private int downWindowY;
    private long downTimeMs;
    private Runnable longPressRunnable;

    private final Runnable autoCaptureRunnable = new Runnable() {
        @Override
        public void run() {
            if (!enabled) return;
            CrashLogger.log(CameraForegroundService.this, "AUTO tick");
            capturePhoto(false);
            if (cameraHandler != null) {
                cameraHandler.postDelayed(this, CAPTURE_INTERVAL_MS);
            }
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        CrashLogger.log(this, "SERVICE onCreate");
        createChannel();

        cameraThread = new HandlerThread("FinderlessCameraThread");
        cameraThread.start();
        cameraHandler = new Handler(cameraThread.getLooper());

        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        enabled = prefs.getBoolean(KEY_ENABLED, false);
        prefs.edit().putBoolean(KEY_FLOAT_ENABLED, false).apply();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : ACTION_START;
        CrashLogger.log(this, "SERVICE onStartCommand action=" + action + " flags=" + flags + " startId=" + startId + " enabled=" + enabled);
        CrashLogger.log(this, "SERVICE startForeground BEGIN");
        startForeground(NOTIFICATION_ID, buildNotification());
        CrashLogger.log(this, "SERVICE startForeground OK");

        if (ACTION_STOP_SERVICE.equals(action)) {
            CrashLogger.log(this, "SERVICE stop requested");
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putBoolean("service_running", false)
                    .putBoolean(KEY_ENABLED, false)
                    .putBoolean(KEY_FLOAT_ENABLED, false)
                    .apply();
            removeFloatingShutter();
            closeCamera();
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
            return START_NOT_STICKY;
        } else if (ACTION_TOGGLE.equals(action)) {
            setEnabled(!enabled);
        } else if (ACTION_CAPTURE_ONCE.equals(action)) {
            handleManualCapture();
        } else if (ACTION_FLOAT_ON.equals(action)) {
            setFloatingEnabled(true);
        } else if (ACTION_FLOAT_OFF.equals(action)) {
            setFloatingEnabled(false);
        } else if (enabled) {
            ensureCameraOpen(true);
        }

        return START_NOT_STICKY;
    }

    private void setEnabled(boolean newValue) {
        CrashLogger.log(this, "SERVICE setEnabled " + newValue);
        enabled = newValue;
        getSharedPreferences(PREFS, MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_ENABLED, enabled)
                .apply();

        if (enabled) {
            ensureCameraOpen(true);
        } else {
            stopAutoCapture();
            if (!manualCapturePending && !captureInProgress) {
                closeCamera();
            }
        }
        updateNotification();
    }

    private void handleManualCapture() {
        CrashLogger.log(this, "CAPTURE manual requested enabled=" + enabled);
        manualCapturePending = true;
        closeAfterManualCapture = !enabled;

        if (cameraHandler == null) return;
        cameraHandler.post(() -> {
            if (cameraDevice != null && session != null && previewBuilder != null) {
                manualCapturePending = false;
                capturePhoto(true);
            } else {
                ensureCameraOpen(true);
            }
        });
    }

    private Notification buildNotification() {
        Intent toggleIntent = new Intent(this, CameraForegroundService.class);
        toggleIntent.setAction(ACTION_TOGGLE);
        PendingIntent togglePending = PendingIntent.getService(
                this,
                1,
                toggleIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Intent captureIntent = new Intent(this, CameraForegroundService.class);
        captureIntent.setAction(ACTION_CAPTURE_ONCE);
        PendingIntent capturePending = PendingIntent.getService(
                this,
                3,
                captureIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent openPending = PendingIntent.getActivity(
                this,
                2,
                openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        RemoteViews view = new RemoteViews(getPackageName(), R.layout.notification_camera);
        view.setTextViewText(R.id.notification_toggle, enabled ? "ON" : "OFF");
        view.setInt(
                R.id.notification_toggle,
                "setBackgroundResource",
                enabled ? R.drawable.toggle_on : R.drawable.toggle_off
        );
        view.setOnClickPendingIntent(R.id.notification_capture, capturePending);
        view.setOnClickPendingIntent(R.id.notification_toggle, togglePending);

        return new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .setOngoing(true)
                .setContentIntent(openPending)
                .setCustomContentView(view)
                .setStyle(new Notification.DecoratedCustomViewStyle())
                .build();
    }

    private void updateNotification() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) nm.notify(NOTIFICATION_ID, buildNotification());
    }

    private void createChannel() {
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "FinderlessCamera",
                NotificationManager.IMPORTANCE_LOW
        );
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) nm.createNotificationChannel(channel);
    }

    private void ensureCameraOpen(boolean allowWhenAutoOff) {
        CrashLogger.log(this, "CAMERA ensureOpen allowWhenAutoOff=" + allowWhenAutoOff + " enabled=" + enabled + " device=" + (cameraDevice != null) + " opening=" + openingCamera);
        if ((!enabled && !allowWhenAutoOff) || cameraDevice != null || openingCamera) return;
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return;

        openingCamera = true;
        CameraManager manager = getSystemService(CameraManager.class);
        if (manager == null) {
            openingCamera = false;
            return;
        }

        try {
            String selectedCameraId = chooseAutomaticBackCamera(manager);
            if (selectedCameraId == null) {
                openingCamera = false;
                return;
            }

            manager.openCamera(selectedCameraId, new CameraDevice.StateCallback() {
                @Override
                public void onOpened(CameraDevice camera) {
                    CrashLogger.log(CameraForegroundService.this, "CAMERA onOpened");
                    openingCamera = false;
                    cameraDevice = camera;
                    createSession();
                }

                @Override
                public void onDisconnected(CameraDevice camera) {
                    CrashLogger.log(CameraForegroundService.this, "CAMERA onDisconnected");
                    openingCamera = false;
                    camera.close();
                    cameraDevice = null;
                    session = null;
                }

                @Override
                public void onError(CameraDevice camera, int error) {
                    CrashLogger.log(CameraForegroundService.this, "CAMERA onError code=" + error);
                    openingCamera = false;
                    camera.close();
                    cameraDevice = null;
                    session = null;
                }
            }, cameraHandler);
        } catch (Exception e) {
            openingCamera = false;
        }
    }

    private String chooseAutomaticBackCamera(CameraManager manager) {
        jpegSize = null;
        focusSize = null;

        try {
            for (String id : manager.getCameraIdList()) {
                try {
                    CameraCharacteristics c = manager.getCameraCharacteristics(id);
                    Integer facing = c.get(CameraCharacteristics.LENS_FACING);
                    if (facing == null || facing != CameraCharacteristics.LENS_FACING_BACK) continue;

                    StreamConfigurationMap map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
                    if (map == null) continue;

                    Size[] jpegSizes = map.getOutputSizes(ImageFormat.JPEG);
                    Size[] yuvSizes = map.getOutputSizes(ImageFormat.YUV_420_888);
                    if (jpegSizes == null || jpegSizes.length == 0 || yuvSizes == null || yuvSizes.length == 0) continue;

                    jpegSize = chooseJpegSize(map);
                    focusSize = Arrays.stream(yuvSizes)
                            .filter(s -> s.getWidth() >= 640 && s.getHeight() >= 480)
                            .min(Comparator.comparingLong(s -> (long) s.getWidth() * s.getHeight()))
                            .orElse(yuvSizes[0]);

                    Integer so = c.get(CameraCharacteristics.SENSOR_ORIENTATION);
                    if (so != null) sensorOrientation = so;
                    return id;
                } catch (Exception ignored) { }
            }
        } catch (Exception ignored) { }

        jpegSize = null;
        focusSize = null;
        return null;
    }

    private Size chooseJpegSize(StreamConfigurationMap map) {
        Size[] sizes = map.getOutputSizes(ImageFormat.JPEG);
        if (sizes == null || sizes.length == 0) return new Size(1920, 1080);

        double targetRatio = 16.0 / 9.0;
        try {
            WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
            if (wm != null) {
                DisplayMetrics metrics = new DisplayMetrics();
                wm.getDefaultDisplay().getRealMetrics(metrics);
                int longSide = Math.max(metrics.widthPixels, metrics.heightPixels);
                int shortSide = Math.min(metrics.widthPixels, metrics.heightPixels);
                if (shortSide > 0) {
                    targetRatio = (double) longSide / (double) shortSide;
                }
            }
        } catch (Exception ignored) { }

        double closestError = Double.MAX_VALUE;
        for (Size s : sizes) {
            int longSide = Math.max(s.getWidth(), s.getHeight());
            int shortSide = Math.min(s.getWidth(), s.getHeight());
            if (shortSide == 0) continue;
            double ratio = (double) longSide / (double) shortSide;
            closestError = Math.min(closestError, Math.abs(ratio - targetRatio));
        }

        double allowedError = closestError + 0.015;
        Size best = sizes[0];
        long bestPixels = 0;

        for (Size s : sizes) {
            int longSide = Math.max(s.getWidth(), s.getHeight());
            int shortSide = Math.min(s.getWidth(), s.getHeight());
            if (shortSide == 0) continue;

            double ratio = (double) longSide / (double) shortSide;
            double error = Math.abs(ratio - targetRatio);
            long pixels = (long) s.getWidth() * s.getHeight();

            if (error <= allowedError && pixels > bestPixels) {
                best = s;
                bestPixels = pixels;
            }
        }
        return best;
    }

    private void createSession() {
        CrashLogger.log(this, "CAMERA createSession BEGIN jpeg=" + jpegSize + " focus=" + focusSize);
        if (cameraDevice == null || jpegSize == null || focusSize == null) return;
        closeReadersOnly();

        jpegReader = ImageReader.newInstance(
                jpegSize.getWidth(),
                jpegSize.getHeight(),
                ImageFormat.JPEG,
                2
        );
        focusReader = ImageReader.newInstance(
                focusSize.getWidth(),
                focusSize.getHeight(),
                ImageFormat.YUV_420_888,
                2
        );

        focusReader.setOnImageAvailableListener(reader -> {
            Image image = reader.acquireLatestImage();
            if (image != null) image.close();
        }, cameraHandler);

        jpegReader.setOnImageAvailableListener(this::saveImage, cameraHandler);

        List<Surface> surfaces = new ArrayList<>();
        surfaces.add(focusReader.getSurface());
        surfaces.add(jpegReader.getSurface());

        try {
            cameraDevice.createCaptureSession(
                    surfaces,
                    new CameraCaptureSession.StateCallback() {
                        @Override
                        public void onConfigured(CameraCaptureSession configuredSession) {
                            CrashLogger.log(CameraForegroundService.this, "CAMERA session configured");
                            if (cameraDevice == null) return;
                            session = configuredSession;

                            try {
                                previewBuilder = cameraDevice.createCaptureRequest(
                                        CameraDevice.TEMPLATE_PREVIEW
                                );
                                previewBuilder.addTarget(focusReader.getSurface());
                                previewBuilder.set(
                                        CaptureRequest.CONTROL_AF_MODE,
                                        CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE
                                );
                                previewBuilder.set(
                                        CaptureRequest.CONTROL_AE_MODE,
                                        CaptureRequest.CONTROL_AE_MODE_ON
                                );
                                previewBuilder.set(
                                        CaptureRequest.FLASH_MODE,
                                        CaptureRequest.FLASH_MODE_OFF
                                );

                                session.setRepeatingRequest(
                                        previewBuilder.build(),
                                        null,
                                        cameraHandler
                                );

                                if (enabled) startAutoCapture();

                                if (manualCapturePending) {
                                    manualCapturePending = false;
                                    cameraHandler.postDelayed(
                                            () -> capturePhoto(true),
                                            250L
                                    );
                                }
                            } catch (CameraAccessException ignored) { }
                        }

                        @Override
                        public void onConfigureFailed(CameraCaptureSession failedSession) {
                            CrashLogger.log(CameraForegroundService.this, "CAMERA session configure FAILED");
                            session = null;
                        }
                    },
                    cameraHandler
            );
        } catch (CameraAccessException ignored) { }
    }

    private void startAutoCapture() {
        CrashLogger.log(this, "AUTO start intervalMs=" + CAPTURE_INTERVAL_MS);
        if (cameraHandler == null || !enabled) return;
        cameraHandler.removeCallbacks(autoCaptureRunnable);
        cameraHandler.postDelayed(autoCaptureRunnable, CAPTURE_INTERVAL_MS);
    }

    private void stopAutoCapture() {
        CrashLogger.log(this, "AUTO stop");
        if (cameraHandler != null) {
            cameraHandler.removeCallbacks(autoCaptureRunnable);
        }
    }

    private void capturePhoto(boolean manual) {
        CrashLogger.log(this, "CAPTURE begin manual=" + manual + " enabled=" + enabled + " inProgress=" + captureInProgress);
        if (!manual && !enabled) return;

        if (cameraDevice == null || session == null
                || jpegReader == null || previewBuilder == null) {
            if (manual) manualCapturePending = true;
            ensureCameraOpen(true);
            return;
        }

        if (captureInProgress) {
            if (manual) {
                manualQueued = true;
                CrashLogger.log(this, "CAPTURE manual queued during auto capture");
            }
            return;
        }

        captureInProgress = true;
        stillRequested = false;

        try {
            previewBuilder.set(
                    CaptureRequest.CONTROL_AF_TRIGGER,
                    CaptureRequest.CONTROL_AF_TRIGGER_START
            );

            session.capture(
                    previewBuilder.build(),
                    new CameraCaptureSession.CaptureCallback() {
                        @Override
                        public void onCaptureCompleted(
                                CameraCaptureSession s,
                                CaptureRequest request,
                                TotalCaptureResult result
                        ) {
                            Integer afState = result.get(
                                    CaptureResult.CONTROL_AF_STATE
                            );

                            if (afState == null
                                    || afState == CaptureResult.CONTROL_AF_STATE_FOCUSED_LOCKED
                                    || afState == CaptureResult.CONTROL_AF_STATE_NOT_FOCUSED_LOCKED
                                    || afState == CaptureResult.CONTROL_AF_STATE_PASSIVE_FOCUSED
                                    || afState == CaptureResult.CONTROL_AF_STATE_PASSIVE_UNFOCUSED) {
                                requestStill();
                            }
                        }
                    },
                    cameraHandler
            );

            cameraHandler.postDelayed(() -> {
                if (captureInProgress) requestStill();
            }, AF_FALLBACK_MS);

        } catch (CameraAccessException e) {
            captureInProgress = false;
            stillRequested = false;
        }
    }

    private void requestStill() {
        CrashLogger.log(this, "CAPTURE requestStill inProgress=" + captureInProgress + " stillRequested=" + stillRequested);
        if (!captureInProgress || stillRequested) return;
        stillRequested = true;
        takeStillPhoto();
    }

    private int getJpegOrientation() {
        int deviceDegrees = 0;
        try {
            WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
            if (wm != null) {
                int rotation = wm.getDefaultDisplay().getRotation();
                if (rotation == Surface.ROTATION_90) deviceDegrees = 90;
                else if (rotation == Surface.ROTATION_180) deviceDegrees = 180;
                else if (rotation == Surface.ROTATION_270) deviceDegrees = 270;
            }
        } catch (Exception ignored) { }

        return (sensorOrientation - deviceDegrees + 360) % 360;
    }

    private void takeStillPhoto() {
        CrashLogger.log(this, "CAPTURE takeStillPhoto");
        if (!captureInProgress || cameraDevice == null
                || session == null || jpegReader == null) {
            finishFocusCycle();
            return;
        }

        try {
            CaptureRequest.Builder still = cameraDevice.createCaptureRequest(
                    CameraDevice.TEMPLATE_STILL_CAPTURE
            );
            still.addTarget(jpegReader.getSurface());
            still.set(
                    CaptureRequest.CONTROL_AF_MODE,
                    CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE
            );
            still.set(
                    CaptureRequest.CONTROL_AE_MODE,
                    CaptureRequest.CONTROL_AE_MODE_ON
            );
            still.set(CaptureRequest.FLASH_MODE, CaptureRequest.FLASH_MODE_OFF);
            still.set(CaptureRequest.JPEG_ORIENTATION, getJpegOrientation());
            still.set(CaptureRequest.JPEG_QUALITY, (byte) 100);

            session.capture(
                    still.build(),
                    new CameraCaptureSession.CaptureCallback() {
                        @Override
                        public void onCaptureCompleted(
                                CameraCaptureSession s,
                                CaptureRequest request,
                                TotalCaptureResult result
                        ) {
                            CrashLogger.log(CameraForegroundService.this, "CAPTURE still completed");
                            vibrateOnce();

                            boolean shouldClose = closeAfterManualCapture;
                            closeAfterManualCapture = false;

                            finishFocusCycle();

                            if (shouldClose && cameraHandler != null) {
                                cameraHandler.postDelayed(
                                        () -> {
                                            if (!enabled) closeCamera();
                                        },
                                        150L
                                );
                            }
                        }

                        @Override
                        public void onCaptureFailed(
                                CameraCaptureSession s,
                                CaptureRequest request,
                                android.hardware.camera2.CaptureFailure failure
                        ) {
                            closeAfterManualCapture = false;
                            finishFocusCycle();
                        }
                    },
                    cameraHandler
            );
        } catch (CameraAccessException e) {
            closeAfterManualCapture = false;
            finishFocusCycle();
        }
    }

    private void finishFocusCycle() {
        captureInProgress = false;
        stillRequested = false;
        if (manualQueued) {
            manualQueued = false;
            if (cameraHandler != null) {
                cameraHandler.postDelayed(() -> capturePhoto(true), 80L);
            }
        }

        if (session == null || previewBuilder == null || cameraHandler == null) return;

        try {
            previewBuilder.set(
                    CaptureRequest.CONTROL_AF_TRIGGER,
                    CaptureRequest.CONTROL_AF_TRIGGER_CANCEL
            );
            session.capture(previewBuilder.build(), null, cameraHandler);

            previewBuilder.set(
                    CaptureRequest.CONTROL_AF_TRIGGER,
                    CaptureRequest.CONTROL_AF_TRIGGER_IDLE
            );
            session.setRepeatingRequest(
                    previewBuilder.build(),
                    null,
                    cameraHandler
            );
        } catch (CameraAccessException ignored) { }
    }

    private void saveImage(ImageReader reader) {
        CrashLogger.log(this, "IMAGE save BEGIN");
        Image image = reader.acquireNextImage();
        if (image == null) return;

        try {
            ByteBuffer buffer = image.getPlanes()[0].getBuffer();
            byte[] bytes = new byte[buffer.remaining()];
            buffer.get(bytes);

            String name = "IMG_"
                    + new SimpleDateFormat(
                            "yyyyMMdd_HHmmss_SSS",
                            Locale.US
                    ).format(new Date())
                    + ".jpg";

            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, name);
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");

            if (Build.VERSION.SDK_INT >= 29) {
                values.put(
                        MediaStore.Images.Media.RELATIVE_PATH,
                        "Pictures/FinderlessCamera"
                );
                values.put(MediaStore.Images.Media.IS_PENDING, 1);
            }

            Uri uri = getContentResolver().insert(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    values
            );

            if (uri != null) {
                try (OutputStream out =
                             getContentResolver().openOutputStream(uri)) {
                    if (out != null) out.write(bytes);
                }

                CrashLogger.log(this, "IMAGE save OK uri=" + uri);

                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues done = new ContentValues();
                    done.put(MediaStore.Images.Media.IS_PENDING, 0);
                    getContentResolver().update(uri, done, null, null);
                }
            }
        } catch (Exception error) {
            CrashLogger.logThrowable(this, "IMAGE save FAILED", error);
        } finally {
            image.close();
        }
    }

    private void vibrateOnce() {
        vibrate(90, 255);
    }

    private void vibrateLongPress() {
        vibrate(40, 200);
    }

    private void vibrate(long durationMs, int amplitude) {
        Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        if (vibrator == null || !vibrator.hasVibrator()) return;
        if (Build.VERSION.SDK_INT >= 26) {
            vibrator.vibrate(VibrationEffect.createOneShot(durationMs, amplitude));
        } else {
            vibrator.vibrate(durationMs);
        }
    }

    private void setFloatingEnabled(boolean value) {
        CrashLogger.log(this, "FLOAT setEnabled " + value);
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_FLOAT_ENABLED, value).apply();
        if (value) showFloatingShutterIfAllowed();
        else removeFloatingShutter();
    }

    private void showFloatingShutterIfAllowed() {
        CrashLogger.log(this, "FLOAT show requested overlayAllowed=" + Settings.canDrawOverlays(this));
        if (!Settings.canDrawOverlays(this) || floatingShutter != null) return;
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (windowManager == null) return;

        DisplayMetrics metrics = getDisplayMetrics();
        int maxX = Math.max(0, metrics.widthPixels - FLOAT_SIZE_PX);
        int maxY = Math.max(0, metrics.heightPixels - FLOAT_SIZE_PX);
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        int defaultX = Math.max(0, maxX - 24);
        int defaultY = Math.max(0, maxY - 180);
        int savedX = clamp(prefs.getInt(KEY_FLOAT_X, defaultX), 0, maxX);
        int savedY = clamp(prefs.getInt(KEY_FLOAT_Y, defaultY), 0, maxY);

        floatingShutter = new FloatingShutterView();
        int windowType = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        floatingParams = new WindowManager.LayoutParams(
                FLOAT_SIZE_PX, FLOAT_SIZE_PX, windowType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                android.graphics.PixelFormat.TRANSLUCENT);
        floatingParams.gravity = Gravity.TOP | Gravity.START;
        floatingParams.x = savedX;
        floatingParams.y = savedY;
        floatingShutter.setOnTouchListener(this::handleFloatingTouch);
        try {
            windowManager.addView(floatingShutter, floatingParams);
        } catch (Exception e) {
            floatingShutter = null;
            floatingParams = null;
        }
    }

    private boolean handleFloatingTouch(View view, MotionEvent event) {
        if (floatingParams == null || windowManager == null) return false;

        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                draggingFloat = false;
                snappedToDelete = false;
                setDeleteSnapVisual(false);
                downRawX = event.getRawX();
                downRawY = event.getRawY();
                downWindowX = floatingParams.x;
                downWindowY = floatingParams.y;
                downTimeMs = System.currentTimeMillis();
                longPressRunnable = () -> {
                    draggingFloat = true;
                    vibrateLongPress();
                    showDeleteTarget();
                };
                mainHandler.postDelayed(longPressRunnable, LONG_PRESS_MS);
                return true;

            case MotionEvent.ACTION_MOVE:
                float dx = event.getRawX() - downRawX;
                float dy = event.getRawY() - downRawY;
                if (!draggingFloat && (Math.abs(dx) > 24 || Math.abs(dy) > 24)) {
                    if (longPressRunnable != null) {
                        mainHandler.removeCallbacks(longPressRunnable);
                        longPressRunnable = null;
                    }
                }
                if (!draggingFloat) return true;

                DisplayMetrics metrics = getDisplayMetrics();
                int maxX = Math.max(0, metrics.widthPixels - FLOAT_SIZE_PX);
                int maxY = Math.max(0, metrics.heightPixels - FLOAT_SIZE_PX);
                float targetCenterX = metrics.widthPixels / 2f;
                float targetCenterY = metrics.heightPixels / 2f;
                float fingerDistance = distance(event.getRawX(), event.getRawY(), targetCenterX, targetCenterY);

                if (!snappedToDelete && fingerDistance <= SNAP_DISTANCE_PX) {
                    snappedToDelete = true;
                    setDeleteSnapVisual(true);
                    floatingParams.x = clamp(Math.round(targetCenterX - FLOAT_SIZE_PX / 2f), 0, maxX);
                    floatingParams.y = clamp(Math.round(targetCenterY - FLOAT_SIZE_PX / 2f), 0, maxY);
                    updateFloatingLayout();
                    return true;
                }

                if (snappedToDelete) {
                    if (fingerDistance >= RELEASE_DISTANCE_PX) {
                        snappedToDelete = false;
                        setDeleteSnapVisual(false);
                        downRawX = event.getRawX();
                        downRawY = event.getRawY();
                        downWindowX = floatingParams.x;
                        downWindowY = floatingParams.y;
                        return true;
                    } else {
                        return true;
                    }
                }

                floatingParams.x = clamp(downWindowX + Math.round(dx), 0, maxX);
                floatingParams.y = clamp(downWindowY + Math.round(dy), 0, maxY);
                updateFloatingLayout();
                return true;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (longPressRunnable != null) {
                    mainHandler.removeCallbacks(longPressRunnable);
                    longPressRunnable = null;
                }
                if (draggingFloat) {
                    draggingFloat = false;
                    setDeleteSnapVisual(false);
                    hideDeleteTarget();
                    if (snappedToDelete) {
                        snappedToDelete = false;
                        animateFloatingDelete();
                    } else {
                        saveFloatingPosition();
                    }
                    return true;
                }
                float upDx = Math.abs(event.getRawX() - downRawX);
                float upDy = Math.abs(event.getRawY() - downRawY);
                long heldMs = System.currentTimeMillis() - downTimeMs;
                if (heldMs < LONG_PRESS_MS && upDx < 24 && upDy < 24) handleManualCapture();
                return true;
            default:
                return false;
        }
    }

    private void setDeleteSnapVisual(boolean snapped) {
        int color = snapped ? Color.RED : Color.WHITE;
        if (floatingShutter != null) floatingShutter.setRingColor(color);
        if (deleteTarget != null) deleteTarget.setTextColor(color);
    }

    private void showDeleteTarget() {
        if (windowManager == null || deleteTarget != null) return;
        DisplayMetrics metrics = getDisplayMetrics();
        deleteTarget = new TextView(this);
        deleteTarget.setText("×");
        deleteTarget.setTextSize(54f);
        deleteTarget.setTextColor(Color.WHITE);
        deleteTarget.setGravity(Gravity.CENTER);
        deleteTarget.setAlpha(0f);
        int windowType = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        deleteTargetParams = new WindowManager.LayoutParams(
                DELETE_TARGET_SIZE_PX, DELETE_TARGET_SIZE_PX, windowType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                android.graphics.PixelFormat.TRANSLUCENT);
        deleteTargetParams.gravity = Gravity.TOP | Gravity.START;
        deleteTargetParams.x = Math.round(metrics.widthPixels / 2f - DELETE_TARGET_SIZE_PX / 2f);
        deleteTargetParams.y = Math.round(metrics.heightPixels / 2f - DELETE_TARGET_SIZE_PX / 2f);
        try {
            windowManager.addView(deleteTarget, deleteTargetParams);
            deleteTarget.animate().alpha(1f).setDuration(120L).start();
        } catch (Exception e) {
            deleteTarget = null;
            deleteTargetParams = null;
        }
    }

    private void hideDeleteTarget() {
        if (deleteTarget == null || windowManager == null) return;
        TextView target = deleteTarget;
        deleteTarget = null;
        deleteTargetParams = null;
        target.animate().alpha(0f).setDuration(100L).withEndAction(() -> {
            try { windowManager.removeView(target); } catch (Exception ignored) { }
        }).start();
    }

    private void animateFloatingDelete() {
        if (floatingShutter == null) {
            setFloatingEnabled(false);
            return;
        }
        FloatingShutterView shutter = floatingShutter;
        shutter.animate().scaleX(0f).scaleY(0f).alpha(0f).setDuration(180L)
                .withEndAction(() -> setFloatingEnabled(false)).start();
    }

    private void updateFloatingLayout() {
        if (floatingShutter == null || floatingParams == null || windowManager == null) return;
        clampFloatingParamsToScreen();
        try { windowManager.updateViewLayout(floatingShutter, floatingParams); } catch (Exception ignored) { }
    }

    private void clampFloatingParamsToScreen() {
        if (floatingParams == null || windowManager == null) return;
        DisplayMetrics metrics = getDisplayMetrics();
        int maxX = Math.max(0, metrics.widthPixels - FLOAT_SIZE_PX);
        int maxY = Math.max(0, metrics.heightPixels - FLOAT_SIZE_PX);
        floatingParams.x = clamp(floatingParams.x, 0, maxX);
        floatingParams.y = clamp(floatingParams.y, 0, maxY);
    }

    private DisplayMetrics getDisplayMetrics() {
        DisplayMetrics metrics = new DisplayMetrics();
        if (windowManager != null) windowManager.getDefaultDisplay().getRealMetrics(metrics);
        return metrics;
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(value, max));
    }

    private static float distance(float x1, float y1, float x2, float y2) {
        float dx = x1 - x2;
        float dy = y1 - y2;
        return (float) Math.sqrt(dx * dx + dy * dy);
    }

    private void saveFloatingPosition() {
        if (floatingParams == null) return;
        clampFloatingParamsToScreen();
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putInt(KEY_FLOAT_X, floatingParams.x)
                .putInt(KEY_FLOAT_Y, floatingParams.y)
                .apply();
    }

    private void removeFloatingShutter() {
        hideDeleteTarget();
        if (floatingShutter != null && windowManager != null) {
            try { windowManager.removeView(floatingShutter); } catch (Exception ignored) { }
        }
        floatingShutter = null;
        floatingParams = null;
        draggingFloat = false;
        snappedToDelete = false;
    }

    private void closeReadersOnly() {
        if (jpegReader != null) {
            jpegReader.close();
            jpegReader = null;
        }

        if (focusReader != null) {
            focusReader.close();
            focusReader = null;
        }
    }

    private void closeCamera() {
        stopAutoCapture();

        if (session != null) {
            session.close();
            session = null;
        }

        previewBuilder = null;

        if (cameraDevice != null) {
            cameraDevice.close();
            cameraDevice = null;
        }

        closeReadersOnly();
        captureInProgress = false;
        stillRequested = false;
        openingCamera = false;
        manualCapturePending = false;
    }

    @Override
    public void onDestroy() {
        CrashLogger.log(this, "SERVICE onDestroy");
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_FLOAT_ENABLED, false).apply();
        removeFloatingShutter();
        closeCamera();

        if (cameraThread != null) {
            cameraThread.quitSafely();
            cameraThread = null;
        }

        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private class FloatingShutterView extends View {
        private final Paint ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        FloatingShutterView() {
            super(CameraForegroundService.this);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);

            ringPaint.setStyle(Paint.Style.STROKE);
            ringPaint.setStrokeWidth(14f);
            ringPaint.setColor(Color.WHITE);
            ringPaint.setStrokeCap(Paint.Cap.ROUND);
        }

        void setRingColor(int color) {
            ringPaint.setColor(color);
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float radius = Math.min(getWidth(), getHeight()) / 2f - 16f;
            canvas.drawCircle(
                    getWidth() / 2f,
                    getHeight() / 2f,
                    radius,
                    ringPaint
            );
        }
    }
}
