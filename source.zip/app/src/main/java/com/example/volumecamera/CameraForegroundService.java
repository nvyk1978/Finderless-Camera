package com.example.volumecamera;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.ImageFormat;
import android.graphics.Paint;
import android.graphics.Canvas;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.CaptureResult;
import android.hardware.camera2.TotalCaptureResult;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.Image;
import android.media.ImageReader;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.Size;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.View;
import android.view.WindowManager;
import android.widget.RemoteViews;

import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class CameraForegroundService extends Service {
    public static final String ACTION_START = "com.example.volumecamera.START";
    public static final String ACTION_TOGGLE = "com.example.volumecamera.TOGGLE";
    public static final String ACTION_CAPTURE_ONCE = "com.example.volumecamera.CAPTURE_ONCE";
    public static final String ACTION_FLOAT_ON = "com.example.volumecamera.FLOAT_ON";
    public static final String ACTION_FLOAT_OFF = "com.example.volumecamera.FLOAT_OFF";

    public static final String PREFS = "finderless_camera_prefs";
    public static final String KEY_ENABLED = "enabled";
    public static final String KEY_SELECTED_CAMERA = "selected_camera";
    public static final String KEY_FLOAT_ENABLED = "float_enabled";
    private static final String KEY_FLOAT_X = "float_x";
    private static final String KEY_FLOAT_Y = "float_y";

    private static final String CHANNEL_ID = "finderless_camera_channel";
    private static final int NOTIFICATION_ID = 20;
    private static final long CAPTURE_INTERVAL_MS = 5000L;
    private static final long AF_FALLBACK_MS = 1800L;
    private static final int FLOAT_SIZE_PX = 200;
    private static final long LONG_PRESS_MS = 450L;

    private HandlerThread cameraThread;
    private Handler cameraHandler;
    private final Handler mainHandler = new Handler();

    private CameraDevice cameraDevice;
    private CameraCaptureSession session;
    private CaptureRequest.Builder previewBuilder;
    private ImageReader jpegReader;
    private ImageReader focusReader;
    private String cameraId;
    private int sensorOrientation = 90;
    private Size jpegSize;
    private Size focusSize;

    private boolean openingCamera = false;
    private boolean enabled = false;
    private boolean captureInProgress = false;
    private boolean stillRequested = false;
    private boolean manualCapturePending = false;
    private boolean closeAfterManualCapture = false;

    private WindowManager windowManager;
    private View floatingShutter;
    private WindowManager.LayoutParams floatingParams;
    private boolean draggingFloat = false;
    private float downRawX;
    private float downRawY;
    private int downWindowX;
    private int downWindowY;
    private long downTimeMs;
    private Runnable longPressRunnable;

    private final Runnable autoCaptureRunnable = new Runnable() {
        @Override
        public void run() {
            if (!enabled) return;
            capturePhoto(false);
            if (cameraHandler != null) {
                cameraHandler.postDelayed(this, CAPTURE_INTERVAL_MS);
            }
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();

        cameraThread = new HandlerThread("FinderlessCameraThread");
        cameraThread.start();
        cameraHandler = new Handler(cameraThread.getLooper());

        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        enabled = prefs.getBoolean(KEY_ENABLED, false);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : ACTION_START;
        startForeground(NOTIFICATION_ID, buildNotification());

        if (ACTION_TOGGLE.equals(action)) {
            setEnabled(!enabled);
        } else if (ACTION_CAPTURE_ONCE.equals(action)) {
            handleManualCapture();
        } else if (ACTION_FLOAT_ON.equals(action)) {
            setFloatingEnabled(true);
        } else if (ACTION_FLOAT_OFF.equals(action)) {
            setFloatingEnabled(false);
        } else {
            if (enabled) ensureCameraOpen(true);
            if (getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(KEY_FLOAT_ENABLED, false)) {
                showFloatingShutterIfAllowed();
            }
        }

        return START_STICKY;
    }

    private void setEnabled(boolean newValue) {
        enabled = newValue;
        getSharedPreferences(PREFS, MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_ENABLED, enabled)
                .apply();

        if (enabled) {
            ensureCameraOpen(true);
        } else {
            stopAutoCapture();
            if (!manualCapturePending && !captureInProgress) {
                closeCamera();
            }
        }
        updateNotification();
    }

    private void handleManualCapture() {
        manualCapturePending = true;
        closeAfterManualCapture = !enabled;

        if (cameraHandler == null) return;
        cameraHandler.post(() -> {
            if (cameraDevice != null && session != null && previewBuilder != null) {
                manualCapturePending = false;
                capturePhoto(true);
            } else {
                ensureCameraOpen(true);
            }
        });
    }

    private Notification buildNotification() {
        Intent toggleIntent = new Intent(this, CameraForegroundService.class);
        toggleIntent.setAction(ACTION_TOGGLE);
        PendingIntent togglePending = PendingIntent.getService(
                this,
                1,
                toggleIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Intent captureIntent = new Intent(this, CameraForegroundService.class);
        captureIntent.setAction(ACTION_CAPTURE_ONCE);
        PendingIntent capturePending = PendingIntent.getService(
                this,
                3,
                captureIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent openPending = PendingIntent.getActivity(
                this,
                2,
                openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        RemoteViews view = new RemoteViews(getPackageName(), R.layout.notification_camera);
        view.setTextViewText(R.id.notification_toggle, enabled ? "ON" : "OFF");
        view.setInt(
                R.id.notification_toggle,
                "setBackgroundResource",
                enabled ? R.drawable.toggle_on : R.drawable.toggle_off
        );
        view.setOnClickPendingIntent(R.id.notification_capture, capturePending);
        view.setOnClickPendingIntent(R.id.notification_toggle, togglePending);

        return new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .setOngoing(true)
                .setContentIntent(openPending)
                .setCustomContentView(view)
                .setStyle(new Notification.DecoratedCustomViewStyle())
                .build();
    }

    private void updateNotification() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) nm.notify(NOTIFICATION_ID, buildNotification());
    }

    private void createChannel() {
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "FinderlessCamera",
                NotificationManager.IMPORTANCE_LOW
        );
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) nm.createNotificationChannel(channel);
    }

    private void ensureCameraOpen(boolean allowWhenAutoOff) {
        if ((!enabled && !allowWhenAutoOff) || cameraDevice != null || openingCamera) return;
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return;

        openingCamera = true;
        CameraManager manager = getSystemService(CameraManager.class);
        if (manager == null) {
            openingCamera = false;
            return;
        }

        try {
            chooseSelectedBackCamera(manager);
            if (cameraId == null) {
                openingCamera = false;
                return;
            }

            manager.openCamera(cameraId, new CameraDevice.StateCallback() {
                @Override
                public void onOpened(CameraDevice camera) {
                    openingCamera = false;
                    cameraDevice = camera;
                    createSession();
                }

                @Override
                public void onDisconnected(CameraDevice camera) {
                    openingCamera = false;
                    camera.close();
                    cameraDevice = null;
                    session = null;
                }

                @Override
                public void onError(CameraDevice camera, int error) {
                    openingCamera = false;
                    camera.close();
                    cameraDevice = null;
                    session = null;
                }
            }, cameraHandler);
        } catch (Exception e) {
            openingCamera = false;
        }
    }

    private void chooseSelectedBackCamera(CameraManager manager) throws CameraAccessException {
        cameraId = null;
        jpegSize = null;
        focusSize = null;

        String preferred = getSharedPreferences(PREFS, MODE_PRIVATE)
                .getString(KEY_SELECTED_CAMERA, null);

        List<String> ids = new ArrayList<>(Arrays.asList(manager.getCameraIdList()));
        if (preferred != null && ids.remove(preferred)) {
            ids.add(0, preferred);
        }

        for (String id : ids) {
            try {
                CameraCharacteristics c = manager.getCameraCharacteristics(id);
                Integer facing = c.get(CameraCharacteristics.LENS_FACING);
                if (facing == null || facing != CameraCharacteristics.LENS_FACING_BACK) continue;

                StreamConfigurationMap map =
                        c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
                if (map == null) continue;

                Size[] jpegSizes = map.getOutputSizes(ImageFormat.JPEG);
                Size[] yuvSizes = map.getOutputSizes(ImageFormat.YUV_420_888);
                if (jpegSizes == null || jpegSizes.length == 0
                        || yuvSizes == null || yuvSizes.length == 0) {
                    continue;
                }

                cameraId = id;
                jpegSize = chooseJpegSize(map);
                focusSize = Arrays.stream(yuvSizes)
                        .filter(s -> s.getWidth() >= 640 && s.getHeight() >= 480)
                        .min(Comparator.comparingLong(
                                s -> (long) s.getWidth() * s.getHeight()
                        ))
                        .orElse(yuvSizes[0]);

                Integer so = c.get(CameraCharacteristics.SENSOR_ORIENTATION);
                if (so != null) sensorOrientation = so;
                return;
            } catch (Exception ignored) {
                // Broken/vendor-specific camera IDs are skipped instead of crashing the app.
            }
        }
    }

    private Size chooseJpegSize(StreamConfigurationMap map) {
        Size[] sizes = map.getOutputSizes(ImageFormat.JPEG);
        if (sizes == null || sizes.length == 0) return new Size(1920, 1080);

        double targetRatio = 16.0 / 9.0;
        try {
            WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
            if (wm != null) {
                DisplayMetrics metrics = new DisplayMetrics();
                wm.getDefaultDisplay().getRealMetrics(metrics);
                int longSide = Math.max(metrics.widthPixels, metrics.heightPixels);
                int shortSide = Math.min(metrics.widthPixels, metrics.heightPixels);
                if (shortSide > 0) {
                    targetRatio = (double) longSide / (double) shortSide;
                }
            }
        } catch (Exception ignored) { }

        double closestError = Double.MAX_VALUE;
        for (Size s : sizes) {
            int longSide = Math.max(s.getWidth(), s.getHeight());
            int shortSide = Math.min(s.getWidth(), s.getHeight());
            if (shortSide == 0) continue;
            double ratio = (double) longSide / (double) shortSide;
            closestError = Math.min(closestError, Math.abs(ratio - targetRatio));
        }

        double allowedError = closestError + 0.015;
        Size best = sizes[0];
        long bestPixels = 0;

        for (Size s : sizes) {
            int longSide = Math.max(s.getWidth(), s.getHeight());
            int shortSide = Math.min(s.getWidth(), s.getHeight());
            if (shortSide == 0) continue;

            double ratio = (double) longSide / (double) shortSide;
            double error = Math.abs(ratio - targetRatio);
            long pixels = (long) s.getWidth() * s.getHeight();

            if (error <= allowedError && pixels > bestPixels) {
                best = s;
                bestPixels = pixels;
            }
        }
        return best;
    }

    private void createSession() {
        if (cameraDevice == null || jpegSize == null || focusSize == null) return;
        closeReadersOnly();

        jpegReader = ImageReader.newInstance(
                jpegSize.getWidth(),
                jpegSize.getHeight(),
                ImageFormat.JPEG,
                2
        );
        focusReader = ImageReader.newInstance(
                focusSize.getWidth(),
                focusSize.getHeight(),
                ImageFormat.YUV_420_888,
                2
        );

        focusReader.setOnImageAvailableListener(reader -> {
            Image image = reader.acquireLatestImage();
            if (image != null) image.close();
        }, cameraHandler);

        jpegReader.setOnImageAvailableListener(this::saveImage, cameraHandler);

        List<Surface> surfaces = new ArrayList<>();
        surfaces.add(focusReader.getSurface());
        surfaces.add(jpegReader.getSurface());

        try {
            cameraDevice.createCaptureSession(
                    surfaces,
                    new CameraCaptureSession.StateCallback() {
                        @Override
                        public void onConfigured(CameraCaptureSession configuredSession) {
                            if (cameraDevice == null) return;
                            session = configuredSession;

                            try {
                                previewBuilder = cameraDevice.createCaptureRequest(
                                        CameraDevice.TEMPLATE_PREVIEW
                                );
                                previewBuilder.addTarget(focusReader.getSurface());
                                previewBuilder.set(
                                        CaptureRequest.CONTROL_AF_MODE,
                                        CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE
                                );
                                previewBuilder.set(
                                        CaptureRequest.CONTROL_AE_MODE,
                                        CaptureRequest.CONTROL_AE_MODE_ON
                                );
                                previewBuilder.set(
                                        CaptureRequest.FLASH_MODE,
                                        CaptureRequest.FLASH_MODE_OFF
                                );

                                session.setRepeatingRequest(
                                        previewBuilder.build(),
                                        null,
                                        cameraHandler
                                );

                                if (enabled) startAutoCapture();

                                if (manualCapturePending) {
                                    manualCapturePending = false;
                                    cameraHandler.postDelayed(
                                            () -> capturePhoto(true),
                                            250L
                                    );
                                }
                            } catch (CameraAccessException ignored) { }
                        }

                        @Override
                        public void onConfigureFailed(CameraCaptureSession failedSession) {
                            session = null;
                        }
                    },
                    cameraHandler
            );
        } catch (CameraAccessException ignored) { }
    }

    private void startAutoCapture() {
        if (cameraHandler == null || !enabled) return;
        cameraHandler.removeCallbacks(autoCaptureRunnable);
        cameraHandler.postDelayed(autoCaptureRunnable, CAPTURE_INTERVAL_MS);
    }

    private void stopAutoCapture() {
        if (cameraHandler != null) {
            cameraHandler.removeCallbacks(autoCaptureRunnable);
        }
    }

    private void capturePhoto(boolean manual) {
        if (!manual && !enabled) return;

        if (cameraDevice == null || session == null
                || jpegReader == null || previewBuilder == null) {
            if (manual) manualCapturePending = true;
            ensureCameraOpen(true);
            return;
        }

        if (captureInProgress) return;

        captureInProgress = true;
        stillRequested = false;

        try {
            previewBuilder.set(
                    CaptureRequest.CONTROL_AF_TRIGGER,
                    CaptureRequest.CONTROL_AF_TRIGGER_START
            );

            session.capture(
                    previewBuilder.build(),
                    new CameraCaptureSession.CaptureCallback() {
                        @Override
                        public void onCaptureCompleted(
                                CameraCaptureSession s,
                                CaptureRequest request,
                                TotalCaptureResult result
                        ) {
                            Integer afState = result.get(
                                    CaptureResult.CONTROL_AF_STATE
                            );

                            if (afState == null
                                    || afState == CaptureResult.CONTROL_AF_STATE_FOCUSED_LOCKED
                                    || afState == CaptureResult.CONTROL_AF_STATE_NOT_FOCUSED_LOCKED
                                    || afState == CaptureResult.CONTROL_AF_STATE_PASSIVE_FOCUSED
                                    || afState == CaptureResult.CONTROL_AF_STATE_PASSIVE_UNFOCUSED) {
                                requestStill();
                            }
                        }
                    },
                    cameraHandler
            );

            cameraHandler.postDelayed(() -> {
                if (captureInProgress) requestStill();
            }, AF_FALLBACK_MS);

        } catch (CameraAccessException e) {
            captureInProgress = false;
            stillRequested = false;
        }
    }

    private void requestStill() {
        if (!captureInProgress || stillRequested) return;
        stillRequested = true;
        takeStillPhoto();
    }

    private int getJpegOrientation() {
        int deviceDegrees = 0;
        try {
            WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
            if (wm != null) {
                int rotation = wm.getDefaultDisplay().getRotation();
                if (rotation == Surface.ROTATION_90) deviceDegrees = 90;
                else if (rotation == Surface.ROTATION_180) deviceDegrees = 180;
                else if (rotation == Surface.ROTATION_270) deviceDegrees = 270;
            }
        } catch (Exception ignored) { }

        return (sensorOrientation - deviceDegrees + 360) % 360;
    }

    private void takeStillPhoto() {
        if (!captureInProgress || cameraDevice == null
                || session == null || jpegReader == null) {
            finishFocusCycle();
            return;
        }

        try {
            CaptureRequest.Builder still = cameraDevice.createCaptureRequest(
                    CameraDevice.TEMPLATE_STILL_CAPTURE
            );
            still.addTarget(jpegReader.getSurface());
            still.set(
                    CaptureRequest.CONTROL_AF_MODE,
                    CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE
            );
            still.set(
                    CaptureRequest.CONTROL_AE_MODE,
                    CaptureRequest.CONTROL_AE_MODE_ON
            );
            still.set(CaptureRequest.FLASH_MODE, CaptureRequest.FLASH_MODE_OFF);
            still.set(CaptureRequest.JPEG_ORIENTATION, getJpegOrientation());
            still.set(CaptureRequest.JPEG_QUALITY, (byte) 100);

            session.capture(
                    still.build(),
                    new CameraCaptureSession.CaptureCallback() {
                        @Override
                        public void onCaptureCompleted(
                                CameraCaptureSession s,
                                CaptureRequest request,
                                TotalCaptureResult result
                        ) {
                            vibrateOnce();

                            boolean shouldClose = closeAfterManualCapture;
                            closeAfterManualCapture = false;

                            finishFocusCycle();

                            if (shouldClose && cameraHandler != null) {
                                cameraHandler.postDelayed(
                                        () -> {
                                            if (!enabled) closeCamera();
                                        },
                                        150L
                                );
                            }
                        }

                        @Override
                        public void onCaptureFailed(
                                CameraCaptureSession s,
                                CaptureRequest request,
                                android.hardware.camera2.CaptureFailure failure
                        ) {
                            closeAfterManualCapture = false;
                            finishFocusCycle();
                        }
                    },
                    cameraHandler
            );
        } catch (CameraAccessException e) {
            closeAfterManualCapture = false;
            finishFocusCycle();
        }
    }

    private void finishFocusCycle() {
        captureInProgress = false;
        stillRequested = false;

        if (session == null || previewBuilder == null || cameraHandler == null) return;

        try {
            previewBuilder.set(
                    CaptureRequest.CONTROL_AF_TRIGGER,
                    CaptureRequest.CONTROL_AF_TRIGGER_CANCEL
            );
            session.capture(previewBuilder.build(), null, cameraHandler);

            previewBuilder.set(
                    CaptureRequest.CONTROL_AF_TRIGGER,
                    CaptureRequest.CONTROL_AF_TRIGGER_IDLE
            );
            session.setRepeatingRequest(
                    previewBuilder.build(),
                    null,
                    cameraHandler
            );
        } catch (CameraAccessException ignored) { }
    }

    private void saveImage(ImageReader reader) {
        Image image = reader.acquireNextImage();
        if (image == null) return;

        try {
            ByteBuffer buffer = image.getPlanes()[0].getBuffer();
            byte[] bytes = new byte[buffer.remaining()];
            buffer.get(bytes);

            String name = "IMG_"
                    + new SimpleDateFormat(
                            "yyyyMMdd_HHmmss_SSS",
                            Locale.US
                    ).format(new Date())
                    + ".jpg";

            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, name);
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");

            if (Build.VERSION.SDK_INT >= 29) {
                values.put(
                        MediaStore.Images.Media.RELATIVE_PATH,
                        "Pictures/FinderlessCamera"
                );
                values.put(MediaStore.Images.Media.IS_PENDING, 1);
            }

            Uri uri = getContentResolver().insert(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    values
            );

            if (uri != null) {
                try (OutputStream out =
                             getContentResolver().openOutputStream(uri)) {
                    if (out != null) out.write(bytes);
                }

                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues done = new ContentValues();
                    done.put(MediaStore.Images.Media.IS_PENDING, 0);
                    getContentResolver().update(uri, done, null, null);
                }
            }
        } catch (Exception ignored) {
        } finally {
            image.close();
        }
    }

    private void vibrateOnce() {
        Vibrator vibrator =
                (Vibrator) getSystemService(VIBRATOR_SERVICE);

        if (vibrator == null || !vibrator.hasVibrator()) return;

        if (Build.VERSION.SDK_INT >= 26) {
            vibrator.vibrate(
                    VibrationEffect.createOneShot(55, 220)
            );
        } else {
            vibrator.vibrate(55);
        }
    }

    private void setFloatingEnabled(boolean value) {
        getSharedPreferences(PREFS, MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_FLOAT_ENABLED, value)
                .apply();

        if (value) {
            showFloatingShutterIfAllowed();
        } else {
            removeFloatingShutter();
        }
    }

    private void showFloatingShutterIfAllowed() {
        if (!Settings.canDrawOverlays(this)) return;
        if (floatingShutter != null) return;

        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (windowManager == null) return;

        DisplayMetrics metrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getRealMetrics(metrics);

        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        int defaultX = Math.max(0, metrics.widthPixels - FLOAT_SIZE_PX - 24);
        int defaultY = Math.max(0, metrics.heightPixels - FLOAT_SIZE_PX - 180);

        int savedX = prefs.getInt(KEY_FLOAT_X, defaultX);
        int savedY = prefs.getInt(KEY_FLOAT_Y, defaultY);

        savedX = Math.max(-FLOAT_SIZE_PX / 2,
                Math.min(savedX, metrics.widthPixels - FLOAT_SIZE_PX / 2));
        savedY = Math.max(-FLOAT_SIZE_PX / 2,
                Math.min(savedY, metrics.heightPixels - FLOAT_SIZE_PX / 2));

        floatingShutter = new FloatingShutterView();

        int windowType = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        floatingParams = new WindowManager.LayoutParams(
                FLOAT_SIZE_PX,
                FLOAT_SIZE_PX,
                windowType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                android.graphics.PixelFormat.TRANSLUCENT
        );
        floatingParams.gravity = Gravity.TOP | Gravity.START;
        floatingParams.x = savedX;
        floatingParams.y = savedY;

        floatingShutter.setOnTouchListener(this::handleFloatingTouch);

        try {
            windowManager.addView(floatingShutter, floatingParams);
        } catch (Exception e) {
            floatingShutter = null;
            floatingParams = null;
        }
    }

    private boolean handleFloatingTouch(View view, MotionEvent event) {
        if (floatingParams == null || windowManager == null) return false;

        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                draggingFloat = false;
                downRawX = event.getRawX();
                downRawY = event.getRawY();
                downWindowX = floatingParams.x;
                downWindowY = floatingParams.y;
                downTimeMs = System.currentTimeMillis();

                longPressRunnable = () -> draggingFloat = true;
                mainHandler.postDelayed(longPressRunnable, LONG_PRESS_MS);
                return true;

            case MotionEvent.ACTION_MOVE:
                float dx = event.getRawX() - downRawX;
                float dy = event.getRawY() - downRawY;

                if (!draggingFloat && (Math.abs(dx) > 24 || Math.abs(dy) > 24)) {
                    if (longPressRunnable != null) {
                        mainHandler.removeCallbacks(longPressRunnable);
                    }
                }

                if (draggingFloat) {
                    floatingParams.x = downWindowX + Math.round(dx);
                    floatingParams.y = downWindowY + Math.round(dy);

                    try {
                        windowManager.updateViewLayout(
                                floatingShutter,
                                floatingParams
                        );
                    } catch (Exception ignored) { }
                }
                return true;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (longPressRunnable != null) {
                    mainHandler.removeCallbacks(longPressRunnable);
                    longPressRunnable = null;
                }

                if (draggingFloat) {
                    draggingFloat = false;

                    if (isFloatingShutterOutsideEnough()) {
                        setFloatingEnabled(false);
                    } else {
                        saveFloatingPosition();
                    }
                    return true;
                }

                float upDx = Math.abs(event.getRawX() - downRawX);
                float upDy = Math.abs(event.getRawY() - downRawY);
                long heldMs = System.currentTimeMillis() - downTimeMs;

                if (heldMs < LONG_PRESS_MS && upDx < 24 && upDy < 24) {
                    handleManualCapture();
                }
                return true;

            default:
                return false;
        }
    }

    private boolean isFloatingShutterOutsideEnough() {
        if (floatingParams == null || windowManager == null) return false;

        DisplayMetrics metrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getRealMetrics(metrics);
        int half = FLOAT_SIZE_PX / 2;

        return floatingParams.x <= -half
                || floatingParams.x >= metrics.widthPixels - half
                || floatingParams.y <= -half
                || floatingParams.y >= metrics.heightPixels - half;
    }

    private void saveFloatingPosition() {
        if (floatingParams == null) return;

        getSharedPreferences(PREFS, MODE_PRIVATE)
                .edit()
                .putInt(KEY_FLOAT_X, floatingParams.x)
                .putInt(KEY_FLOAT_Y, floatingParams.y)
                .apply();
    }

    private void removeFloatingShutter() {
        if (floatingShutter != null && windowManager != null) {
            try {
                windowManager.removeView(floatingShutter);
            } catch (Exception ignored) { }
        }

        floatingShutter = null;
        floatingParams = null;
        draggingFloat = false;
    }

    private void closeReadersOnly() {
        if (jpegReader != null) {
            jpegReader.close();
            jpegReader = null;
        }

        if (focusReader != null) {
            focusReader.close();
            focusReader = null;
        }
    }

    private void closeCamera() {
        stopAutoCapture();

        if (session != null) {
            session.close();
            session = null;
        }

        previewBuilder = null;

        if (cameraDevice != null) {
            cameraDevice.close();
            cameraDevice = null;
        }

        closeReadersOnly();
        captureInProgress = false;
        stillRequested = false;
        openingCamera = false;
        manualCapturePending = false;
    }

    @Override
    public void onDestroy() {
        removeFloatingShutter();
        closeCamera();

        if (cameraThread != null) {
            cameraThread.quitSafely();
            cameraThread = null;
        }

        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private class FloatingShutterView extends View {
        private final Paint ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        FloatingShutterView() {
            super(CameraForegroundService.this);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);

            ringPaint.setStyle(Paint.Style.STROKE);
            ringPaint.setStrokeWidth(14f);
            ringPaint.setColor(Color.WHITE);
            ringPaint.setStrokeCap(Paint.Cap.ROUND);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float radius = Math.min(getWidth(), getHeight()) / 2f - 16f;
            canvas.drawCircle(
                    getWidth() / 2f,
                    getHeight() / 2f,
                    radius,
                    ringPaint
            );
        }
    }
}
