package com.example.volumecamera;

import android.Manifest;
import android.animation.ValueAnimator;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.ImageFormat;
import android.graphics.Paint;
import android.graphics.Canvas;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.CaptureResult;
import android.hardware.camera2.TotalCaptureResult;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.Image;
import android.media.ImageReader;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.MediaStore;
import android.provider.DocumentsContract;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.Size;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.PathInterpolator;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.View;
import android.view.WindowManager;
import android.widget.RemoteViews;
import android.widget.TextView;

import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class CameraForegroundService extends Service {
    public static final String ACTION_START = "com.example.volumecamera.START";
    public static final String ACTION_TOGGLE = "com.example.volumecamera.TOGGLE";
    public static final String ACTION_CAPTURE_ONCE = "com.example.volumecamera.CAPTURE_ONCE";
    public static final String ACTION_FLOAT_ON = "com.example.volumecamera.FLOAT_ON";
    public static final String ACTION_FLOAT_OFF = "com.example.volumecamera.FLOAT_OFF";
    public static final String ACTION_STOP_SERVICE = "com.example.volumecamera.STOP_SERVICE";
    public static final String ACTION_FLOAT_STATE_CHANGED = "com.example.volumecamera.FLOAT_STATE_CHANGED";
    public static final String ACTION_SERVICE_STATE_CHANGED = "com.example.volumecamera.SERVICE_STATE_CHANGED";
    public static final String ACTION_AUTO_STATE_CHANGED = "com.example.volumecamera.AUTO_STATE_CHANGED";
    public static final String ACTION_CAMERA_STATE_CHANGED = "com.example.volumecamera.CAMERA_STATE_CHANGED";
    public static final String ACTION_REFRESH_NOTIFICATION = "com.example.volumecamera.REFRESH_NOTIFICATION";
    public static final String ACTION_SWITCH_CAMERA = "com.example.volumecamera.SWITCH_CAMERA";
    public static final String ACTION_NOTIFICATION_DISMISSED = "com.example.volumecamera.NOTIFICATION_DISMISSED";

    public static final String PREFS = "finderless_camera_prefs";
    public static final String KEY_ENABLED = "enabled";
    public static final String KEY_FLOAT_ENABLED = "float_enabled";
    public static final String KEY_SHUTTER_VIBRATION = "shutter_vibration";
    public static final String KEY_BURST_ENABLED = "burst_enabled";
    public static final String KEY_SAVE_FOLDER_URI = "save_folder_uri";
    public static final String KEY_SAVE_FOLDER_NAME = "save_folder_name";
    private static final String KEY_NOTIFICATION_SWIPE_END = "notification_swipe_end";
    private static final String KEY_USE_FRONT_CAMERA = "use_front_camera";
    private static final String KEY_FLOAT_X = "float_x";
    private static final String KEY_FLOAT_Y = "float_y";

    private static final String CHANNEL_ID = "finderless_camera_channel";
    private static final int NOTIFICATION_ID = 20;
    public static final int NOTIFICATION_ID_PUBLIC = NOTIFICATION_ID;
    private static final long CAPTURE_INTERVAL_MS = 5000L;
    private static final long AF_FALLBACK_MS = 1800L;
    private static final int FLOAT_SIZE_PX = 200;
    private static final int DELETE_TARGET_SIZE_PX = 200;
    private static final long LONG_PRESS_MS = 450L;
    private static final float SNAP_DISTANCE_PX = 300f;
    private static final float RELEASE_DISTANCE_PX = 420f;

    private HandlerThread cameraThread;
    private Handler cameraHandler;
    private final Handler mainHandler = new Handler();

    private CameraDevice cameraDevice;
    private CameraCaptureSession session;
    private CaptureRequest.Builder previewBuilder;
    private ImageReader jpegReader;
    private ImageReader focusReader;
    private int sensorOrientation = 90;
    private int selectedAfMode = CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE;
    private Size jpegSize;
    private Size focusSize;

    private boolean openingCamera = false;
    private boolean enabled = false;
    private boolean captureInProgress = false;
    private boolean stillRequested = false;
    private boolean manualCapturePending = false;
    private boolean closeAfterManualCapture = false; // resident mode keeps camera session warm
    private boolean manualQueued = false;
    private boolean residentRunning = false;
    private int pendingManualShots = 0;
    private boolean notificationFlash = false;

    private WindowManager windowManager;
    private FloatingShutterView floatingShutter;
    private WindowManager.LayoutParams floatingParams;
    private TextView deleteTarget;
    private WindowManager.LayoutParams deleteTargetParams;
    private boolean draggingFloat = false;
    private boolean snappedToDelete = false;
    private float downRawX;
    private float downRawY;
    private int downWindowX;
    private int downWindowY;
    private float grabOffsetX;
    private float grabOffsetY;
    private long downTimeMs;
    private Runnable longPressRunnable;

    private final Runnable autoCaptureRunnable = new Runnable() {
        @Override
        public void run() {
            if (!enabled) return;
            CrashLogger.log(CameraForegroundService.this, "AUTO tick");
            capturePhoto(false);
            if (cameraHandler != null) {
                cameraHandler.postDelayed(this, CAPTURE_INTERVAL_MS);
            }
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        CrashLogger.log(this, "SERVICE onCreate");
        createChannel();

        cameraThread = new HandlerThread("FinderlessCameraThread");
        cameraThread.start();
        cameraHandler = new Handler(cameraThread.getLooper());

        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        enabled = prefs.getBoolean(KEY_ENABLED, false);
        residentRunning = prefs.getBoolean("service_running", false);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : ACTION_START;
        boolean floatEnabled = getSharedPreferences(PREFS, MODE_PRIVATE)
                .getBoolean(KEY_FLOAT_ENABLED, false);
        CrashLogger.log(this, "SERVICE onStartCommand action=" + action + " flags=" + flags + " startId=" + startId + " enabled=" + enabled);
        CrashLogger.log(this, "SERVICE startForeground BEGIN");
        startForeground(NOTIFICATION_ID, buildNotification());
        CrashLogger.log(this, "SERVICE startForeground OK");

        if (ACTION_NOTIFICATION_DISMISSED.equals(action)) {
            boolean swipeEnd = getSharedPreferences(PREFS, MODE_PRIVATE)
                    .getBoolean(KEY_NOTIFICATION_SWIPE_END, true);
            if (!swipeEnd) {
                updateNotification();
                return START_NOT_STICKY;
            }
            CrashLogger.log(this, "SERVICE notification dismissed");
            residentRunning = false;
            enabled = false;
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putBoolean("service_running", false)
                    .putBoolean(KEY_ENABLED, false)
                    .putBoolean(KEY_FLOAT_ENABLED, false)
                    .apply();
            removeFloatingShutter();
            closeCamera();
            sendBroadcast(new Intent(ACTION_SERVICE_STATE_CHANGED).setPackage(getPackageName()));
            sendBroadcast(new Intent(ACTION_FLOAT_STATE_CHANGED).setPackage(getPackageName()));
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
            return START_NOT_STICKY;
        } else if (ACTION_STOP_SERVICE.equals(action)) {
            if (floatEnabled) {
                CrashLogger.log(this, "SERVICE stop ignored while floating shutter active");
                return START_NOT_STICKY;
            }

            CrashLogger.log(this, "SERVICE stop requested");
            residentRunning = false;
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putBoolean("service_running", false)
                    .putBoolean(KEY_ENABLED, false)
                    .apply();
            enabled = false;
            stopAutoCapture();
            if (!floatEnabled) {
                closeCamera();
                stopForeground(STOP_FOREGROUND_REMOVE);
                stopSelf();
            }
            sendBroadcast(new Intent(ACTION_SERVICE_STATE_CHANGED).setPackage(getPackageName()));
            return START_NOT_STICKY;
        } else if (ACTION_START.equals(action)) {
            residentRunning = true;
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putBoolean("service_running", true)
                    .apply();
            ensureCameraOpen(true);
            sendBroadcast(new Intent(ACTION_SERVICE_STATE_CHANGED).setPackage(getPackageName()));
        } else if (ACTION_REFRESH_NOTIFICATION.equals(action)) {
            updateNotification();
        } else if (ACTION_SWITCH_CAMERA.equals(action)) {
            restartCameraForSelection();
        } else if (ACTION_TOGGLE.equals(action)) {
            setEnabled(!enabled);
        } else if (ACTION_CAPTURE_ONCE.equals(action)) {
            handleManualCapture();
        } else if (ACTION_FLOAT_ON.equals(action)) {
            setFloatingEnabled(true);
        } else if (ACTION_FLOAT_OFF.equals(action)) {
            setFloatingEnabled(false);
        } else if (enabled) {
            ensureCameraOpen(true);
        }

        return START_NOT_STICKY;
    }

    private void setEnabled(boolean newValue) {
        CrashLogger.log(this, "SERVICE setEnabled " + newValue);
        enabled = newValue;
        getSharedPreferences(PREFS, MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_ENABLED, enabled)
                .apply();

        if (enabled) {
            if (!residentRunning) {
                residentRunning = true;
                getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                        .putBoolean("service_running", true)
                        .apply();
                sendBroadcast(new Intent(ACTION_SERVICE_STATE_CHANGED).setPackage(getPackageName()));
            }
            ensureCameraOpen(true);
        } else {
            stopAutoCapture();
            boolean floatEnabled = getSharedPreferences(PREFS, MODE_PRIVATE)
                    .getBoolean(KEY_FLOAT_ENABLED, false);
            if (!residentRunning && !floatEnabled
                    && !manualCapturePending && !captureInProgress) {
                closeCamera();
            }
        }
        updateNotification();
        sendBroadcast(new Intent(ACTION_AUTO_STATE_CHANGED).setPackage(getPackageName()));
    }

    private void handleManualCapture() {
        boolean burst = getSharedPreferences(PREFS, MODE_PRIVATE)
                .getBoolean(KEY_BURST_ENABLED, false);
        int shots = burst ? 3 : 1;

        CrashLogger.log(this, "CAPTURE manual requested shots=" + shots);
        enqueueManualShots(shots);
    }

    private void enqueueManualShots(int shots) {
        if (shots <= 0) return;
        pendingManualShots += shots;
        manualCapturePending = true;
        closeAfterManualCapture = false;

        if (cameraHandler == null) return;
        cameraHandler.post(() -> {
            if (cameraDevice != null && session != null && previewBuilder != null) {
                runNextManualShot();
            } else {
                ensureCameraOpen(true);
            }
        });
    }

    private void runNextManualShot() {
        if (pendingManualShots <= 0 || captureInProgress) return;
        pendingManualShots--;
        manualCapturePending = pendingManualShots > 0;

        vibrateShutterNow();
        flashShutters(false);
        capturePhoto(true);
    }

    private void playShutterFeedback(boolean burst) {
        if (burst) {
            vibrateBurstNow();
            flashShutters(true);
        } else {
            vibrateShutterNow();
            flashShutters(false);
        }
    }

    private Notification buildNotification() {
        Intent toggleIntent = new Intent(this, CameraForegroundService.class);
        toggleIntent.setAction(ACTION_TOGGLE);
        PendingIntent togglePending = PendingIntent.getService(
                this,
                1,
                toggleIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Intent captureIntent = new Intent(this, CameraForegroundService.class);
        captureIntent.setAction(ACTION_CAPTURE_ONCE);
        PendingIntent capturePending = PendingIntent.getService(
                this,
                3,
                captureIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Intent dismissedIntent = new Intent(this, CameraForegroundService.class);
        dismissedIntent.setAction(ACTION_NOTIFICATION_DISMISSED);
        PendingIntent dismissedPending = PendingIntent.getService(
                this,
                4,
                dismissedIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent openPending = PendingIntent.getActivity(
                this,
                2,
                openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        RemoteViews view = new RemoteViews(getPackageName(), R.layout.notification_camera);
        view.setTextViewText(R.id.notification_toggle, enabled ? "STOP" : "AUTO");
        view.setInt(
                R.id.notification_toggle,
                "setBackgroundResource",
                enabled ? R.drawable.button_dark_gray : R.drawable.button_blue
        );
        view.setTextColor(
                R.id.notification_toggle,
                enabled ? Color.RED : Color.WHITE
        );
        view.setInt(R.id.notification_capture, "setBackgroundResource",
                notificationFlash ? R.drawable.button_shutter_flash : R.drawable.button_shutter);
        view.setTextColor(R.id.notification_capture,
                notificationFlash ? Color.BLACK : Color.WHITE);
        view.setOnClickPendingIntent(R.id.notification_capture, capturePending);
        view.setOnClickPendingIntent(R.id.notification_toggle, togglePending);

        boolean swipeEnd = getSharedPreferences(PREFS, MODE_PRIVATE)
                .getBoolean(KEY_NOTIFICATION_SWIPE_END, true);

        Notification.Builder builder = new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .setOngoing(!swipeEnd)
                .setAutoCancel(false)
                .setContentIntent(openPending)
                .setCustomContentView(view)
                .setStyle(new Notification.DecoratedCustomViewStyle());

        if (swipeEnd) {
            builder.setDeleteIntent(dismissedPending);
        }

        return builder.build();
    }

    private void updateNotification() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) nm.notify(NOTIFICATION_ID, buildNotification());
    }

    private void createChannel() {
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "FinderlessCamera",
                NotificationManager.IMPORTANCE_LOW
        );
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) nm.createNotificationChannel(channel);
    }

    private void ensureCameraOpen(boolean allowWhenAutoOff) {
        CrashLogger.log(this, "CAMERA ensureOpen allowWhenAutoOff=" + allowWhenAutoOff + " enabled=" + enabled + " device=" + (cameraDevice != null) + " opening=" + openingCamera);
        if ((!enabled && !allowWhenAutoOff) || cameraDevice != null || openingCamera) return;
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return;

        openingCamera = true;
        CameraManager manager = getSystemService(CameraManager.class);
        if (manager == null) {
            openingCamera = false;
            return;
        }

        try {
            String selectedCameraId = chooseAutomaticBackCamera(manager);
            if (selectedCameraId == null) {
                openingCamera = false;
                return;
            }

            manager.openCamera(selectedCameraId, new CameraDevice.StateCallback() {
                @Override
                public void onOpened(CameraDevice camera) {
                    CrashLogger.log(CameraForegroundService.this, "CAMERA onOpened");
                    openingCamera = false;
                    cameraDevice = camera;
                    createSession();
                }

                @Override
                public void onDisconnected(CameraDevice camera) {
                    CrashLogger.log(CameraForegroundService.this, "CAMERA onDisconnected");
                    openingCamera = false;
                    camera.close();
                    cameraDevice = null;
                    session = null;
                }

                @Override
                public void onError(CameraDevice camera, int error) {
                    CrashLogger.log(CameraForegroundService.this, "CAMERA onError code=" + error);
                    openingCamera = false;
                    camera.close();
                    cameraDevice = null;
                    session = null;
                }
            }, cameraHandler);
        } catch (Exception e) {
            openingCamera = false;
        }
    }

    private String chooseAutomaticBackCamera(CameraManager manager) {
        boolean useFront = getSharedPreferences(PREFS, MODE_PRIVATE)
                .getBoolean(KEY_USE_FRONT_CAMERA, false);
        int wantedFacing = useFront
                ? CameraCharacteristics.LENS_FACING_FRONT
                : CameraCharacteristics.LENS_FACING_BACK;

        jpegSize = null;
        focusSize = null;
        selectedAfMode = CaptureRequest.CONTROL_AF_MODE_OFF;

        try {
            for (String id : manager.getCameraIdList()) {
                try {
                    CameraCharacteristics c = manager.getCameraCharacteristics(id);
                    Integer facing = c.get(CameraCharacteristics.LENS_FACING);
                    if (facing == null || facing != wantedFacing) continue;

                    StreamConfigurationMap map =
                            c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
                    if (map == null) continue;

                    Size[] jpegSizes = map.getOutputSizes(ImageFormat.JPEG);
                    Size[] yuvSizes = map.getOutputSizes(ImageFormat.YUV_420_888);
                    if (jpegSizes == null || jpegSizes.length == 0
                            || yuvSizes == null || yuvSizes.length == 0) {
                        continue;
                    }

                    jpegSize = chooseJpegSize(map);
                    focusSize = Arrays.stream(yuvSizes)
                            .filter(s -> s.getWidth() >= 640 && s.getHeight() >= 480)
                            .min(Comparator.comparingLong(
                                    s -> (long) s.getWidth() * s.getHeight()
                            ))
                            .orElse(yuvSizes[0]);

                    int[] afModes = c.get(
                            CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES
                    );
                    selectedAfMode = chooseAfMode(afModes);

                    Integer so = c.get(CameraCharacteristics.SENSOR_ORIENTATION);
                    if (so != null) sensorOrientation = so;

                    return id;
                } catch (Exception ignored) { }
            }
        } catch (Exception ignored) { }

        jpegSize = null;
        focusSize = null;
        return null;
    }

    private int chooseAfMode(int[] modes) {
        if (modes == null || modes.length == 0) {
            return CaptureRequest.CONTROL_AF_MODE_OFF;
        }

        for (int mode : modes) {
            if (mode == CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE) {
                return mode;
            }
        }

        for (int mode : modes) {
            if (mode == CaptureRequest.CONTROL_AF_MODE_AUTO) {
                return mode;
            }
        }

        return CaptureRequest.CONTROL_AF_MODE_OFF;
    }

    private void restartCameraForSelection() {
        if (cameraHandler == null) return;

        cameraHandler.post(() -> {
            closeCamera();

            boolean floatEnabled = getSharedPreferences(PREFS, MODE_PRIVATE)
                    .getBoolean(KEY_FLOAT_ENABLED, false);

            if (residentRunning || floatEnabled || enabled) {
                ensureCameraOpen(true);
            }

            sendBroadcast(new Intent(ACTION_CAMERA_STATE_CHANGED)
                    .setPackage(getPackageName()));
        });
    }

    private Size chooseJpegSize(StreamConfigurationMap map) {
        Size[] sizes = map.getOutputSizes(ImageFormat.JPEG);
        if (sizes == null || sizes.length == 0) return new Size(1920, 1080);

        double targetRatio = 16.0 / 9.0;
        try {
            WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
            if (wm != null) {
                DisplayMetrics metrics = new DisplayMetrics();
                wm.getDefaultDisplay().getRealMetrics(metrics);
                int longSide = Math.max(metrics.widthPixels, metrics.heightPixels);
                int shortSide = Math.min(metrics.widthPixels, metrics.heightPixels);
                if (shortSide > 0) {
                    targetRatio = (double) longSide / (double) shortSide;
                }
            }
        } catch (Exception ignored) { }

        double closestError = Double.MAX_VALUE;
        for (Size s : sizes) {
            int longSide = Math.max(s.getWidth(), s.getHeight());
            int shortSide = Math.min(s.getWidth(), s.getHeight());
            if (shortSide == 0) continue;
            double ratio = (double) longSide / (double) shortSide;
            closestError = Math.min(closestError, Math.abs(ratio - targetRatio));
        }

        double allowedError = closestError + 0.015;
        Size best = sizes[0];
        long bestPixels = 0;

        for (Size s : sizes) {
            int longSide = Math.max(s.getWidth(), s.getHeight());
            int shortSide = Math.min(s.getWidth(), s.getHeight());
            if (shortSide == 0) continue;

            double ratio = (double) longSide / (double) shortSide;
            double error = Math.abs(ratio - targetRatio);
            long pixels = (long) s.getWidth() * s.getHeight();

            if (error <= allowedError && pixels > bestPixels) {
                best = s;
                bestPixels = pixels;
            }
        }
        return best;
    }

    private void createSession() {
        CrashLogger.log(this, "CAMERA createSession BEGIN jpeg=" + jpegSize + " focus=" + focusSize);
        if (cameraDevice == null || jpegSize == null || focusSize == null) return;
        closeReadersOnly();

        jpegReader = ImageReader.newInstance(
                jpegSize.getWidth(),
                jpegSize.getHeight(),
                ImageFormat.JPEG,
                2
        );
        focusReader = ImageReader.newInstance(
                focusSize.getWidth(),
                focusSize.getHeight(),
                ImageFormat.YUV_420_888,
                2
        );

        focusReader.setOnImageAvailableListener(reader -> {
            Image image = reader.acquireLatestImage();
            if (image != null) image.close();
        }, cameraHandler);

        jpegReader.setOnImageAvailableListener(this::saveImage, cameraHandler);

        List<Surface> surfaces = new ArrayList<>();
        surfaces.add(focusReader.getSurface());
        surfaces.add(jpegReader.getSurface());

        try {
            cameraDevice.createCaptureSession(
                    surfaces,
                    new CameraCaptureSession.StateCallback() {
                        @Override
                        public void onConfigured(CameraCaptureSession configuredSession) {
                            CrashLogger.log(CameraForegroundService.this, "CAMERA session configured");
                            if (cameraDevice == null) return;
                            session = configuredSession;

                            try {
                                previewBuilder = cameraDevice.createCaptureRequest(
                                        CameraDevice.TEMPLATE_PREVIEW
                                );
                                previewBuilder.addTarget(focusReader.getSurface());
                                previewBuilder.set(
                                        CaptureRequest.CONTROL_AF_MODE,
                                        selectedAfMode
                                );
                                previewBuilder.set(
                                        CaptureRequest.CONTROL_AE_MODE,
                                        CaptureRequest.CONTROL_AE_MODE_ON
                                );
                                previewBuilder.set(
                                        CaptureRequest.FLASH_MODE,
                                        CaptureRequest.FLASH_MODE_OFF
                                );

                                session.setRepeatingRequest(
                                        previewBuilder.build(),
                                        null,
                                        cameraHandler
                                );

                                if (enabled) startAutoCapture();

                                if (manualCapturePending) {
                                    manualCapturePending = false;
                                    cameraHandler.postDelayed(
                                            () -> capturePhoto(true),
                                            250L
                                    );
                                }
                            } catch (CameraAccessException ignored) { }
                        }

                        @Override
                        public void onConfigureFailed(CameraCaptureSession failedSession) {
                            CrashLogger.log(CameraForegroundService.this, "CAMERA session configure FAILED");
                            session = null;
                        }
                    },
                    cameraHandler
            );
        } catch (CameraAccessException ignored) { }
    }

    private void startAutoCapture() {
        CrashLogger.log(this, "AUTO start intervalMs=" + CAPTURE_INTERVAL_MS);
        if (cameraHandler == null || !enabled) return;
        cameraHandler.removeCallbacks(autoCaptureRunnable);
        cameraHandler.postDelayed(autoCaptureRunnable, CAPTURE_INTERVAL_MS);
    }

    private void stopAutoCapture() {
        CrashLogger.log(this, "AUTO stop");
        if (cameraHandler != null) {
            cameraHandler.removeCallbacks(autoCaptureRunnable);
        }
    }

    private void captureBurst3() {
        enqueueManualShots(3);
    }

    private void capturePhoto(boolean manual) {
        CrashLogger.log(this, "CAPTURE begin manual=" + manual + " enabled=" + enabled + " inProgress=" + captureInProgress);
        if (!manual && !enabled) return;

        if (cameraDevice == null || session == null
                || jpegReader == null || previewBuilder == null) {
            if (manual) manualCapturePending = true;
            ensureCameraOpen(true);
            return;
        }

        if (captureInProgress) {
            if (manual) {
                pendingManualShots++;
                manualCapturePending = true;
                CrashLogger.log(this, "CAPTURE manual queued during active capture");
            }
            return;
        }

        captureInProgress = true;
        stillRequested = false;

        try {
            previewBuilder.set(
                    CaptureRequest.CONTROL_AF_TRIGGER,
                    CaptureRequest.CONTROL_AF_TRIGGER_START
            );

            session.capture(
                    previewBuilder.build(),
                    new CameraCaptureSession.CaptureCallback() {
                        @Override
                        public void onCaptureCompleted(
                                CameraCaptureSession s,
                                CaptureRequest request,
                                TotalCaptureResult result
                        ) {
                            Integer afState = result.get(
                                    CaptureResult.CONTROL_AF_STATE
                            );

                            if (afState == null
                                    || afState == CaptureResult.CONTROL_AF_STATE_FOCUSED_LOCKED
                                    || afState == CaptureResult.CONTROL_AF_STATE_NOT_FOCUSED_LOCKED
                                    || afState == CaptureResult.CONTROL_AF_STATE_PASSIVE_FOCUSED
                                    || afState == CaptureResult.CONTROL_AF_STATE_PASSIVE_UNFOCUSED) {
                                requestStill();
                            }
                        }
                    },
                    cameraHandler
            );

            cameraHandler.postDelayed(() -> {
                if (captureInProgress) requestStill();
            }, AF_FALLBACK_MS);

        } catch (CameraAccessException e) {
            captureInProgress = false;
            stillRequested = false;
        }
    }

    private void requestStill() {
        CrashLogger.log(this, "CAPTURE requestStill inProgress=" + captureInProgress + " stillRequested=" + stillRequested);
        if (!captureInProgress || stillRequested) return;
        stillRequested = true;
        takeStillPhoto();
    }

    private int getJpegOrientation() {
        int deviceDegrees = 0;
        try {
            WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
            if (wm != null) {
                int rotation = wm.getDefaultDisplay().getRotation();
                if (rotation == Surface.ROTATION_90) deviceDegrees = 90;
                else if (rotation == Surface.ROTATION_180) deviceDegrees = 180;
                else if (rotation == Surface.ROTATION_270) deviceDegrees = 270;
            }
        } catch (Exception ignored) { }

        return (sensorOrientation - deviceDegrees + 360) % 360;
    }

    private void takeStillPhoto() {
        CrashLogger.log(this, "CAPTURE takeStillPhoto");
        if (!captureInProgress || cameraDevice == null
                || session == null || jpegReader == null) {
            finishFocusCycle();
            return;
        }

        try {
            CaptureRequest.Builder still = cameraDevice.createCaptureRequest(
                    CameraDevice.TEMPLATE_STILL_CAPTURE
            );
            still.addTarget(jpegReader.getSurface());
            still.set(
                    CaptureRequest.CONTROL_AF_MODE,
                    selectedAfMode
            );
            still.set(
                    CaptureRequest.CONTROL_AE_MODE,
                    CaptureRequest.CONTROL_AE_MODE_ON
            );
            still.set(CaptureRequest.FLASH_MODE, CaptureRequest.FLASH_MODE_OFF);
            still.set(CaptureRequest.JPEG_ORIENTATION, getJpegOrientation());
            still.set(CaptureRequest.JPEG_QUALITY, (byte) 100);

            session.capture(
                    still.build(),
                    new CameraCaptureSession.CaptureCallback() {
                        @Override
                        public void onCaptureCompleted(
                                CameraCaptureSession s,
                                CaptureRequest request,
                                TotalCaptureResult result
                        ) {
                            CrashLogger.log(CameraForegroundService.this, "CAPTURE still completed");
                            vibrateOnce();

                            boolean shouldClose = closeAfterManualCapture
                                    && !residentRunning
                                    && !getSharedPreferences(PREFS, MODE_PRIVATE)
                                            .getBoolean(KEY_FLOAT_ENABLED, false);
                            closeAfterManualCapture = false;

                            finishFocusCycle();

                            if (shouldClose && cameraHandler != null) {
                                cameraHandler.postDelayed(
                                        () -> {
                                            if (!enabled) closeCamera();
                                        },
                                        150L
                                );
                            }
                        }

                        @Override
                        public void onCaptureFailed(
                                CameraCaptureSession s,
                                CaptureRequest request,
                                android.hardware.camera2.CaptureFailure failure
                        ) {
                            closeAfterManualCapture = false;
                            finishFocusCycle();
                        }
                    },
                    cameraHandler
            );
        } catch (CameraAccessException e) {
            closeAfterManualCapture = false;
            finishFocusCycle();
        }
    }

    private void finishFocusCycle() {
        captureInProgress = false;
        stillRequested = false;
        if (pendingManualShots > 0 && cameraHandler != null) {
            cameraHandler.postDelayed(this::runNextManualShot, 90L);
        }

        if (session == null || previewBuilder == null || cameraHandler == null) return;

        try {
            previewBuilder.set(
                    CaptureRequest.CONTROL_AF_TRIGGER,
                    CaptureRequest.CONTROL_AF_TRIGGER_CANCEL
            );
            session.capture(previewBuilder.build(), null, cameraHandler);

            previewBuilder.set(
                    CaptureRequest.CONTROL_AF_TRIGGER,
                    CaptureRequest.CONTROL_AF_TRIGGER_IDLE
            );
            session.setRepeatingRequest(
                    previewBuilder.build(),
                    null,
                    cameraHandler
            );
        } catch (CameraAccessException ignored) { }
    }

    private void saveImage(ImageReader reader) {
        CrashLogger.log(this, "IMAGE save BEGIN");
        Image image = reader.acquireNextImage();
        if (image == null) return;

        try {
            ByteBuffer buffer = image.getPlanes()[0].getBuffer();
            byte[] bytes = new byte[buffer.remaining()];
            buffer.get(bytes);

            String name = "IMG_"
                    + new SimpleDateFormat(
                            "yyyyMMdd_HHmmss_SSS", Locale.US
                    ).format(new Date())
                    + ".jpg";

            String treeUriString = getSharedPreferences(PREFS, MODE_PRIVATE)
                    .getString(KEY_SAVE_FOLDER_URI, null);

            if (treeUriString != null && !treeUriString.trim().isEmpty()) {
                Uri treeUri = Uri.parse(treeUriString);
                Uri parentDocument = DocumentsContract.buildDocumentUriUsingTree(
                        treeUri,
                        DocumentsContract.getTreeDocumentId(treeUri)
                );

                Uri created = DocumentsContract.createDocument(
                        getContentResolver(),
                        parentDocument,
                        "image/jpeg",
                        name
                );

                if (created == null) {
                    throw new IllegalStateException("Could not create image document");
                }

                try (OutputStream out =
                             getContentResolver().openOutputStream(created)) {
                    if (out == null) {
                        throw new IllegalStateException("Could not open image output");
                    }
                    out.write(bytes);
                }

                CrashLogger.log(this, "IMAGE save OK uri=" + created);
            } else {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME, name);
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");

                if (Build.VERSION.SDK_INT >= 29) {
                    values.put(
                            MediaStore.Images.Media.RELATIVE_PATH,
                            "Pictures/FinderlessCamera"
                    );
                    values.put(MediaStore.Images.Media.IS_PENDING, 1);
                }

                Uri uri = getContentResolver().insert(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                        values
                );

                if (uri != null) {
                    try (OutputStream out =
                                 getContentResolver().openOutputStream(uri)) {
                        if (out != null) out.write(bytes);
                    }

                    if (Build.VERSION.SDK_INT >= 29) {
                        ContentValues done = new ContentValues();
                        done.put(MediaStore.Images.Media.IS_PENDING, 0);
                        getContentResolver().update(uri, done, null, null);
                    }

                    CrashLogger.log(this, "IMAGE save OK uri=" + uri);
                }
            }
        } catch (Exception error) {
            CrashLogger.logThrowable(this, "IMAGE save FAILED", error);
        } finally {
            image.close();
        }
    }

    private void flashShutters(boolean burst) {
        if (floatingShutter != null) {
            floatingShutter.flashInner(burst);
        }

        if (burst) {
            pulseNotificationFlash(0L);
            pulseNotificationFlash(150L);
            pulseNotificationFlash(300L);
        } else {
            pulseNotificationFlash(0L);
        }
    }

    private void pulseNotificationFlash(long delayMs) {
        mainHandler.postDelayed(() -> {
            notificationFlash = true;
            updateNotification();
            mainHandler.postDelayed(() -> {
                notificationFlash = false;
                updateNotification();
            }, 90L);
        }, delayMs);
    }

    private void vibrateBurstNow() {
        boolean vibrationEnabled = getSharedPreferences(PREFS, MODE_PRIVATE)
                .getBoolean(KEY_SHUTTER_VIBRATION, true);
        if (!vibrationEnabled) return;

        Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        if (vibrator == null || !vibrator.hasVibrator()) return;

        if (Build.VERSION.SDK_INT >= 26) {
            long[] timings = new long[]{0, 70, 45, 70, 45, 70};
            int[] amplitudes = new int[]{0, 255, 0, 255, 0, 255};
            vibrator.vibrate(VibrationEffect.createWaveform(timings, amplitudes, -1));
        } else {
            vibrator.vibrate(new long[]{0, 70, 45, 70, 45, 70}, -1);
        }
    }

    private void vibrateOnce() {
        vibrate(90, 255);
    }

    private void vibrateLongPress() {
        vibrate(40, 200);
    }

    private void vibrateShutterNow() {
        boolean enabled = getSharedPreferences(PREFS, MODE_PRIVATE)
                .getBoolean(KEY_SHUTTER_VIBRATION, true);
        if (enabled) {
            vibrate(140L, 255);
        }
    }

    private void vibrate(long durationMs, int amplitude) {
        Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        if (vibrator == null || !vibrator.hasVibrator()) return;
        if (Build.VERSION.SDK_INT >= 26) {
            vibrator.vibrate(VibrationEffect.createOneShot(durationMs, amplitude));
        } else {
            vibrator.vibrate(durationMs);
        }
    }

    private void setFloatingEnabled(boolean value) {
        CrashLogger.log(this, "FLOAT setEnabled " + value);
        getSharedPreferences(PREFS, MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_FLOAT_ENABLED, value)
                .apply();

        if (value) {
            showFloatingShutterIfAllowed();
            ensureCameraOpen(true);
        } else {
            removeFloatingShutter();
            if (!residentRunning && !enabled && !captureInProgress) {
                closeCamera();
                stopForeground(STOP_FOREGROUND_REMOVE);
                stopSelf();
            }
        }

        sendBroadcast(new Intent(ACTION_FLOAT_STATE_CHANGED).setPackage(getPackageName()));
    }

    private void showFloatingShutterIfAllowed() {
        CrashLogger.log(this, "FLOAT show requested overlayAllowed=" + Settings.canDrawOverlays(this));
        if (!Settings.canDrawOverlays(this) || floatingShutter != null) return;
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (windowManager == null) return;

        DisplayMetrics metrics = getDisplayMetrics();
        int maxX = Math.max(0, metrics.widthPixels - FLOAT_SIZE_PX);
        int maxY = Math.max(0, metrics.heightPixels - FLOAT_SIZE_PX);
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        int defaultX = Math.max(0, metrics.widthPixels - FLOAT_SIZE_PX - 300);
        int defaultY = Math.max(0, metrics.heightPixels - FLOAT_SIZE_PX - 300);
        int savedX = clamp(prefs.getInt(KEY_FLOAT_X, defaultX), 0, maxX);
        int savedY = clamp(prefs.getInt(KEY_FLOAT_Y, defaultY), 0, maxY);

        floatingShutter = new FloatingShutterView();
        int windowType = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        floatingParams = new WindowManager.LayoutParams(
                FLOAT_SIZE_PX, FLOAT_SIZE_PX, windowType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                android.graphics.PixelFormat.TRANSLUCENT);
        floatingParams.gravity = Gravity.TOP | Gravity.START;
        floatingParams.x = savedX;
        floatingParams.y = savedY;
        floatingShutter.setOnTouchListener(this::handleFloatingTouch);
        try {
            windowManager.addView(floatingShutter, floatingParams);
        } catch (Exception e) {
            floatingShutter = null;
            floatingParams = null;
        }
    }

    private boolean handleFloatingTouch(View view, MotionEvent event) {
        if (floatingParams == null || windowManager == null) return false;

        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                draggingFloat = false;
                snappedToDelete = false;
                setDeleteSnapVisual(false);
                downRawX = event.getRawX();
                downRawY = event.getRawY();
                downWindowX = floatingParams.x;
                downWindowY = floatingParams.y;
                grabOffsetX = event.getRawX() - floatingParams.x;
                grabOffsetY = event.getRawY() - floatingParams.y;
                downTimeMs = System.currentTimeMillis();
                longPressRunnable = () -> {
                    draggingFloat = true;
                    vibrateLongPress();
                    showDeleteTarget();
                };
                mainHandler.postDelayed(longPressRunnable, LONG_PRESS_MS);
                return true;

            case MotionEvent.ACTION_MOVE:
                float dx = event.getRawX() - downRawX;
                float dy = event.getRawY() - downRawY;
                if (!draggingFloat && (Math.abs(dx) > 24 || Math.abs(dy) > 24)) {
                    if (longPressRunnable != null) {
                        mainHandler.removeCallbacks(longPressRunnable);
                        longPressRunnable = null;
                    }
                }
                if (!draggingFloat) return true;

                DisplayMetrics metrics = getDisplayMetrics();
                int maxX = Math.max(0, metrics.widthPixels - FLOAT_SIZE_PX);
                int maxY = Math.max(0, metrics.heightPixels - FLOAT_SIZE_PX);
                float targetCenterX = metrics.widthPixels / 2f;
                float targetCenterY = metrics.heightPixels / 2f;
                float fingerDistance = distance(event.getRawX(), event.getRawY(), targetCenterX, targetCenterY);

                if (!snappedToDelete && fingerDistance <= SNAP_DISTANCE_PX) {
                    snappedToDelete = true;
                    setDeleteSnapVisual(true);
                    animateDeleteTargetScale(true);
                    floatingParams.x = clamp(Math.round(targetCenterX - FLOAT_SIZE_PX / 2f), 0, maxX);
                    floatingParams.y = clamp(Math.round(targetCenterY - FLOAT_SIZE_PX / 2f), 0, maxY);
                    updateFloatingLayout();
                    return true;
                }

                if (snappedToDelete) {
                    if (fingerDistance >= RELEASE_DISTANCE_PX) {
                        snappedToDelete = false;
                        setDeleteSnapVisual(false);
                        animateDeleteTargetScale(false);

                        floatingParams.x = clamp(
                                Math.round(event.getRawX() - grabOffsetX),
                                0,
                                maxX
                        );
                        floatingParams.y = clamp(
                                Math.round(event.getRawY() - grabOffsetY),
                                0,
                                maxY
                        );
                        updateFloatingLayout();

                        downRawX = event.getRawX();
                        downRawY = event.getRawY();
                        downWindowX = floatingParams.x;
                        downWindowY = floatingParams.y;
                        return true;
                    } else {
                        return true;
                    }
                }

                floatingParams.x = clamp(downWindowX + Math.round(dx), 0, maxX);
                floatingParams.y = clamp(downWindowY + Math.round(dy), 0, maxY);
                updateFloatingLayout();
                return true;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (longPressRunnable != null) {
                    mainHandler.removeCallbacks(longPressRunnable);
                    longPressRunnable = null;
                }
                if (draggingFloat) {
                    draggingFloat = false;
                    if (snappedToDelete) {
                        snappedToDelete = false;
                        animateFloatingDelete();
                    } else {
                        animateDeleteTargetScale(false);
                        setDeleteSnapVisual(false);
                        hideDeleteTarget();
                        saveFloatingPosition();
                    }
                    return true;
                }
                float upDx = Math.abs(event.getRawX() - downRawX);
                float upDy = Math.abs(event.getRawY() - downRawY);
                long heldMs = System.currentTimeMillis() - downTimeMs;
                if (heldMs < LONG_PRESS_MS && upDx < 24 && upDy < 24) handleManualCapture();
                return true;
            default:
                return false;
        }
    }

    private void setDeleteSnapVisual(boolean snapped) {
        int color = snapped ? Color.RED : Color.WHITE;
        if (floatingShutter != null) floatingShutter.setRingColor(color);
        if (deleteTarget != null) deleteTarget.setTextColor(color);
    }

    private void animateDeleteTargetScale(boolean expand) {
        if (deleteTarget == null) return;
        float targetScale = expand ? 2f : 1f;
        deleteTarget.animate()
                .scaleX(targetScale)
                .scaleY(targetScale)
                .setDuration(expand ? 1000L : 500L)
                .setInterpolator(expand
                        ? new PathInterpolator(0.01f, 0.98f, 0.04f, 1.00f)
                        : new PathInterpolator(0.85f, 0.00f, 1.00f, 0.20f))
                .start();
    }

    private void showDeleteTarget() {
        if (windowManager == null || deleteTarget != null) return;
        DisplayMetrics metrics = getDisplayMetrics();
        deleteTarget = new TextView(this);
        deleteTarget.setText("×");
        deleteTarget.setTextSize(54f);
        deleteTarget.setTextColor(Color.WHITE);
        deleteTarget.setGravity(Gravity.CENTER);
        deleteTarget.setAlpha(0f);
        deleteTarget.setScaleX(1f);
        deleteTarget.setScaleY(1f);
        int windowType = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        deleteTargetParams = new WindowManager.LayoutParams(
                DELETE_TARGET_SIZE_PX, DELETE_TARGET_SIZE_PX, windowType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                android.graphics.PixelFormat.TRANSLUCENT);
        deleteTargetParams.gravity = Gravity.TOP | Gravity.START;
        deleteTargetParams.x = Math.round(metrics.widthPixels / 2f - DELETE_TARGET_SIZE_PX / 2f);
        deleteTargetParams.y = Math.round(metrics.heightPixels / 2f - DELETE_TARGET_SIZE_PX / 2f - 16f);
        try {
            windowManager.addView(deleteTarget, deleteTargetParams);
            deleteTarget.animate().alpha(1f).setDuration(120L).start();
        } catch (Exception e) {
            deleteTarget = null;
            deleteTargetParams = null;
        }
    }

    private void hideDeleteTarget() {
        if (deleteTarget == null || windowManager == null) return;
        TextView target = deleteTarget;
        deleteTarget = null;
        deleteTargetParams = null;
        target.animate().alpha(0f).setDuration(100L).withEndAction(() -> {
            try { windowManager.removeView(target); } catch (Exception ignored) { }
        }).start();
    }

    private void animateFloatingDelete() {
        getSharedPreferences(PREFS, MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_FLOAT_ENABLED, false)
                .remove(KEY_FLOAT_X)
                .remove(KEY_FLOAT_Y)
                .apply();
        sendBroadcast(new Intent(ACTION_FLOAT_STATE_CHANGED).setPackage(getPackageName()));

        if (deleteTarget != null) {
            deleteTarget.animate().scaleX(0f).scaleY(0f).alpha(0f)
                    .setDuration(1000L)
                    .setInterpolator(new PathInterpolator(0.97f, 0.00f, 1.00f, 0.02f)).start();
        }
        if (floatingShutter == null) {
            getSharedPreferences(PREFS, MODE_PRIVATE)
                    .edit()
                    .putBoolean(KEY_FLOAT_ENABLED, false)
                    .apply();
            removeFloatingAfterDeleteImmediate();
            return;
        }

        FloatingShutterView shutter = floatingShutter;
        shutter.animate()
                .scaleX(0f)
                .scaleY(0f)
                .alpha(0f)
                .setDuration(1000L)
                .setInterpolator(new PathInterpolator(0.97f, 0.00f, 1.00f, 0.02f))
                .withEndAction(() -> {
                    shutter.setVisibility(View.INVISIBLE);
                    getSharedPreferences(PREFS, MODE_PRIVATE)
                            .edit()
                            .putBoolean(KEY_FLOAT_ENABLED, false)
                            .apply();
                    sendBroadcast(new Intent(ACTION_FLOAT_STATE_CHANGED).setPackage(getPackageName()));
                    removeFloatingAfterDeleteImmediate();
                })
                .start();
    }

    private void removeFloatingAfterDeleteImmediate() {
        if (windowManager != null && deleteTarget != null) {
            TextView target = deleteTarget;
            deleteTarget = null;
            deleteTargetParams = null;

            try {
                target.animate().cancel();
                target.setVisibility(View.INVISIBLE);
                windowManager.removeViewImmediate(target);
            } catch (Exception ignored) { }
        }

        if (windowManager != null && floatingShutter != null) {
            FloatingShutterView shutter = floatingShutter;
            floatingShutter = null;
            floatingParams = null;

            try {
                shutter.animate().cancel();
                shutter.setVisibility(View.INVISIBLE);
                windowManager.removeViewImmediate(shutter);
            } catch (Exception ignored) { }
        }

        draggingFloat = false;
        snappedToDelete = false;
    }

    private void updateFloatingLayout() {
        if (floatingShutter == null || floatingParams == null || windowManager == null) return;
        clampFloatingParamsToScreen();
        try { windowManager.updateViewLayout(floatingShutter, floatingParams); } catch (Exception ignored) { }
    }

    private void clampFloatingParamsToScreen() {
        if (floatingParams == null || windowManager == null) return;
        DisplayMetrics metrics = getDisplayMetrics();
        int maxX = Math.max(0, metrics.widthPixels - FLOAT_SIZE_PX);
        int maxY = Math.max(0, metrics.heightPixels - FLOAT_SIZE_PX);
        floatingParams.x = clamp(floatingParams.x, 0, maxX);
        floatingParams.y = clamp(floatingParams.y, 0, maxY);
    }

    private DisplayMetrics getDisplayMetrics() {
        DisplayMetrics metrics = new DisplayMetrics();
        if (windowManager != null) windowManager.getDefaultDisplay().getRealMetrics(metrics);
        return metrics;
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(value, max));
    }

    private static float distance(float x1, float y1, float x2, float y2) {
        float dx = x1 - x2;
        float dy = y1 - y2;
        return (float) Math.sqrt(dx * dx + dy * dy);
    }

    private void saveFloatingPosition() {
        if (floatingParams == null) return;
        clampFloatingParamsToScreen();
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putInt(KEY_FLOAT_X, floatingParams.x)
                .putInt(KEY_FLOAT_Y, floatingParams.y)
                .apply();
    }

    private void removeFloatingShutter() {
        removeFloatingShutter(true);
    }

    private void removeFloatingShutter(boolean savePosition) {
        hideDeleteTarget();

        if (savePosition) {
            saveFloatingPosition();
        }

        if (floatingShutter != null && windowManager != null) {
            try { windowManager.removeView(floatingShutter); } catch (Exception ignored) { }
        }
        floatingShutter = null;
        floatingParams = null;
        draggingFloat = false;
        snappedToDelete = false;
    }

    private void closeReadersOnly() {
        if (jpegReader != null) {
            jpegReader.close();
            jpegReader = null;
        }

        if (focusReader != null) {
            focusReader.close();
            focusReader = null;
        }
    }

    private void closeCamera() {
        stopAutoCapture();

        if (session != null) {
            session.close();
            session = null;
        }

        previewBuilder = null;

        if (cameraDevice != null) {
            cameraDevice.close();
            cameraDevice = null;
        }

        closeReadersOnly();
        captureInProgress = false;
        stillRequested = false;
        openingCamera = false;
        manualCapturePending = false;
    }

    @Override
    public void onDestroy() {
        CrashLogger.log(this, "SERVICE onDestroy");
        removeFloatingShutter();
        closeCamera();

        if (cameraThread != null) {
            cameraThread.quitSafely();
            cameraThread = null;
        }

        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private class FloatingShutterView extends View {
        private final Paint ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint innerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float innerFlash = 0f;

        FloatingShutterView() {
            super(CameraForegroundService.this);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);

            ringPaint.setStyle(Paint.Style.STROKE);
            ringPaint.setStrokeWidth(14f);
            ringPaint.setColor(Color.WHITE);
            ringPaint.setStrokeCap(Paint.Cap.ROUND);
            innerPaint.setStyle(Paint.Style.FILL);
            innerPaint.setColor(Color.WHITE);
        }

        void flashInner(boolean burst) {
            float[] values = burst
                    ? new float[]{0f, 1f, 0f, 1f, 0f, 1f, 0f}
                    : new float[]{0f, 1f, 0f};

            ValueAnimator animator = ValueAnimator.ofFloat(values);
            animator.setDuration(burst ? 620L : 420L);
            animator.setInterpolator(new DecelerateInterpolator());
            animator.addUpdateListener(a -> {
                innerFlash = (float) a.getAnimatedValue();
                invalidate();
            });
            animator.start();
        }

        void setRingColor(int color) {
            ringPaint.setColor(color);
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float radius = Math.min(getWidth(), getHeight()) / 2f - 16f;
            if (innerFlash > 0f) {
                innerPaint.setAlpha(Math.round(255f * innerFlash));
                canvas.drawCircle(
                        getWidth() / 2f,
                        getHeight() / 2f,
                        Math.max(0f, radius - 14f),
                        innerPaint
                );
            }
            canvas.drawCircle(
                    getWidth() / 2f,
                    getHeight() / 2f,
                    radius,
                    ringPaint
            );
        }
    }
}
