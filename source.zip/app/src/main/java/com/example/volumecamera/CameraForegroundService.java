package com.example.volumecamera;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.ImageFormat;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.CaptureResult;
import android.hardware.camera2.TotalCaptureResult;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.Image;
import android.media.ImageReader;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.MediaStore;
import android.util.Size;
import android.view.Surface;
import android.view.WindowManager;
import android.util.DisplayMetrics;
import android.widget.RemoteViews;

import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class CameraForegroundService extends Service {
    public static final String ACTION_START = "com.example.volumecamera.START";
    public static final String ACTION_TOGGLE = "com.example.volumecamera.TOGGLE";
    public static final String PREFS = "volume_camera_prefs";
    public static final String KEY_ENABLED = "enabled";

    private static final String CHANNEL_ID = "finderless_camera_channel";
    private static final int NOTIFICATION_ID = 20;

    private HandlerThread cameraThread;
    private Handler cameraHandler;
    private CameraDevice cameraDevice;
    private CameraCaptureSession session;
    private CaptureRequest.Builder previewBuilder;
    private ImageReader jpegReader;
    private ImageReader focusReader;
    private String cameraId;
    private int sensorOrientation = 90;
    private Size jpegSize;
    private Size focusSize;
    private boolean openingCamera = false;
    private boolean enabled = false;
    private boolean captureInProgress = false;
    private static final long CAPTURE_INTERVAL_MS = 5000L;

    private final Runnable autoCaptureRunnable = new Runnable() {
        @Override public void run() {
            if (!enabled) return;
            capturePhoto();
            if (cameraHandler != null) cameraHandler.postDelayed(this, CAPTURE_INTERVAL_MS);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();
        cameraThread = new HandlerThread("VolumeCameraThread");
        cameraThread.start();
        cameraHandler = new Handler(cameraThread.getLooper());
        enabled = getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(KEY_ENABLED, false);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : ACTION_START;
        startForeground(NOTIFICATION_ID, buildNotification());

        if (ACTION_TOGGLE.equals(action)) {
            setEnabled(!enabled);
        } else if (enabled) {
            openCameraIfNeeded();
        }
        return START_STICKY;
    }

    private void setEnabled(boolean newValue) {
        enabled = newValue;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_ENABLED, enabled).apply();
        if (enabled) openCameraIfNeeded(); else closeCamera();
        updateNotification();
    }

    private Notification buildNotification() {
        Intent toggleIntent = new Intent(this, CameraForegroundService.class);
        toggleIntent.setAction(ACTION_TOGGLE);
        PendingIntent togglePending = PendingIntent.getService(
                this, 1, toggleIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent openPending = PendingIntent.getActivity(
                this, 2, openIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        RemoteViews view = new RemoteViews(getPackageName(), R.layout.notification_camera);
        view.setTextViewText(R.id.notification_status, enabled ? "3秒ごとに自動撮影中" : "停止中");
        view.setTextViewText(R.id.notification_toggle, enabled ? "ON" : "OFF");
        view.setInt(R.id.notification_toggle, "setBackgroundResource",
                enabled ? R.drawable.toggle_on : R.drawable.toggle_off);
        view.setOnClickPendingIntent(R.id.notification_toggle, togglePending);

        return new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .setOngoing(true)
                .setContentIntent(openPending)
                .setCustomContentView(view)
                .setStyle(new Notification.DecoratedCustomViewStyle())
                .build();
    }

    private void updateNotification() {
        getSystemService(NotificationManager.class).notify(NOTIFICATION_ID, buildNotification());
    }

    private void createChannel() {
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "FinderlessCamera", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("3秒間隔の自動撮影状態");
        getSystemService(NotificationManager.class).createNotificationChannel(channel);
    }

    private void openCameraIfNeeded() {
        if (!enabled || cameraDevice != null || openingCamera) return;
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return;
        openingCamera = true;

        CameraManager manager = getSystemService(CameraManager.class);
        try {
            chooseBackCamera(manager);
            if (cameraId == null) {
                openingCamera = false;
                return;
            }
            manager.openCamera(cameraId, new CameraDevice.StateCallback() {
                @Override public void onOpened(CameraDevice camera) {
                    openingCamera = false;
                    cameraDevice = camera;
                    createSession();
                }
                @Override public void onDisconnected(CameraDevice camera) {
                    openingCamera = false;
                    camera.close();
                    cameraDevice = null;
                }
                @Override public void onError(CameraDevice camera, int error) {
                    openingCamera = false;
                    camera.close();
                    cameraDevice = null;
                }
            }, cameraHandler);
        } catch (Exception e) {
            openingCamera = false;
        }
    }

    private void chooseBackCamera(CameraManager manager) throws CameraAccessException {
        for (String id : manager.getCameraIdList()) {
            CameraCharacteristics c = manager.getCameraCharacteristics(id);
            Integer facing = c.get(CameraCharacteristics.LENS_FACING);
            if (facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) {
                StreamConfigurationMap map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
                if (map == null) continue;
                Size[] sizes = map.getOutputSizes(ImageFormat.JPEG);
                Size[] focusSizes = map.getOutputSizes(ImageFormat.YUV_420_888);
                if (sizes == null || sizes.length == 0 || focusSizes == null || focusSizes.length == 0) continue;
                cameraId = id;
                jpegSize = Arrays.stream(sizes)
                        .filter(s -> ((long) s.getWidth() * s.getHeight()) <= 12_500_000L)
                        .max(Comparator.comparingLong(s -> (long) s.getWidth() * s.getHeight()))
                        .orElse(Arrays.stream(sizes)
                                .max(Comparator.comparingLong(s -> (long) s.getWidth() * s.getHeight()))
                                .orElse(sizes[0]));
                focusSize = Arrays.stream(focusSizes)
                        .filter(s -> s.getWidth() >= 640 && s.getHeight() >= 480)
                        .min(Comparator.comparingLong(s -> (long) s.getWidth() * s.getHeight()))
                        .orElse(focusSizes[0]);
                return;
            }
        }
    }

    private void createSession() {
        if (cameraDevice == null || jpegSize == null || focusSize == null) return;
        closeReadersOnly();

        jpegReader = ImageReader.newInstance(jpegSize.getWidth(), jpegSize.getHeight(), ImageFormat.JPEG, 2);
        focusReader = ImageReader.newInstance(focusSize.getWidth(), focusSize.getHeight(), ImageFormat.YUV_420_888, 2);
        focusReader.setOnImageAvailableListener(reader -> {
            Image image = reader.acquireLatestImage();
            if (image != null) image.close();
        }, cameraHandler);
        jpegReader.setOnImageAvailableListener(this::saveImage, cameraHandler);

        List<android.view.Surface> surfaces = new ArrayList<>();
        surfaces.add(focusReader.getSurface());
        surfaces.add(jpegReader.getSurface());

        try {
            cameraDevice.createCaptureSession(surfaces, new CameraCaptureSession.StateCallback() {
                @Override public void onConfigured(CameraCaptureSession s) {
                    if (cameraDevice == null) return;
                    session = s;
                    try {
                        previewBuilder = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
                        previewBuilder.addTarget(focusReader.getSurface());
                        previewBuilder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
                        previewBuilder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
                        previewBuilder.set(CaptureRequest.FLASH_MODE, CaptureRequest.FLASH_MODE_OFF);
                        session.setRepeatingRequest(previewBuilder.build(), null, cameraHandler);
                        startAutoCapture();
                    } catch (CameraAccessException ignored) { }
                }
                @Override public void onConfigureFailed(CameraCaptureSession s) { }
            }, cameraHandler);
        } catch (CameraAccessException ignored) { }
    }

    private void startAutoCapture() {
        if (cameraHandler == null || !enabled) return;
        cameraHandler.removeCallbacks(autoCaptureRunnable);
        cameraHandler.postDelayed(autoCaptureRunnable, CAPTURE_INTERVAL_MS);
    }

    private void stopAutoCapture() {
        if (cameraHandler != null) cameraHandler.removeCallbacks(autoCaptureRunnable);
    }

    private Size chooseJpegSize(StreamConfigurationMap map) {
        Size[] sizes = map.getOutputSizes(ImageFormat.JPEG);
        if (sizes == null || sizes.length == 0) {
            return new Size(1920, 1080);
        }

        // Prefer the current device display aspect ratio. Since saved images are portrait,
        // compare using the long/short side ratio so 1080x2400 and 2400x1080 are equivalent.
        double targetRatio = 16.0 / 9.0;
        try {
            WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
            if (wm != null) {
                DisplayMetrics metrics = new DisplayMetrics();
                wm.getDefaultDisplay().getRealMetrics(metrics);
                int longSide = Math.max(metrics.widthPixels, metrics.heightPixels);
                int shortSide = Math.min(metrics.widthPixels, metrics.heightPixels);
                if (shortSide > 0) targetRatio = (double) longSide / (double) shortSide;
            }
        } catch (Exception ignored) { }

        Size best = sizes[0];
        double bestScore = Double.MAX_VALUE;

        for (Size s : sizes) {
            int longSide = Math.max(s.getWidth(), s.getHeight());
            int shortSide = Math.min(s.getWidth(), s.getHeight());
            if (shortSide == 0) continue;

            double ratio = (double) longSide / (double) shortSide;
            double ratioError = Math.abs(ratio - targetRatio);

            // Avoid extremely huge images for repeated shooting, but still prefer
            // a reasonably high resolution around 8-16 MP when ratios are close.
            long pixels = (long) s.getWidth() * s.getHeight();
            double megapixels = pixels / 1_000_000.0;
            double mpPenalty = megapixels > 16.0 ? (megapixels - 16.0) * 0.02 :
                               megapixels < 6.0 ? (6.0 - megapixels) * 0.02 : 0.0;

            double score = ratioError * 10.0 + mpPenalty;
            if (score < bestScore) {
                bestScore = score;
                best = s;
            }
        }
        return best;
    }

    private void capturePhoto() {
        if (!enabled) return;
        if (cameraDevice == null || session == null || jpegReader == null || previewBuilder == null) {
            openCameraIfNeeded();
            return;
        }
        if (captureInProgress) return;
        captureInProgress = true;

        try {
            previewBuilder.set(CaptureRequest.CONTROL_AF_TRIGGER, CaptureRequest.CONTROL_AF_TRIGGER_START);
            session.capture(previewBuilder.build(), new CameraCaptureSession.CaptureCallback() {
                private boolean shot = false;

                private void maybeShoot(TotalCaptureResult result) {
                    if (shot) return;
                    Integer afState = result.get(CaptureResult.CONTROL_AF_STATE);
                    if (afState == null ||
                            afState == CaptureResult.CONTROL_AF_STATE_FOCUSED_LOCKED ||
                            afState == CaptureResult.CONTROL_AF_STATE_NOT_FOCUSED_LOCKED ||
                            afState == CaptureResult.CONTROL_AF_STATE_PASSIVE_FOCUSED ||
                            afState == CaptureResult.CONTROL_AF_STATE_PASSIVE_UNFOCUSED) {
                        shot = true;
                        takeStillPhoto();
                    }
                }

                @Override
                public void onCaptureCompleted(CameraCaptureSession s, CaptureRequest request,
                                               TotalCaptureResult result) {
                    maybeShoot(result);
                }
            }, cameraHandler);

            // Some devices do not report a locked AF state promptly. Do not miss the 3-second cycle.
            cameraHandler.postDelayed(() -> {
                if (captureInProgress) takeStillPhoto();
            }, 1800L);

        } catch (CameraAccessException e) {
            captureInProgress = false;
        }
    }

    private int getJpegOrientation() {
        int deviceDegrees = 0;
        try {
            WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
            if (wm != null) {
                int rotation = wm.getDefaultDisplay().getRotation();
                if (rotation == Surface.ROTATION_90) deviceDegrees = 90;
                else if (rotation == Surface.ROTATION_180) deviceDegrees = 180;
                else if (rotation == Surface.ROTATION_270) deviceDegrees = 270;
            }
        } catch (Exception ignored) { }

        // Rear camera orientation. For normal portrait usage this usually yields 90°.
        return (sensorOrientation - deviceDegrees + 360) % 360;
    }

    private void takeStillPhoto() {
        if (!captureInProgress || cameraDevice == null || session == null || jpegReader == null) return;

        try {
            CaptureRequest.Builder still = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
            still.addTarget(jpegReader.getSurface());
            still.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            still.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
            still.set(CaptureRequest.FLASH_MODE, CaptureRequest.FLASH_MODE_OFF);
            still.set(CaptureRequest.JPEG_ORIENTATION, getJpegOrientation());

            session.capture(still.build(), new CameraCaptureSession.CaptureCallback() {
                @Override
                public void onCaptureCompleted(CameraCaptureSession s, CaptureRequest request,
                                               TotalCaptureResult result) {
                    vibrateOnce();
                    finishFocusCycle();
                }

                @Override
                public void onCaptureFailed(CameraCaptureSession s, CaptureRequest request,
                                            android.hardware.camera2.CaptureFailure failure) {
                    finishFocusCycle();
                }
            }, cameraHandler);
        } catch (CameraAccessException e) {
            finishFocusCycle();
        }
    }

    private void finishFocusCycle() {
        captureInProgress = false;
        if (session == null || previewBuilder == null || cameraHandler == null) return;
        try {
            previewBuilder.set(CaptureRequest.CONTROL_AF_TRIGGER, CaptureRequest.CONTROL_AF_TRIGGER_CANCEL);
            session.capture(previewBuilder.build(), null, cameraHandler);
            previewBuilder.set(CaptureRequest.CONTROL_AF_TRIGGER, CaptureRequest.CONTROL_AF_TRIGGER_IDLE);
            session.setRepeatingRequest(previewBuilder.build(), null, cameraHandler);
        } catch (CameraAccessException ignored) { }
    }

    private void saveImage(ImageReader reader) {
        Image image = reader.acquireNextImage();
        if (image == null) return;
        try {
            ByteBuffer buffer = image.getPlanes()[0].getBuffer();
            byte[] bytes = new byte[buffer.remaining()];
            buffer.get(bytes);

            String name = "IMG_" + new SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US)
                    .format(new Date()) + ".jpg";
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, name);
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            if (Build.VERSION.SDK_INT >= 29) {
                values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/FinderlessCamera");
                values.put(MediaStore.Images.Media.IS_PENDING, 1);
            }
            Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri != null) {
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out != null) out.write(bytes);
                }
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues done = new ContentValues();
                    done.put(MediaStore.Images.Media.IS_PENDING, 0);
                    getContentResolver().update(uri, done, null, null);
                }
            }
        } catch (Exception ignored) {
        } finally {
            image.close();
        }
    }

    private void vibrateOnce() {
        Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        if (vibrator == null || !vibrator.hasVibrator()) return;
        if (Build.VERSION.SDK_INT >= 26) {
            vibrator.vibrate(VibrationEffect.createOneShot(55, 220));
        } else {
            vibrator.vibrate(55);
        }
    }

    private void closeReadersOnly() {
        if (jpegReader != null) { jpegReader.close(); jpegReader = null; }
        if (focusReader != null) { focusReader.close(); focusReader = null; }
    }

    private void closeCamera() {
        stopAutoCapture();
        if (session != null) { session.close(); session = null; }
        previewBuilder = null;
        if (cameraDevice != null) { cameraDevice.close(); cameraDevice = null; }
        closeReadersOnly();
        captureInProgress = false;
        openingCamera = false;
    }

    @Override
    public void onDestroy() {
        closeCamera();
        if (cameraThread != null) cameraThread.quitSafely();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
