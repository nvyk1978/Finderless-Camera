plugins {
    id("com.android.application")
}

android {
    namespace = "com.example.volumecamera"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.example.volumecamera"
        minSdk = 26
        targetSdk = 36
        versionCode = 48
        versionName = "0.1.45"
    }
}
