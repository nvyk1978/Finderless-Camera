plugins {
    id("com.android.application")
}

android {
    namespace = "com.example.volumecamera"
    compileSdk = 36

    signingConfigs {
        create("update") {
            storeFile = file("keystore/finderless-update.jks")
            storePassword = "finderless2026"
            keyAlias = "finderless"
            keyPassword = "finderless2026"
        }
    }

    defaultConfig {
        applicationId = "com.example.volumecamera"
        minSdk = 26
        targetSdk = 36
        versionCode = 98
        versionName = "0.1.95"
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("update")
        }
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("update")
        }
    }
}
