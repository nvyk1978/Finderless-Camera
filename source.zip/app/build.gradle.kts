plugins {
    id("com.android.application")
}

val appVersionName = "0.1.97"

android {
    namespace = "com.example.volumecamera"
    compileSdk = 36

    signingConfigs {
        create("update") {
            storeFile = file("keystore/finderless-update.jks")
            storePassword = "finderless2026"
            keyAlias = "finderless"
            keyPassword = "finderless2026"
        }
    }

    defaultConfig {
        applicationId = "com.example.volumecamera"
        minSdk = 26
        targetSdk = 36
        versionCode = 100
        versionName = appVersionName
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("update")
        }
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("update")
        }
    }
}

// Name the APK at the Android Gradle Plugin output stage itself.
// This means the actual file under app/build/outputs/apk/... already contains
// the version number; it does not rely on the GitHub artifact name or a later copy.
androidComponents {
    onVariants(selector().all()) { variant ->
        variant.outputs.forEach { output ->
            output.outputFileName.set("FinderlessCamera-v$appVersionName.apk")
        }
    }
}
