plugins {
    id("com.android.application")
}

// Keep this literal because the ZIP build workflow validates versionName directly.
val apkVersionName = "0.1.98"

android {
    namespace = "com.example.volumecamera"
    compileSdk = 36

    signingConfigs {
        create("update") {
            storeFile = file("keystore/finderless-update.jks")
            storePassword = "finderless2026"
            keyAlias = "finderless"
            keyPassword = "finderless2026"
        }
    }

    defaultConfig {
        applicationId = "com.example.volumecamera"
        minSdk = 26
        targetSdk = 36
        versionCode = 101
        versionName = "0.1.98"
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("update")
        }
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("update")
        }
    }
}

// Rename the APK at the Android Gradle Plugin output stage.
// apkVersionName is intentionally separate from defaultConfig.versionName so
// versionName remains a literal for the repository's Verify source ZIP step.
androidComponents {
    onVariants(selector().all()) { variant ->
        variant.outputs.forEach { output ->
            output.outputFileName.set("FinderlessCamera-v$apkVersionName.apk")
        }
    }
}
