# FinderlessCamera 0.1.12

Changes from 0.1.11:
- Bottom padding: 100 px.
- Peek-prevention button:
  - normal: dark red / `覗き見防止モード`
  - active: red / `覗き見防止モード中`
- While peek-prevention mode is active, vibration / notification swipe / front-camera
  switches and their text are red regardless of ON/OFF state.
- Existing peek-mode forced-state behavior is unchanged.
- Notification buttons keep the wider 96dp width but return to 40dp height.
- Floating delete X moved another 5px upward (10px total from original center).
- Resident stop is ignored while the floating shutter is active.
- X returns from snapped 2x size to normal size in 500ms when snap is released.
