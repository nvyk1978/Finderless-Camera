# FinderlessCamera 0.1.18

Smartphone Monitor Mode:
- Enabling Smartphone Monitor Mode automatically starts resident mode.
- It automatically starts AUTO capture.
- Monitor mode remains the highest-priority runtime state while persisted:
  front camera ON, shutter vibration OFF, notification swipe-dismiss ON,
  floating shutter OFF, AUTO ON.
- When monitor mode is enabled from the UI, the Activity removes itself from
  Android's recent-task list after the service/runtime state has been applied.
- Reopening the app while monitor mode is already active keeps the UI accessible
  so the user can turn monitor mode OFF.
- CameraForegroundService explicitly uses stopWithTask=false.
- While monitor mode is active, service returns START_STICKY so Android may
  recreate the service after process pressure.
