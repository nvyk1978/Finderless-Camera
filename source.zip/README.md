# FinderlessCamera 0.1.9

Changes:
- Top settings order:
  1. Floating shutter
  2. 3-burst shot
  3. Shutter vibration
  4. Start resident service on app launch
- Auto-start resident toggle defaults OFF.
- Resident camera service keeps CameraDevice/CaptureSession open even when auto capture is OFF.
- Floating shutter also keeps camera open.
- Camera closes only when neither resident nor floating-shutter use requires it.
- Notification dismissal updates resident state and the main button.
- On app resume, active notification state is checked to choose 常駐開始 / 常駐終了.
- Floating delete snap radius: 300 px.
- Floating initial position: 300 px from right and bottom.
- X-delete immediately turns the floating-shutter toggle OFF and clears saved position.
- X and shutter now shrink/fade together for the full delete animation.
- More exaggerated easing on X expansion and delete shrink.
- Burst setting defaults OFF; when ON, a normal shutter tap requests 3 shots.
- Burst vibration is three fast pulses immediately at shutter input.
- Notification shutter and floating shutter flash white inside their shapes.
- Notification shutter is the same width as the auto ON/OFF button.
