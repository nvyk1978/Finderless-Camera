# FinderlessCamera 0.1.19

Fixes:
- Notification manual-shutter ◎ moved 1px down from 0.1.18 (now 4px above center).
- Resident-start button now enters a request-in-flight state immediately, preventing the
  short startup window where taps appeared to do nothing.
- Smartphone Monitor Mode: tapping Resident End, STOP, or Smartphone Monitor Mode active
  performs one complete shutdown: monitor OFF / AUTO OFF / resident OFF.
- Floating shutter overlay uses an explicit `float_overlay_alive` runtime flag.
- Floating ON is persisted only after WindowManager successfully adds the overlay.
- Overlay creation failure rolls the floating toggle back OFF immediately.
- On Activity resume, stale `float_enabled=true` with no live overlay is reset to OFF.
- Floating overlay removal and service destruction both clear the live-overlay flag.
