# FinderlessCamera 0.1.23
- Independent ミニファインダー toggle directly below フロートシャッター.
- 200px-high live Camera2 preview overlay, default lower-left.
- Independent of HIDE.
- Long press to move; same central × snap/delete behavior as floating shutter.
- × delete animation 0.5s, toggle turns OFF, saved position clears.
- Normal moved position is remembered.
- Smartphone Monitor Mode forces mini finder OFF.
