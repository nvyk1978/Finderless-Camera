# FinderlessCamera 0.1.10

- Settings are grouped below the title with a 200 px gap.
- Toggle order:
  floating shutter / 3 burst / shutter vibration / auto-start resident /
  notification swipe-dismiss / front camera.
- Added app-side auto capture ON/OFF button.
- Added save-folder chooser above diagnostic log.
- Front camera switch changes actual LENS_FACING immediately while active.
- Camera status text changes between rear/front.
- Resident or floating-shutter mode keeps the Camera2 session open.
- Notification auto label is AUTO/OFF.
- Notification swipe behavior updates immediately.
- Burst mode gives vibration + shutter flash at each actual shot.
- Delete X is shifted up 5 px and X/shutter delete animation is 1 second.
- User-selected folder is stored using Android's document-tree permission.
