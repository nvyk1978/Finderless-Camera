# FinderlessCamera 0.1.4-diagnostic

Diagnostic build based on the 0.1.4-float single-camera version.

No camera-ID or multi-camera functions are added.

Diagnostics:
- timestamped app/service/camera/capture/float events
- uncaught Java exception stack trace
- Android 11+ previous process exit reason via ApplicationExitInfo
- previous exit trace when Android exposes it
- `診断ログを表示` button in the settings screen
- internal log capped/rotated to avoid unlimited growth

Please reproduce the crash, reopen FinderlessCamera if possible,
tap `診断ログを表示`, and capture/send the bottom of the report.


Notification fix:
- Removed android.widget.Space from custom RemoteViews notification.
- Uses right-aligned LinearLayout gravity instead.
