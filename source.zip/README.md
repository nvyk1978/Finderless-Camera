# FinderlessCamera 0.1.20

Crash fix:
- Floating shutter flash animation is now always dispatched to the main UI thread.
- Notification flash feedback is also dispatched from the same main-thread path.
- `FloatingShutterView.flashInner()` contains a defensive main-thread check and reposts
  itself if called from CameraThread or any non-main thread.
- Camera2 capture processing remains on FinderlessCameraThread.
- This fixes the confirmed `ViewRootImpl$CalledFromWrongThreadException` seen when
  tapping the floating shutter.
