# Finderless Camera

通知常駐型のAndroidカメラ試作版です。

## 現在の仕様
- カメラプレビューなし
- 通知右側のON/OFF風ボタン
- ON中：3秒間隔の自動で背面カメラ撮影
- フラッシュOFF
- Camera2の連続AF（オートフォーカス）
- 撮影完了時に短いバイブ1回
- 保存先：`Pictures/FinderlessCamera`
- 画面消灯中でも、Foreground Service + Accessibility Serviceで音量キー検出を試みます

## 初回セットアップ
1. アプリを起動
2. カメラ・通知権限を許可
3. 「常駐通知を開始」
4. 「音量ボタン検出を有効にする」からAndroidのアクセシビリティ設定を開く
5. `Finderless Camera` をON
6. 通知右側をONにする

## GitHub ActionsでAPKを作る
1. このプロジェクト一式をGitHubリポジトリの`main`ブランチへ入れる
2. Actions → `Build APK` を開く
3. `Run workflow`
4. 完了後、Artifacts の `FinderlessCamera-debug-apk` をダウンロード

`main`へpushした場合も自動ビルドされます。

## 重要：実機検証が必要な点
Androidのバージョン・メーカーにより、画面OFF/ロック中の音量キーイベントやカメラ動作が制限される場合があります。
この初版は、その可否を実機で確認できる形にしています。

## ビルド環境
- Android Gradle Plugin 9.3.1
- Gradle 9.5.0
- JDK 17
- compileSdk / targetSdk 36
- minSdk 26
