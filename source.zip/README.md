# FinderlessCamera 0.1.5

Based on the stable diagnostic-notification-fix build.

Changes:
- Main content shifted down 200 px.
- Main resident-service button is oval-square:
  - orange `常駐開始`
  - red `常駐終了`
- Diagnostic button is oval-square.
- Notification manual shutter `◎` is oval-square.
- Floating delete target is 200x200 px.
- Floating shutter snaps to delete target within 200 px.
- When snapped, both shutter ring and X turn red.
- Manual shutter works even while an automatic capture is already in progress (queued immediately after the current capture).
- Stronger capture vibration: 90 ms, amplitude 255.
- Service uses START_NOT_STICKY to avoid restart crash loops.
