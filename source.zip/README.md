# FinderlessCamera 0.1.26 — no-video branch

Based on 0.1.24. All video/recording UI and code are intentionally absent.

Retained / added:
- HIDE mode is a 10-minute escape-pod action.
- HIDE always starts AUTO still-photo capture, hides the notification, removes float/mini finder with 0.5s animations, disables shutter vibration, and removes the Activity task.
- Reopening the app during HIDE completely exits HIDE: AUTO OFF, resident service OFF, camera OFF, notification hidden setting reset, vibration restored, float/mini OFF.
- If the app is not reopened, HIDE fully terminates after 10 minutes and restores defaults.
- Notification swipe dismissal fully stops AUTO/camera/resident/overlays.
- Settings toggle `常駐中に通知エリアから消す` only hides/shows the notification.
- Notification HIDE: 96x40, dark gray, red text, brief bright feedback before hiding.
- AF and image-quality controls are compact right-aligned three-way segments.
- AF time (0.5 / 1.0 / 1.8 sec) is shown immediately left of the AF segment.
- Actual selected JPEG resolution is shown immediately left of the quality segment and follows front/back camera and low/medium/high.
- AF/quality rows gray out during AUTO and restore on STOP.
- Resident/AUTO buttons share one row. Save-folder/diagnostic buttons share one row.
- Bottom spacing is 50px.
- Mini finder remains portrait 225x400px and is now clipped to a rounded oval-square.
- Float and mini-finder long-press delay shortened from 450ms to 250ms.
- Turning Floating Shutter OFF from its toggle now uses a 0.5s in-place shrink/fade animation.

## 0.1.27
- Fixed mini-finder startup crash on Android 16: no background Drawable is assigned to TextureView.
- Mini finder remains rounded using ViewOutlineProvider + clipToOutline.
- AF / image-quality headings restored to 17sp.
- AF time and JPEG-resolution value text made smaller and narrower to preserve segment width.
- Three-way segments widened; no horizontal text scaling/condensed type is used.
- Settings bottom-only padding changed from 50px to 100px.


## 0.1.47
- AUTO restart now resumes when the warm camera session is already open.
- Auto shutter segment: 3s / 5s / 10s (default 5s).
- Burst segment: NO / 3 / 5 (default NO); replaces the old 3-shot switch.
- Burst and auto-shutter settings are shared by normal AUTO and HIDE mode.
- HIDE foreground notification uses the minimal title `1 new message`.

## 0.1.48
- Floating shutter and mini finder can bootstrap the camera foreground service without opening the four-button notification launcher.
- Opening the main app immediately terminates smartphone monitor mode.
- Notification launcher / core foreground / HIDE notification small icons are unified to the dot icon.
- Tapping the mini finder takes a photo; drag/long-press gestures remain reserved for moving/deleting it.
- Manual captures from mini finder, notification launcher and floating shutter all use the shared burst setting (NO / 3 / 5).
- Smartphone monitor mode uses the shared auto-shutter interval and burst settings, same as HIDE/AUTO.
- Removed the old `起動時に常駐して起動する` setting and its automatic resident-start behavior.
- Added `保存画像にジャイロを適用` below shutter vibration, default ON. Physical device orientation is sensor-derived and therefore works even when Android screen auto-rotate is disabled.
- Main settings Activity is locked to portrait orientation.


## 0.1.50
- Mini-finder tap capture now gives a brief white finder flash once per tap/capture set; burst 3/5 does not strobe the finder for every frame.
- Blue and orange accents are one step darker across buttons, switches/segments and the notification launcher.
- Dark-gray states are one step darker for launcher STOP, HIDE controls and unselected/disabled segments.
- Complete-exit X icons in both settings and notification launcher now use the same dark red as the app's other dark-red controls.
- Removed the `常駐中に通知ランチャーを隠す` settings toggle. Notification swipe/HIDE internals remain service-managed.
- Added `起動時に通知ランチャーだけ起動する` below the front-camera switch, default OFF. When enabled, opening the app restores/starts only the notification launcher; AUTO, floating shutter and mini finder are not enabled by it.


## v0.1.50
- Toggle labels now use the same TextView typography as segment labels.
- Startup launcher-only mode skips the settings screen on app-icon launch; notification-body tap opens settings.
- Mini-finder capture flash now fills the rectangular finder area.
- Blue/orange accents darkened one more step.


## v0.1.53
- Palette retained: #2A2222 / #3A3333 / #5A5555 / #223355 / #445577 / #441100 / #882211 / #775500.
- Toggle ON: #445577, Toggle OFF: #2A2222.
- HIDE mode button text remains white in app and notification launcher.


## v0.1.58 (versionCode 61)
- Mini finder camera session reopens correctly after aspect/resolution changes while mini finder is active.
- Floating shutter and mini finder long-press threshold shortened by 0.2 s (250 ms -> 50 ms).
- Main-screen complete-exit long-press threshold shortened by 0.2 s (250 ms -> 50 ms).
- Complete-exit X icon changed to light red #882211 (including notification launcher).
- Toggle colors: OFF track #2A2222 / thumb #FFFFFF; ON track #223355 / thumb #445577.


## v0.1.59
- Fixed JPEG aspect selection so explicit 4:3/16:9 cannot fall back to a 1:1 stream.
- Added anti-blur exposure control for all still captures: targets about 1/125 s, raises ISO first, and only slows shutter when sensor ISO limit is reached.
- The same exposure policy applies to single and burst shots.


## v0.1.63
- Switch thumb aspect adjusted from 20x20dp to 24x20dp so the rendered Android Switch knob appears closer to a true circle on-device.
- Track remains #2A2222. OFF thumb remains #FFFFFF. ON thumb remains #445577.


## v0.1.68
NToggleSwitch owns geometry. Previous NToggleThumbDrawable.java retained for rollback. Quick Settings tile invokes ACTION_SHOW_NOTIFICATION only.


## v0.1.71
- Restored all N-toggle thumb colors to the same 24dp integer-pixel diameter after the v0.1.70 size experiment proved size control works.
- NToggleSwitch now owns touch dispatch explicitly and delegates ACTION_UP to CompoundButton.performClick(), restoring checked-state movement/listeners.
- Complete-exit button long-press confirmation delay restored to 300ms (v0.1.70 had 50ms, causing ordinary taps to become drags before ACTION_UP).
- Quick Settings notification-launcher tile unchanged.


## v0.1.74
- N-toggle thumb slide animation: 120ms decelerate for normal user toggles.
- Locked-red mode remains immediate (no slide animation).
- Thumb diameter remains 24dp in all states.


## v0.1.77 (versionCode 79)
- Finalized N toggle thumb sizing: OFF white 24dp, colored ON/locked thumbs 26dp.
- Keeps the existing 120ms slide animation and current touch behavior.


## v0.1.77 changes
- Restored mini-finder / floating-shutter tap capture by returning the shared drag long-press threshold from 50 ms to 300 ms. At 50 ms, an ordinary tap was promoted to drag before ACTION_UP, so the capture branch could not run.
- N-toggle locked dark-red transitions now use the same 120 ms thumb animation as normal state changes.
- Selected segmented controls now use light blue #445577.


## v0.1.79 (versionCode 82)
- Floating shutter flash changed to the same quick double-flash rhythm as the mini finder.
- Floating shutter and mini finder visual feedback now fires for every actual shot, including each burst frame.
- Shutter vibration remains controlled by the existing setting and fires once per completed shot for either overlay.
- Removed the mini finder tap-time pre-flash so feedback stays synchronized with capture.


## v0.1.81 (versionCode 84)
- Fixed remaining legacy enqueueManualShots(3) call after shot-source tracking was introduced.
- No behavior change from v0.1.80 beyond compile fix.

- v0.1.82: HIDE crash-loop recovery: reopening the app clears persistent HIDE state before any service start; HIDE teardown closes Camera2 before mini-finder removal to prevent session-reconfigure races.


## v0.1.87
- Notification launcher is swipe-dismissible again. Swiping it out marks the launcher inactive and synchronizes the settings launcher button.
- If the launcher is the camera foreground notification, swipe-out tears down the resident camera foreground service so the privacy indicator turns off instead of falling back to the HIDE/core notification.
- QS-only launcher dismissal also broadcasts state change and keeps the settings button synchronized.
