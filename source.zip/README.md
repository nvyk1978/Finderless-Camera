# FinderlessCamera 0.1.26 — no-video branch

Based on 0.1.24. All video/recording UI and code are intentionally absent.

Retained / added:
- HIDE mode is a 10-minute escape-pod action.
- HIDE always starts AUTO still-photo capture, hides the notification, removes float/mini finder with 0.5s animations, disables shutter vibration, and removes the Activity task.
- Reopening the app during HIDE completely exits HIDE: AUTO OFF, resident service OFF, camera OFF, notification hidden setting reset, vibration restored, float/mini OFF.
- If the app is not reopened, HIDE fully terminates after 10 minutes and restores defaults.
- Notification swipe dismissal fully stops AUTO/camera/resident/overlays.
- Settings toggle `常駐中に通知エリアから消す` only hides/shows the notification.
- Notification HIDE: 96x40, dark gray, red text, brief bright feedback before hiding.
- AF and image-quality controls are compact right-aligned three-way segments.
- AF time (0.5 / 1.0 / 1.8 sec) is shown immediately left of the AF segment.
- Actual selected JPEG resolution is shown immediately left of the quality segment and follows front/back camera and low/medium/high.
- AF/quality rows gray out during AUTO and restore on STOP.
- Resident/AUTO buttons share one row. Save-folder/diagnostic buttons share one row.
- Bottom spacing is 50px.
- Mini finder remains portrait 225x400px and is now clipped to a rounded oval-square.
- Float and mini-finder long-press delay shortened from 450ms to 250ms.
- Turning Floating Shutter OFF from its toggle now uses a 0.5s in-place shrink/fade animation.

## 0.1.27
- Fixed mini-finder startup crash on Android 16: no background Drawable is assigned to TextureView.
- Mini finder remains rounded using ViewOutlineProvider + clipToOutline.
- AF / image-quality headings restored to 17sp.
- AF time and JPEG-resolution value text made smaller and narrower to preserve segment width.
- Three-way segments widened; no horizontal text scaling/condensed type is used.
- Settings bottom-only padding changed from 50px to 100px.
