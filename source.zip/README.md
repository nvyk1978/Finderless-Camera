# FinderlessCamera 0.1.4-float

Rollback build: stable single-camera 0.1.4 behavior + manual-gate fix + floating shutter.

- 5-second automatic capture
- notification `◎` manual capture
- flash OFF
- autofocus before capture, max 1.8 s wait
- JPEG quality 100
- Pictures/FinderlessCamera
- no camera-ID selection
- no multi-camera code

Floating shutter:
- default OFF after app/service restart
- 200×200 px, always fully inside screen
- tap to shoot
- long-press confirmation vibration
- drag after long press
- central `×` delete target
- snap within about 100 px
- unsnap after about 200 px
- release while snapped: shrink/fade out and toggle OFF
