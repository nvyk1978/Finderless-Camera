# FinderlessCamera 0.1.8

Changes:
- Floating delete snap radius: 250 px (release 350 px).
- Delete X expands with fast-start / slow-finish easing.
- Delete X and floating shutter shrink/fade with slow-start / accelerating easing.
- X-delete broadcasts state immediately so the settings toggle updates without reopening.
- Stronger shutter vibration, triggered immediately at capture request.
- Added `シャッター時のバイブレーション` toggle, default ON.
- Resident mode keeps the camera session warm where possible for faster response.
- Floating shutter: tap = single shot; stationary long-press = 3-shot burst.

Android notification limitation:
- RemoteViews/PendingIntent does not expose a reliable long-press gesture callback to the app.
  The notification shutter remains single-tap capture; a true notification long-press burst
  cannot be implemented reliably without changing the interaction model.
