# FinderlessCamera 0.1.7

Floating shutter refinements:
- Snap radius: 600 px.
- Unsnap radius: 700 px.
- Delete X target: 200 x 200 px.
- While snapped, X expands to 2x over 1 second.
- While snapped, X and shutter ring are red.
- When unsnapped, shutter returns under the finger using the original grab offset.
- Delete animation takes 2 seconds.
- X-delete turns the floating shutter toggle OFF.
- X-delete does not save position.
- Settings-toggle OFF saves position.
- Initial position: 600 px from right and 600 px from bottom.
- Shutter view is hidden before removal to prevent a one-frame white ring flash.
