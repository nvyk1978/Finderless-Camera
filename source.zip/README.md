# FinderlessCamera 0.1.15

Changes:
- FinderlessCamera title moved down 100pt.
- Bottom spacing increased to 200pt.
- Notification button boxes remain aligned; only the manual ◎ glyph is moved down 10pt.
- Resident END button: dark gray background / red text.
- AUTO STOP button: dark gray background / red text.
- Notification STOP: dark gray background / red text.
- Normal switches use blue when ON; the three monitor-controlled labels use normal text color.
- `覗き見防止モード` renamed to `スマホ監視モード`.
- Active monitor button: dark gray background / red text / `スマホ監視モード中`.
- During monitor mode, vibration / notification-dismiss / front-camera switches and text remain red.
- Floating-delete cleanup removes X and shutter immediately after the delete animation to prevent one-frame X reappearance.
