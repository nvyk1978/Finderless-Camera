# FinderlessCamera 0.1.14

- Title fixed at top.
- All toggles/buttons/info bottom-aligned as one group.
- Bottom padding 100px.
- Vertical rhythm: switches 4dp, buttons 8dp, info 6-10dp.
- Floating X moved another 3px up (16px total).
- Notification manual shutter moved another 10px up (15px total).
- Enabling floating shutter automatically starts resident mode.
- Starting AUTO automatically starts resident mode if needed.
