# FinderlessCamera 0.1.16

Unit correction from 0.1.15:
- FinderlessCamera title offset: 100px (was mistakenly 100pt).
- Bottom spacing: 200px (was mistakenly 200pt).
- Notification manual shutter ◎ internal downward offset: 10px (was mistakenly 10pt).
- All other 0.1.15 behavior is unchanged.
